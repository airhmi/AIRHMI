# AIRHMI widget reference — JSON fields and defaults

> Field names are **camelCase** in `.airhmi.json`. A missing field is not an error — Designer applies
> the default. Values below are Designer 2.9.4 defaults. When unsure about a field, open the matching
> page of the installed user guide (`manual\<lang>\04-component-reference\`) or create the component
> once in Designer, save, and read the JSON it wrote.

## Project model
```text
AirHmiProject (.airhmi.json root)
 ├─ device / upload / host / arduino / resources     project settings
 ├─ globalVariables[] (EVariable) · globalTimers[] (ETimer)   independent of screens
 └─ screens[] → screen
     ├─ name, width, height, backgroundColor, backgroundImage, onStart, functions
     ├─ variables[] · timers[]   (screen-local)
     └─ components[]             all visual components
```

## Project root — verified fields
```json
{
  "format": "airhmi-project",
  "version": 2,
  "name": "My Panel",
  "sourceDirectory": "",
  "device": { "width": 800, "height": 480, "rotation": "Horizontal", "profile": "AIRHMI_7", "firmware": "V5.07" },
  "upload": { "comPort": "", "baudRate": 115200, "interface": "usb", "startVideoStorage": "Flash" },
  "host":   { "target": "None", "protocol": "UART", "notes": "" },
  "arduino":{ "enabled": false, "sketchPath": "", "library": "AIRDUINO" },
  "startup":{ "picturePath": "img\\boot_logo.png", "pictureHex": "", "timeoutMs": 2000, "rotate": "Horizontal" },
  "resources": { "fonts": [ { "id": "font_roboto", "name": "Roboto", "relativePath": "", "embeddedHex": "" } ],
                 "images": [], "sounds": [], "videos": [] },
  "imageExportFormat": "Raw565",
  "globalVariables": [], "globalTimers": [],
  "screens": [],
  "openFirstScreen": "MainScreen",
  "hardware": { "enabled": false }
}
```
| Device | `device.profile` | width × height |
|---|---|---|
| 4.3" | `AIRHMI_4_3` | 480 × 272 |
| 5" | `AIRHMI_5` | 800 × 480 |
| 7" | `AIRHMI_7` | 800 × 480 |
| 10" | `AIRHMI_10` | 1024 × 600 |

`host.target`: `None` (standalone screen), `CustomUart` (your own host board), `Airduino` (Arduino with
the AIRDUINO library). `imageExportFormat`: `Raw565` (default, RGB565 raw) or `Jpeg`.
`hardware`: Hardware / Startup Settings block (Ethernet, Modbus TCP server, UART framing, GPIO/PWM start
levels, backlight, volume, startup user code) — full field list in `network-api.md` §1; omitted or
`enabled:false` = old behaviour. `upload.startVideoStorage` is the device's boot splash video, unrelated
to Video objects.
`startup` (Designer: Screen > Startup Logo): `picturePath` = boot logo image (PNG/JPG/BMP) **relative to the
project folder** (Designer 2.9.6+ stores it so; an absolute path breaks when the project moves), empty = default
AIRHMI logo; `pictureHex` = embedded logo from old `.ahi` (ignored when `picturePath` is set); `timeoutMs` = how
long it shows (default 2000); `rotate` = `Horizontal` / `Vertical`. Export scales it to the device size →
`airhmi_logo.raw` (RGB565, 768,000 B at 800×480) + `logo.js`. No command-line option: write the block in JSON.

## Screen skeleton
```json
{
  "id": "screen_main", "name": "MainScreen",
  "width": 800, "height": 480,
  "backgroundColor": -16777216,
  "backgroundImage": "", "backgroundPictureHex": "",
  "onStart": "", "functions": "",
  "variables": [], "timers": [],
  "components": []
}
```
- `name` ≤ 20 characters (firmware buffer), PascalCase, used in `ChangeScreenSet("MainScreen")`.
- `backgroundImage`: resource reference `"id:img_main_bg_png"` (see image recipe in `html-to-airhmi.md` §3).
- `onStart`: inline C or a `.c` file reference (`MainScreen_OnStart.c`), runs **every time** the screen opens.
- `functions`: shared C functions of the screen, callable from all its events.

## Common base (every component)
| Field | Type | Default | Notes |
|---|---|---|---|
| `componentType` | string | required | `EButton`, `ELabelBox`, … (spellings below are exact) |
| `id` | string | GUID | leave empty, Designer assigns |
| `name` | string | "" | **unique across the project**; event code and socket use it |
| `ownerScreen` | string | "" | screen name (fill it) |
| `left`, `top`, `width`, `height` | int | 0 | pixels |
| `visible`, `active` | bool | true | |
| `locked`, `static` | bool | false | |
| `tag` | int | 255 | free |
| `order` | int | 0 | z-order; **0..N-1 per screen, unique, background first** |
| `groupId` | string | "" | |
| `events` | object | `{}` | `onDown`, `onUp`, `onPress`, `onClick` — omit empty ones |
| `legacyProperties` | object | `{}` | legacy import leftovers, leave empty |

Event value = inline C code **or** a `.c` file name relative to the project folder (`code\btnStart_OnDown.c`).

## Component types (toolbox name → `componentType`, default size)

### Common
**Button → `EButton`** (160×64): `caption="Button"`, `pressCaption=""`, `fontName="Roboto"`, `fontSize=16`,
`fontColor=-1`, `textAlignment="Center"`, `color=-16776961`, `colorTo=-16777088`, `borderColor=-16777216`,
`borderWidth=1`, `radius=3` (corner radius px, 0 = sharp), `pressColor=-1`, `pressColorTo=-4144960`,
`pressFontColor=-1`, `pushPull=false`, `gradient="Top to Bottom"`, `effect=0`, `effectTime=100`,
`placement=1`, `permanent=false`

**LabelBox → `ELabelBox`** (180×42) — the only text component: `caption="LabelBox"`, `fontName`, `fontSize=16`,
`fontColor=-1`, `textAlignment="Center"`, `scrollEnable=false`, `scrollSpeed=0`, `rotate=0`, `keyboard="None"`
(on-screen keyboard type when the box is editable: `None`, `Numeric`, `Full`, …). Read-only display: `keyboard="None"`.
The device centres the text vertically in the box: for a single line give `height` ≈ 1.17 × `fontSize`.
⚠️ **Labels are not touch targets** (device and simulator): `onDown`/`onUp`/`onClick` on a label never run; a
label with a keyboard only opens the keypad and takes the typed text. For a touchable text put an `EShape`
hotspot with a higher `order` over it, or use an `EButton`.

**Label → `ELabel` — removed in Designer 2.9.6** (not shown in the toolbox). Never write `ELabel`; Designer 2.9.6+ converts every `ELabel`
of an older project (`.ahi` / `.airhmi.json`) to `ELabelBox` on open (same name, text, events; height = line height).

**TransShape → `EShape`** (160×80): `autoSize=false`, `borderColor=-16728065`, `borderWidth=2`,
`fillColor=540223160`, `shapeKind="Rectangle"`
⚠️ Purpose: **invisible touch/event area** (hotspot). Visible in Designer, **not drawn at runtime**.
Not a decoration element. **Keep the default colours** — custom (transparent) colours make the shape
unfindable in Designer later.

**Toggle → `EToggle`** (120×48): `state=0`, `stateOffCaption="Off"`, `stateOnCaption="On"`, `fontName`,
`fontSize=14`, `color=-1`, `fontColor=-1`, `pressColor=0`, `backgroundColorOff=-12303292`,
`backgroundColorOn=-16744448`, `flat=false`

**Spinner → `ESpinner`** (140×48): `value=0`, `minValue=0`, `maxValue=100`, `step=1`, `color=-12303292`,
`buttonColor=-10066330`, `fontColor=-1`, `fontName`, `fontSize=18`, `borderColor=-16777216`
(numeric up/down input)

**Menu → `EMenu`** (240×320, Designer 3.5.0+): a vertical, finger-scrollable list of items with optional
sub-text, icon and section headers (device: emWin SWIPELIST). `items="Item 1\nItem 2\nItem 3"` (one item per line),
`subTexts=""` (one line per item, empty line = none), `icons=""` (one project image name per line, empty = no icon;
icon size = `itemHeight-16`), `separators=""` (section headers placed **above** the item with that index:
`"0:Production;3:Settings"`), `selPos=-1` (−1 = nothing selected), `itemHeight=64`, `separatorHeight=34`,
`fontName="Roboto"`, `fontSize=17`, `subFontSize=13`, `backgroundColor=-14867925`, `selectedColor=-13660192`,
`textColor=-1512206`, `subTextColor=-6642510`, `lineColor=-13946304`, `separatorColor=-8418663`,
`separatorBackgroundColor=-15328735`, `borderColor=-13946304`, `borderPenSize=1`, `kineticScroll=true`
(false = no drag scrolling). **Event:** tapping an item selects it (`SelPos`/`SelVal`) and runs `events.onUp` —
the only menu event; `onDown`/`onPress` are unused. Changing `items` at runtime rebuilds the list; `subTexts`
and `separators` keep their indices. Full example: `examples\AIRHMI_Examples\1-BasicUI\Log_Menu\Log_Menu.airhmi.json`.

### Data
**Gauge → `EveGauge`** (120×120): `value=0`, `radius=0`, `minValue=0`, `maxValue=100`, `angleStart=-90`,
`angleEnd=90`, `color=0`, `needleColor=-65536`, `needleCenterColor=-1`, `needleCenterSize=18`, `needleX=60`,
`needleY=56`, `needleHeight=48`, `needleWidth=8`, `noPointer=false`, `noBackGround=false`,
`pictureName/picturePath/pictureHex=""` (needle geometry scales with the widget size)

**Arc → `EArc`** (120×120): `value=0`, `minValue=0`, `maxValue=100`, `startAngle=135`, `sweepAngle=270`,
`trackColor=-14931648`, `trackWidth=12`, `trackVisible=true`, `valueColor=-12877066`, `valueWidth=12`,
`valueAlign="Center"` (`Inner`/`Center`/`Outer`), `roundedEnds=true`
Ring/donut progress without a needle. Angles: 0° = 3 o'clock, clockwise positive; 135°/270° = classic
gauge with a gap at the bottom; `startAngle=270, sweepAngle=180` = top half circle. `valueWidth <
trackWidth` + `valueAlign` gives a border effect. The centre text is a **separate ELabelBox**.

**Line → `ELine`** (160×80): `points=[[0,0],[100,0]]` (**2-D int array**, not a string), `lineColor=-12877066`,
`lineWidth=2`, `capStyle="Round"` (`Butt`/`Round`), `closed=false`
Polyline. **Object-local coordinates with bottom-left origin (y grows upward)**. Points outside the
box are clipped. Max **128 points** (sliding window). Runtime: `LineAddPoint`, `LineSetPoint`, `LineClear`.

**Graph → `EGraph`** (220×120): `backgroundColor=-16777216`, `gridVisible=true`, `gridXSize=10`,
`gridYSize=10`, `scaleMultiple=1`, `scaleTickDistance=20`, `scaleOffset=120`, `yOffset=0`, `lineCount=4`,
`line1Color=-16776961`, `line2Color=-256`, `line3Color=-16744448`, `line4Color=-16181` (up to 4 traces)

**BarChart → `EBarChart`** (200×120): `values="30,60,45,80,55"`, `maxValue=100`, `barColor=-16744448`,
`axisColor=-1`, `backgroundColor=-16777216`, `axisVisible=true`

**PieChart → `EPieChart`** (120×120): `values="30,20,25,15,10"`, `sliceColors="-65536,-16711936,-16776961,-256,-23296"`,
`donut=false`, `innerRadius=40` (% when donut), `backgroundColor=-16777216`

**Qr → `EQR`** (120×120): `caption="AIRHMI"` (encoded content), `pixelSize=4`

**Led → `ELed`** (40×40): `state=0`, `onColor=-16711936`, `offColor=-12303292`, `blink=false`,
`blinkInterval=500`, `shape="Circle"`

**SevenSegment → `ESevenSeg`** (120×60): `value=0`, `digitCount=3`, `onColor=-65536`, `offColor=-14671840`,
`backgroundColor=-16777216`, `leadingZero=false`, `decimalPlaces=0`

**Slider → `EveSlider`** (220×36): `direction="horizontal"`, `value=0`, `range=100` (min is always 0),
`color=0`, `pressColor=-1`, `backgroundColor=-12303292`, `thumbColor=-1`

**ProgressBar → `EveProgressBar`** (220×34): `value=0`, `range=100`, `direction="horizontal"`,
`style="Rounded"`, `color=-16776961`, `backgroundColor=-12303292`, `borderColor=-16777216`, `borderSize=1`,
`fontName`, `fontSize=14`, `fontColor=-1`, `flat=false`

**ListView → `EListView`** (220×120): `headerList="Num^Name^Surname"`, `headerListSize="50^100^150"`,
`headerType="int^str^str"`, `headerBackgroundColor=-4144960`, `headerFontColor=-65536`, `headerFontSize=16`,
`headerHeight=34`, `gridVisible=true`, `enableMotion=true`, `gridFont="Roboto"`, `gridFontSize=16`,
`gridFontColor=-16777216`, `backgroundColor=-4144960`, `selectedItemColor=-16776961`, `enableSort=true`,
`items=""`, `listFile=""` (file name on the SD root), `listFileData=""`. Column separator `^`.
Large/real data goes to `sd_card\<listFile>`; the simulator reads it from its SD root, the device from the card root.

**ListWheel → `EListWhell`** (160×120 — spelling is intentional): `items=""`, `listFile=""`,
`listFileData="1\n2\n3\n4\n5"` (one item per line), `value=0`, `selectedColor=-65536`,
`unselectedColor=-8355712`, `separatorColor=-8355712`, `backgroundColor=-1`, `borderColor=-16777216`,
`borderPenSize=1`, `lineCount=3`, `fontName`, `fontSize=26`

**Log → `ELog`** (300×160, Designer 3.5.0+): a read-only, scrollable text log (event/alarm history; device: emWin
MULTIEDIT). `text=""` (initial lines, `\n` separated), `maxLines=200` (1..1000; oldest lines drop when exceeded —
in batches of `maxLines/10`, so the line count floats between 90 % and 100 % of `maxLines`), `timestamp=false`
(true = every appended line gets an `HH:mm:ss ` prefix: device RTC, or time since boot when no RTC is set),
`wrapMode="Word"` (`Word` / `None`), `autoScroll=true` (follow the newest line), `scrollBar=true`, `scrollBarWidth=24` (px, 8–48; finger-friendly, Designer 3.5.0+),
`fontName="Roboto"`, `fontSize=13`, `backgroundColor=-15921131`, `textColor=-3682342`, `borderColor=-13946304`,
`borderPenSize=1`. Text buffer on the device = `maxLines × 96` characters (≤ 96 KB). No events of its own.
`static=true` keeps the content across screen changes and lets scripts on other screens append to it.
⚠️ Performance: appending to a **full** 200-line log costs ≈0.3 s on the device (the widget re-wraps all text);
for fast feeds keep `maxLines` at 50–100. Example: `examples\AIRHMI_Examples\1-BasicUI\Log_Menu`.

**Variable → `EVariable`** (non-visual): `data=""`, `dataType="String"` (`String` / `int` / `float` / `Struct`
— exactly these spellings; `Int`, `Double` are wrong), `modifiers="Private"` (`Private`/`Public`).
Screen-local in `screens[].variables[]`, project-wide in `globalVariables[]`.

### Media
**Image → `EImage`** (120×90): `pictureName=""` (`"id:img_…"`), `picturePath=""` (`img\logo.png`),
`pictureHex=""`, `picturePressPath/picturePressHex=""`, `blendColor=0`, `rotationAngle=0`,
`rotationCenterLeft/Top=0`, `scaleX=1`, `scaleY=1`, `pushPull=false`

**MultiIcon → `EMultiIcon`** (80×80): `value=0` (shown state), `stateCount=2`, `state0Picture…state7Picture=""`
(resource references per state), `pictureNames=""`, `backgroundColor=0` — a state-switching icon
(e.g. fan off/on/fault) driven by `icoFan.Value = 2;`.

**Sound → `ESound`** (non-visual): `storage="Flash"` (`Flash`/`SD`), `fileName=""`, `mediaPath=""`
**Video → `EVideo`** (180×120, **canvas object** since 2.9.4): `fileName=""` (resource file, `intro.mp4`),
`mediaPath=""`, `fps=15` (5–30), `quality=5` (1–31, 1 = best), `loop=false`, `autoPlay=false`, `volume=100`
(reserved, no audio yet), `posterTimeMs=0`; legacy `storage="SD"`, `controlSetting=false` (ignored).
Even W×H, nothing overlapping it, one `autoPlay` per screen, ≤ 8 per screen. The MP4 is converted to
`<Screen>_<Name>.emf` + poster at export. Resource: `resources.videos[] { "id":"video_intro",
"name":"intro.mp4", "relativePath":"videos\\intro.mp4", "embeddedHex":"" }`. Details, functions and
cookbook: `video-object.md`.

### System
**Timer → `ETimer`** (non-visual): `interval=1000` (ms), `enabled=true`, `event=""` (periodic code)
**File → `EFile`** (non-visual): `fileName=""`

Legacy/unknown types import as `GenericComponent` — never write it by hand.

⚠️ Exact spellings that look like typos but are **required**: `EListWhell`, `EveGauge`, `EveSlider`,
`EveProgressBar`, `ESevenSeg`, `EQR`.

## Colour format (most frequent mistake)
Property fields use **signed 32-bit ARGB int** (.NET `Color.ToArgb()`); negative numbers are normal.
Opaque `#RRGGBB` → `R*65536 + G*256 + B - 16777216`.

| Colour | int | hex |
|---|---|---|
| black | -16777216 | 0xFF000000 |
| white | -1 | 0xFFFFFFFF |
| red | -65536 | 0xFFFF0000 |
| blue | -16776961 | 0xFF0000FF |
| dark green | -16744448 | 0xFF008000 |
| half-transparent example | 540223160 | 0x2029A7B8 |

In **event code** colours are strings: `button1.Color = "#FFAB00";`.

## Minimal valid component
```json
{
  "componentType": "EButton",
  "name": "btnStart",
  "ownerScreen": "MainScreen",
  "left": 100, "top": 200, "width": 200, "height": 100,
  "order": 1,
  "caption": "START",
  "events": { "onDown": "ChangeScreenSet(\"SettingsScreen\");" }
}
```

## Adding a component by hand — checklist
1. Append to the screen's `components[]` with at least `componentType`, `name`, `ownerScreen`,
   `left/top/width/height`, `order`.
2. `name` unique, colours int, `order` sequence intact.
3. `id` may stay empty.
4. Run `scripts\lint-project.ps1` then `scripts\run-sim.ps1 -NoLaunch` — "validation error" means a wrong
   field name or type; `export-result.json → validation.issues[]` names the object.
