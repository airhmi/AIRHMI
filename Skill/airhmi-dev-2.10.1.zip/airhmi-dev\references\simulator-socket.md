# Simulator socket test interface (TCP 8890)

> While the simulator runs it listens on a TCP socket and accepts normal HMI commands — read/write
> values, switch screens, touch coordinates and drive the debugger without touching the GUI.
> `test\test-scenario.ps1` and `scripts\capture-sim.ps1` are built on it.

## Protocol
| Item | Value |
|---|---|
| Address / port | `127.0.0.1:8890` (TCP) — **external command port**. `8888` is the internal VM↔host bridge (hundreds of messages/s; accepts external commands for backward compatibility but automation uses 8890). `8891` = printf input. |
| SD root | Start the simulator with `--sd <dir>` (`run-sim.ps1` passes the project's `sd_card\`). Check: `?sys.sd` → `sys.sd=<root>`; window title shows `[SD: <name>]`. Without the switch the fixed `C:\Users\Public\airhmi\sd_card` is used. |
| Encoding | UTF-8 (required for non-ASCII text) |
| Flow | **One command per connection**: connect → send → read reply → server closes |
| Timeout | RX/TX 3000 ms |
| Reply | getter → value; setter/void → empty. **`VarGet` → `"type,value"`** (e.g. `1,0`) |
| Debug log | `C:\Users\Public\airhmi\socket_debug.log` (every RX/TX line) |

## Two command formats
1. **Function call** (contains `(` and `);`):
   `ListViewGetXY("lvSettings", 0, 0, x);` · `LabelSet("lblFloor", "Text", "7");`
2. **Comma / wire format**:
   `lvSettings,0,,ListViewGetXY,0,` · `direction,,,VarGet,,`

⚠️ **`VarSet` / `VarGet` / `VarSeti` (project variables) MUST use the comma format.** In function
format the `Var*` commands are only echoed, nothing is set or read:
```text
scenarioData,DOOR:OPENED,,VarSet,,    # writes a string (type 0)
musicStatus,,,VarGet,,                # -> "1,0" (type 1, value 0)
VarSet("x","y");                      # ⚠ does NOT write — echo only
```
Screen-object commands (`LabelSet`, `ListViewGetXY`, `ChangeScreenSet` …) work in both formats.
These are **socket test commands**, not event code — event code always uses dot syntax (`script-api.md` §1).

3. **UART text protocol** (also accepted on the socket): `?button1.Text` reads, `button1.Text=12`
   writes, `?sys.screen` current screen, `?sys.sd` SD root. Handy for quick checks after dot-syntax code.

## Ready PowerShell client (`scripts\AirHmiSocket.psm1`)
```powershell
Import-Module "$PSScriptRoot\..\..\scripts\AirHmiSocket.psm1"   # adjust the relative path
Send-Hmi 'LabelSet("lblFloor","Text","7");'
Send-Hmi 'MainScreen,,,ChangeScreenSet,,'
Wait-Screen 'MainScreen' -TimeoutMs 3000      # polls ",,,ScreenGet,," until it matches
Touch-Hmi 400 240                              # tap at HMI coordinates
Send-Hmi 'demoTemp,25,,VarSet,,'
(Send-Hmi 'demoTemp,,,VarGet,,')               # -> "1,25"
```
Minimal inline version if the module is not available:
```powershell
function Send-Hmi([string]$cmd) {
    $c = New-Object System.Net.Sockets.TcpClient
    $c.Connect("127.0.0.1", 8890); $c.ReceiveTimeout = 3000; $c.SendTimeout = 3000
    $s = $c.GetStream(); $b = [Text.Encoding]::UTF8.GetBytes($cmd)
    $s.Write($b, 0, $b.Length); $s.Flush(); Start-Sleep -Milliseconds 250
    $resp = ""; $buf = New-Object byte[] 4096
    if ($s.DataAvailable) { $n = $s.Read($buf,0,4096); $resp = [Text.Encoding]::UTF8.GetString($buf,0,$n) }
    $c.Close(); return $resp.Trim()
}
```

## Programmatic touch (Touch / Press / Release)
Tap a button or object **without mouse or window focus**: send the HMI coordinate (0..W, 0..H — read it
from the screenshot) of the active screen:
```text
Touch,x,y,,,      # press + release at (x,y)  (normal tap)
Press,x,y,,,      # hold down
Release,x,y,,,    # release — for PushPull / long-press scenarios
```
- Take a screenshot → read the target's centre (x,y) → `Send-Hmi "Touch,$x,$y,,,"`. No `mouse_event`,
  no window offsets (that approach misses when the window moves or is not in front).
- Internally the topmost child control at (x,y) receives `WM_LBUTTONDOWN/UP` → the real event chain
  runs (screen change, `onDown` script …).
- Verify with `ScreenGet` right after the `Touch`. Projects with idle/demo timers may switch screens
  on their own — measure `Touch → immediately ScreenGet`.

## Scenario test skeleton (`test\test-scenario.ps1`)
```powershell
param([string]$LogDir = "$PSScriptRoot\logs")
Import-Module "$env:USERPROFILE\.claude\skills\airhmi-dev\scripts\AirHmiSocket.psm1" -Force
$log = Join-Path $LogDir ("test-scenario-{0}.log" -f (Get-Date -Format yyyyMMdd-HHmmss))
New-Item -ItemType Directory -Force $LogDir | Out-Null
$fail = 0
function Check([string]$id, [bool]$ok, [string]$detail) {
    $line = "[{0}] {1} {2}" -f ($(if ($ok) {"PASS"} else {"FAIL"})), $id, $detail
    $line | Tee-Object -FilePath $log -Append; if (-not $ok) { $script:fail++ }
}

# S-01: start → main screen shows "Ready"
Send-Hmi 'MainScreen,,,ChangeScreenSet,,' | Out-Null
Check "S-01" (Wait-Screen 'MainScreen') "main screen opened"
Check "S-01" ((Send-Hmi '?lblStatus.Text') -match 'Ready') "status label"

# S-02: Settings button opens SettingsScreen
Touch-Hmi 720 420
Check "S-02" (Wait-Screen 'SettingsScreen') "settings via touch"

# E-01: injected out-of-range temperature shows the alarm
Send-Hmi 'demoTemp,99,,VarSet,,' | Out-Null; Start-Sleep -Milliseconds 1200
Check "E-01" ((Send-Hmi '?ledAlarm.State') -match '1') "alarm LED on"

"RESULT: $(if ($fail -eq 0) {'PASS'} else {"FAIL ($fail)"}) — log $log"
exit $fail
```
One block per S-xx/E-xx from `SCENARIO.md`, same numbering; the acceptance criterion is the `Check`.
Keep every log (regression history).

## PCC debugger commands (`Dbg*`) — breakpoints / stepping / variables
The simulator's source-level debugger is driven over the same socket (works on both ports; use 8890).
Line numbers are **event-code lines** (1-based, as in Designer's editor); screen `Functions` report
`F<n>`.

| Command | Reply | Meaning |
|---|---|---|
| `DbgBreakAt,<screen>,<object>,<event>,<line>[,0]` | `OK` / `ERR,no debug info …` | Set a breakpoint (moves to the next code-generating line). Trailing `0` removes it. For `Functions`: `DbgBreakAt,<screen>,<screen>,Functions,<line>` |
| `DbgClear` | `OK` | Remove all breakpoints |
| `DbgState` | `paused\|running\|idle\|error,<screen>,<object>,<event>,<line\|F<n>>,<reason>` | `reason`: `bp` / `step` / `pause`; `error` stays until the next event |
| `DbgContinue` / `DbgPause` / `DbgStop` | `OK` / `ERR,not paused` | Continue / pause the running event (infinite-loop catcher; if nothing runs, stops at the first line of the next event) / abort the event |
| `DbgStep,over\|into\|out` | `OK` | Step; `into` stops at a function header (`F<n>`), `out` returns to the caller |
| `DbgGet,<name>` | value / `ERR,…` | Event variable → active frame local → project global → screen variable. `p.x` member access works; arrays `[1,2,3]`, structs `{...}` |
| `DbgSet,<name>,<value>` | `OK` / `ERR,…` | Only while paused |
| `DbgAttach,0\|1` · `DbgAttach?` | `OK` / `1\|0` | Attach/detach without a window |
| `DbgWindow,open\|close\|tab` | `OK` | Open/close the debugger window; select the simulator's Debug tab |

- Precondition: the export contains `.pccdbg` files (default; `--no-debug-info` removes them →
  `DbgBreakAt` answers `ERR,no debug info`).
- Breakpoints persist in `C:\Users\Public\airhmi\debugger\<ProjectName>.breakpoints.json`; start tests
  with `DbgClear` + `DbgAttach,1` for a clean state.
- Example: `DbgClear` → `DbgBreakAt,Screen1,Button1,OnUp,7` → `Touch,100,70,,,` → poll `DbgState`
  (100 ms, up to 3 s) = `paused,Screen1,Button1,OnUp,7,bp` → `DbgGet,total` → `DbgStep,into` → `DbgContinue`.
  While paused, `LabelGet`/`Touch` still answer; other events (timers included) queue and run after `Continue`.

## Notes
- The socket exists only while the simulator runs (start it with `run-sim.ps1`).
- **Heavy timer/demo code makes the simulator slow per event:** each event re-initialises the
  native mocks, and touches queued behind a busy timer run late. Speed a demo model up (a demo-speed
  variable) only while the test waits for a process state; tap and check screens at 1x. Protect against
  double presses by state ("command already applied" bit), not by a time window — a late second tap
  falls outside any window.
- `Fs_*` paths: `D:` = the `--sd` folder, `C:` = `C:\Users\Public\airhmi\flash`. Network functions
  (`SocketTCP_*`, `ModbusTCP_*`) really connect from the PC — a scenario that needs PLC data can run a
  Modbus TCP simulator on the PC and `test-scenario.ps1` can preload its registers.
- Getters refresh a ListView from the SD root on every call → a value written with `ListViewSetXY` may not
  survive the next `ListViewGetXY`.
- Frequent commands: `ListViewGetXY/SetXY`, `LabelSet`, `ScreenGet/ChangeScreenSet`, `GlobalIntVarGet`,
  `GlobalStdVarGet`, property keys `COLOR`, `FONT_SIZE`, `ENABLE`, `STATE`, `VISIBLE`.
- Whether a command was recognised: `socket_debug.log`.
