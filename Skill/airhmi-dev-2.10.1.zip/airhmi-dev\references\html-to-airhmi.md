# HTML mockup → AIRHMI conversion rules

> This file gives the *rules*; field lists live in `widget-reference.md`, event-code functions in
> `script-api.md`.

## 0. Precondition: the mockup is designed to be convertible
- One HTML page = one AIRHMI screen. Page size = device resolution:

| Device | Resolution |
|---|---|
| 4.3" | **480×272** |
| 5" and 7" | **800×480** |
| 10" | **1024×600** |

  Ask the user for the device size if it is not known — do not guess.
- Every element is `position:absolute; left/top/width/height` in **px** → copied 1:1 into the JSON.
- HTML `id` → component `name` (unique; event code reaches the widget by this name).

## 1. Layering principle — static is baked into the background, dynamic becomes a widget (DEFAULT)
A screen is split in two:
- **Everything static is baked into the background image:** panels, frames, decoration, separators,
  fixed icons, fixed titles, button faces (when no press effect is needed). Production: render the
  mockup with dynamic elements hidden (`[data-dynamic]{visibility:hidden}`) at device resolution →
  PNG → the screen's `backgroundImage`. The background does not have to be a flat picture — all the
  visual richness of the design lives here.
- **Only dynamic / interactive parts become widgets:** changing text → `ELabelBox`, pressable area →
  `EButton` (visible press effect) or invisible `EShape` hotspot (face already in the background),
  state-switching picture → `EImage`/`EMultiIcon`, value displays → gauge/arc/progress/slider.
- **Gain:** the widget constraints of §7 (no shadow, no radius …) apply only to dynamic elements;
  the static layer is free HTML.
- **The decision is written in the behaviour plan:** for every mockup element "static → bake" or
  "dynamic → which widget".
- **Press-feedback pattern — press images:** key faces are baked in their normal state; for each key a
  small image of its **pressed** state is produced (`<screen>_press_<name>.png`), placed at the key's
  coordinates as an `EImage` with `visible=false`. Touch area event: `onDown` → `imgKeyQ.Visible = 1;`
  + the key's action · `onUp` → `imgKeyQ.Visible = 0;`. For simple single-colour buttons `EButton`
  with `pressColor` is the simpler alternative.
- **Movable group (card) pattern — exception to layering:** component groups whose position changes
  at runtime (sortable cards) are **not** baked — card shell `EImage`, symbol `EImage`, live value
  `ELabelBox`, bar/LED separate widgets; the group moves together in code.
- Mockup requirement: dynamic elements carry `data-dynamic`; press images are rendered from the
  mockup's `:active` style and cropped to the element's bounding box.

## 2. Element → widget mapping (dynamic elements)

| HTML | componentType | Notes |
|---|---|---|
| `<button>` | `EButton` | text→`caption`; background→`color` (+`colorTo` for gradient); `border-radius`→`radius` px; click→`events.onDown` |
| `<span>/<p>/<h1..h6>` (text) | `ELabelBox` | **always ELabelBox, never ELabel**. Read-only: `keyboard="None"`; text→`caption`, font-size→`fontSize`, color→`fontColor`. Box with slack (§6) |
| `<input type="text/number">` | `ELabelBox` | set `keyboard` to the on-screen keyboard type |
| `<img>` | `EImage` | file→`pictureName/picturePath` (§3); `transform:rotate`→`rotationAngle` |
| touch area / invisible button (hotspot) | `EShape` | **EShape = invisible touch/event area**, not drawn at runtime. Keep default colours |
| coloured / bordered `<div>` (decoration) | — | **do not use EShape** (invisible). Bake into the background or use `EImage` |
| `<input type="range">` | `EveSlider` | max→`range` (min is 0), value→`value`; `direction` |
| `<progress>` | `EveProgressBar` | value/max→`value/range`; `style="Rounded"` |
| needle dial | `EveGauge` | `minValue/maxValue/angleStart/angleEnd` |
| ring / donut progress (no needle, value in the middle) | `EArc` | `value/min/max`, `startAngle/sweepAngle`, `trackColor/Width`, `valueColor/Width`, `valueAlign`; centre text = separate `ELabelBox` |
| free line / polyline / live trend curve / schematic line | `ELine` | `points` 2-D int array, **object-local, bottom-left origin**; runtime `LineAddPoint`; max 128 points |
| multi-trace line chart | `EGraph` | up to 4 traces, grid |
| bar chart / pie chart | `EBarChart` / `EPieChart` | `values` comma list |
| `<table>` | `EListView` | headers with `^`: `headerList`, `headerListSize`, `headerType`; big data via `sd_card` `listFile` |
| scroll picker / `<select>` | `EListWhell` | `listFileData` one item per line; `lineCount` visible rows |
| navigation / settings list (`<ul>`/`<nav>` rows with title, sub-text, optional icon, section headers) | `EMenu` (3.5.0+) | `items` one per line, `subTexts`, `icons` (project image names), `separators` `"0:Production;3:Settings"`; `itemHeight`/`separatorHeight`; tap → `events.onUp` (`sel = menu1.SelVal;`) |
| event / alarm log, console (`<pre>`, `<textarea readonly>`, scrolling list of timestamped lines) | `ELog` (3.5.0+) | `maxLines` (50–100 for fast feeds), `timestamp`, `wrapMode`, `autoScroll`; feed with `log1.Append = "...";` |
| checkbox / switch | `EToggle` | `stateOffCaption/stateOnCaption`, `backgroundColorOff/On` |
| numeric up/down | `ESpinner` | `minValue/maxValue/step` |
| status lamp | `ELed` | `onColor/offColor`, `blink` |
| digital readout | `ESevenSeg` | `digitCount`, `decimalPlaces` |
| state icon (fan off/on/fault) | `EMultiIcon` | `stateCount`, `state0Picture…` |
| QR image | `EQR` | `caption` = encoded content, `pixelSize` |
| `<video>` (poster + play icon, even W×H) / `<audio>` | `EVideo` / `ESound` | Video: `fileName` = MP4 resource, `fps`/`quality`/`loop`/`autoPlay`/`posterTimeMs`, controls outside the rectangle (`video-object.md`); Sound: `storage`, `fileName` |
| JS `setInterval(f, ms)` | `ETimer` | `interval` ms, code in `event` |
| JS variable / state | `EVariable` | `dataType` `String`/`int`/`float`; project-wide → `globalVariables[]` |

No equivalent → bake into the background + overlay `ELabelBox`/`EImage` (+ invisible `EShape` touch
area); if that fails simplify the mockup (tell the user). **Never invent a component type.**

## 3. Images (EImage / screen background)
- **Designer accepts PNG only.** Convert JPG/WebP first.
- **Scale the image yourself to the widget's exact W×H pixels** — do not rely on export scaling
  (export converts to RGB565 `.raw`; the simulator reads the raw size from the JSON W/H → mismatch = garbage).
- **Never hand-fill `pictureHex` / `backgroundPictureHex`** (legacy fallback).

**Adding an image to the JSON — exact recipe:**
1. Put the PNG next to the project: `<project>\img\logo.png` (`relativePath` is relative to the `.airhmi.json` folder).
2. `resources.images[]` entry — id rule: `"img_"` + name lower-cased, every non-alphanumeric → `_`
   (including the extension dot: `logo.png` → `img_logo_png`):
   ```json
   { "id": "img_logo_png", "name": "logo.png", "relativePath": "img\\logo.png", "embeddedHex": "" }
   ```
3. On the EImage **both** fields (Designer writes both; preview resolves `picturePath` first):
   ```json
   "pictureName": "id:img_logo_png", "picturePath": "img\\logo.png", "pictureHex": "", "scaleX": 1, "scaleY": 1
   ```
4. Screen background: `"backgroundImage": "id:img_logo_png"` (one reference is enough).

**Traps that produce a blank/garbled image:**
- `pictureName`'s `id:` must equal `resources.images[].id` exactly → otherwise a silent **placeholder**.
- Do not put a path into `pictureName`; a wrong `picturePath` shadows a correct `pictureName`.
- `relativePath` not relative to the project folder → placeholder.
- `scaleX/scaleY` always `1` — 0/missing hides or distorts the picture.
- Same image used at two different W×H → export writes `_WxH` suffixed raws; do not assume raw names.
- **CSS translucent panels/overlays must be baked into the PNG** — CSS layers are not converted; an
  EShape "panel" is invisible at runtime, the background looks "naked".
- Full-screen backgrounds exactly at device resolution; larger files only bloat the `.raw`.

## 4. Colour conversion (most frequent error)
- Property fields (`color`, `fontColor`, `backgroundColor` …): **signed 32-bit ARGB int**.
  `#RRGGBB` → `R*65536 + G*256 + B − 16777216`. `#FF0000` → `-65536`, `#FFFFFF` → `-1`, `#000000` → `-16777216`.
- CSS `rgba()` → alpha into the top byte `0xAARRGGBB` (only where alpha is supported, e.g. `EShape.fillColor`).
- **In event code** colours are strings: `btn.Color = "#FFAB00";`.
- **Measure colours from the rendered mockup pixels**, do not eyeball them. An HTML gradient that must
  become one AIRHMI colour → average of the gradient pixels.

## 5. Event code (C, compiled to PCC bytecode at export)
- `events`: `{ "onUp", "onDown", "onClick", "onPress" }` — omit empty ones. **Button actions on
  `onDown`** (responsive on the device); destructive actions on `onUp`.
- Page navigation (`<a href>` / JS) → `ChangeScreenSet("MainScreen");` (**not** `ScreenSet`).
- Functions: `script-api.md`. Start with `#include "stk.h"`.
- Screen start code → the screen's `onStart`; shared functions → `functions`.

## 6. Fonts / text
- Default font **Roboto** (built into the device); CSS `font-size` px → `fontSize` 1:1.
- **Text boxes get slack — tight fitting is forbidden:** width = longest expected text + ~20 % (≥ 10 px),
  height ≈ fontSize × 1.6. Draw the slack in the mockup already so the 1:1 coordinate copy carries it.
  (Simulator = GDI, device = emWin — metrics differ; tight boxes wrap or vanish on the device.)
- **Custom font = real TTF, not a guess:** any non-Roboto font needs `<FontName>.ttf` in the project
  (`fonts\<FontName>.ttf` or a `resources.fonts[]` entry with `relativePath`), `fontName` exactly the
  file stem. Designer 2.8+ copies it into the package and warns (`COMPONENT_FONT_FILE_MISSING`) when
  missing; otherwise the simulator silently draws Arial.
- `text-align` → `textAlignment` (`Center`, `Left`, `Right`). Scrolling text: `ELabelBox.scrollEnable`.

## 7. Constraints — what HTML can do and AIRHMI cannot
Do not use these in the mockup (dynamic elements):
- CSS shadow, blur, transition/animation (only EButton `effect` and EImage rotation exist)
- border-radius is not free — exception: **EButton `radius`** (px) and ProgressBar `Rounded`; assume
  square corners elsewhere
- No web fonts — Roboto or a TTF shipped with the project
- No flex/grid flow layout — absolute coordinates only
- No nested scroll areas (scrolling only inside EListView / EListWhell / EMenu / ELog)
- No translucent visual panels — EShape is not drawn at runtime; translucent decoration is designed
  **inside** the background PNG (alpha is composited over the screen background)
- No Unicode subscript/superscript characters in dynamic text (`CO₂` → `CO2`)

## 8. Bringing it alive — timers for live data (mandatory layer)
Every value that updates by itself (sensor, counter, clock, communication data) is driven by an
**ETimer**: screen-specific in `screens[].timers[]`, project-wide in `globalTimers[]`.

```json
{ "componentType": "ETimer", "name": "timerTemp", "ownerScreen": "MainScreen",
  "interval": 1000, "enabled": true,
  "event": "#include \"stk.h\"\ndouble a; int t;\nADC_Read(0, &a); t = a;   // real sensor on device\nlblTemp.Text = t;" }
```
- On the device the source is a real read (`ADC_Read`, `uartDataGet`, `GPIO_Read`,
  `ModbusTCP_ReadHoldingRegisters`, `SocketTCP_Read`, `TimeGet`); **in the simulator the board I/O is
  mocked** — the screen must still look alive. Network reads are real in the simulator: a PLC value
  (`ModbusTCP_ReadHoldingRegisters(1, 0, 1, v); lblTemp.Text = v[0];`) comes alive as soon as a Modbus
  TCP server (the PLC or a simulator on the PC) answers — `network-api.md` §4.
- Two ways to animate in the simulator (column "in simulator" of the behaviour plan):
  1. **Demo generation** — realistic drift inside the timer, replaced by the real read for the device:
     ```c
     #include "stk.h"
     int v;
     VarGet("demoTemp", &v);
     v = v + (rand() % 3) - 1;              // slow drift
     if (v < 20) v = 20; if (v > 28) v = 28;
     VarSeti("demoTemp", v);
     lblTemp.Text = v;
     ```
  2. **Socket injection** — the timer reads a project variable; `test-scenario.ps1` feeds it over TCP 8890
     (`demoTemp,25,,VarSet,,`) — preferred for scenario-controlled tests.
- Timer control from code: `timerTemp.Enable = 1;` / `timerTemp.Interval = 5000;`.
- Clock: minute timer + `TimeGet(&h,&mi);` → label (simulator: `timeSet` is a no-op but `TimeGet` works).
- ⚠️ Every numeric display on the screen needs one row in the behaviour plan — a live value without a
  timer shows up as a "dead screen" in the comparison.
- Screen entry: do not rely on `OnStart` or the first timer cycle to draw values — detect entry in the
  timer and re-write everything ~1 s later (`script-api.md` §1, screen-entry writes).

## 9. Post-conversion checklist
1. Every component: `componentType`, unique `name`, `ownerScreen`, `left/top/width/height`, `order`?
2. Colours int (properties) / `"#RRGGBB"` (code)?
3. `EListView` `listFile` present in `sd_card\`?
4. `scripts\lint-project.ps1` clean → `scripts\run-sim.ps1` → export `ok`, simulator title 2.x, log clean.
