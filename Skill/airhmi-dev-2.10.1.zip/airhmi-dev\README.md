# airhmi-dev — Claude Code skill for AIRHMI project development

Build AIRHMI touch-screen projects with Claude Code and the **installed AIRHMI Designer**:
idea → scenario → HTML mockup → `.airhmi.json` → event code → headless export → simulator test →
visual comparison → device (SD card / FTP).

## Requirements
- Windows 10/11, PowerShell 5.1+
- **AIRHMI Designer 2.9.4 or newer** installed (download: https://airhmi.com) for the full feature set
  (Video object, Modbus TCP / sockets, `Fs_*` files, Hardware / Startup Settings, VNC viewer). 2.8.x
  works without those; 2.7.x works too, but export needs one manual click per run.
- Claude Code (https://claude.com/claude-code). Any agent that reads `SKILL.md` can use the skill.
- Optional: Microsoft Edge (headless mockup screenshots), an AIRHMI device on the network (FTP) or an
  SD card reader.

## Install
1. Download `airhmi-dev-<version>.zip` from the releases page (or clone the repository).
2. Extract to `%USERPROFILE%\.claude\skills\airhmi-dev\` so that `SKILL.md` is directly inside that folder.
3. Start Claude Code in your project folder and say what you want, e.g.
   *"Create a 7-inch temperature/humidity panel for a greenhouse controller"* or
   *"AIRHMI projesi: 4.3 inç kahve makinesi ekranı yap"*.
   The skill answers in your language.

## Version compatibility
| Skill | Designer | Notes |
|---|---|---|
| 2.10.x | 3.5.0+ | Full + Log (`ELog`) and Menu (`EMenu`) objects (bundled simulator build 2026-10-27+, firmware V6.04 2026-10-27) |
| 2.9.x / 2.10.x | 2.9.4+ | Full: Video object, Modbus TCP / sockets, `Fs_*`, Hardware / Startup Settings, VNC viewer (no Log/Menu) |
| 2.9.x | 2.8.x | Headless export + font copy; the 2.9 features above are unavailable (the skill says so) |
| 2.9.x | 2.7.x | Manual Export in Designer; everything else automated |

Simulator: use **2.9.2 or newer** (comes with Designer setup 2.9.6). 2.9.0 reads project variables as 0;
2.9.1 and older lose some `Visible`/`Text` writes made right after re-entering a screen, lack `sscanf`, and stop
at start-up when a screen with a background image has an `EImage` at order 0.

`scripts\env-check.ps1` prints what it found and what is available.

## Folder layout
```text
airhmi-dev\
  SKILL.md              the workflow and rules Claude follows
  references\           widget reference, HTML→AIRHMI rules, script API, host protocol, socket, deploy, templates, examples
  scripts\              env-check, new-project, lint-project, run-sim, capture-sim, compare-shots, FTP, …
  CHANGELOG.md  VERSION  README.md
```

## Feedback / bugs
Platform problems (Designer, simulator, firmware): https://github.com/airhmi/AIRHMI/issues with the
repro package the skill prepares (`support\repro-<date>\`). Skill text improvements: same place, label `skill`.

## License
Same as the AIRHMI repository.
