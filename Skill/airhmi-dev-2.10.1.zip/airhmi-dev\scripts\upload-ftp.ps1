﻿<#
.SYNOPSIS  Uploads an export package to the AIRHMI device over FTP (single control session, incremental).
.DESCRIPTION
  Defaults (host, port, user, password, drive, dir) come from Designer's workspace-settings.json -> FtpDevice
  (read through env-check.ps1); any parameter overrides them. Remote target = <DeviceDrive>\<RemoteDir> (D:\prog).
  -Incremental sends only new/changed files (SHA-256 manifest in C:\Users\Public\airhmi\deploy-state\<ip>.json).
  -Restart restarts the device afterwards over port 80 and waits until it is back (restart-device.ps1).
.EXAMPLE
  .\upload-ftp.ps1 -SourceDir C:\Users\Public\airhmi\simulator -Incremental -Restart
  .\upload-ftp.ps1 -DeviceIp 192.168.2.150 -SourceDir C:\Users\Public\airhmi\simulator -ForceFull
#>
param(
  [string]$DeviceIp = '',
  [int]$Port = 0,
  [string]$SourceDir = 'C:\Users\Public\airhmi\simulator',
  [string]$UserName = '',
  [string]$Password = '',
  [string]$DeviceDrive = '',
  [string]$RemoteDir = '',
  [int]$TimeoutMs = 60000,
  [string]$StateDir = 'C:\Users\Public\airhmi\deploy-state',
  [string[]]$Exclude = @('socket_debug.log'),
  [switch]$Incremental,
  [switch]$ForceFull,
  [switch]$DryRun,
  [switch]$Restart
)


$ErrorActionPreference = 'Stop'
# Fill missing parameters from Designer's FtpDevice settings (workspace-settings.json), read-only.
. (Join-Path $PSScriptRoot 'env-check.ps1')
$airEnv = Get-AirHmiEnvironment
if (-not $DeviceIp)    { $DeviceIp = $airEnv.FtpHost }
if ($Port -le 0)       { $Port = $airEnv.FtpPort }
if (-not $UserName)    { $UserName = $airEnv.FtpUser }
if (-not $Password)    { $Password = $airEnv.FtpPassword }
if (-not $DeviceDrive) { $DeviceDrive = $airEnv.FtpDrive }
if (-not $RemoteDir)   { $RemoteDir = $airEnv.FtpDir }
if (-not $DeviceIp)    { throw 'Device IP unknown: pass -DeviceIp or set it once in Designer (File > Export to Device (FTP)).' }
if (-not $UserName)    { $UserName = 'admin' }
if (-not $Password)    { $Password = 'admin' }
$source = (Resolve-Path -LiteralPath $SourceDir).Path
# Root files the device reads at boot go LAST, files.ini (the package list) at the very end: an interrupted
# upload then leaves the old list in place instead of an empty files.ini that stops the device at start-up.
$bootLast = @('hw.cfg', 'init.pcc', 'logo.js', 'options.ini', 'files.ini')
$bootRank = { if ($_.DirectoryName.TrimEnd('\') -eq $source.TrimEnd('\')) { [array]::IndexOf($bootLast, $_.Name.ToLowerInvariant()) } else { -1 } }
$allFiles = @(Get-ChildItem -LiteralPath $source -Recurse -File | Sort-Object @{ Expression = $bootRank }, FullName)
if ($allFiles.Count -eq 0) { throw "No files to upload: $source" }

$items = @()
$excludedCount = 0
foreach ($file in $allFiles) {
  $relative = $file.FullName.Substring($source.Length).TrimStart('\')
  $excluded = $false
  foreach ($pattern in $Exclude) {
    if ($relative -like $pattern -or $file.Name -like $pattern) { $excluded = $true; break }
  }
  if ($excluded) { $excludedCount++; continue }
  $items += [pscustomobject]@{
    File = $file
    Path = $relative.Replace('\','/')
    Directory = [IO.Path]::GetDirectoryName($relative)
    Bytes = $file.Length
    SHA256 = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash
  }
}
if ($items.Count -eq 0) { throw 'All source files are excluded' }

$stateName = ($DeviceIp -replace '[^A-Za-z0-9_.-]','_') + '.json'
$stateFile = Join-Path $StateDir $stateName
$previous = @{}
$stateWasMissing = -not (Test-Path -LiteralPath $stateFile)
if ($Incremental -and -not $ForceFull -and -not $stateWasMissing) {
  $saved = Get-Content -Raw -Encoding UTF8 -LiteralPath $stateFile | ConvertFrom-Json
  foreach ($entry in $saved.files) { $previous[[string]$entry.path] = [string]$entry.sha256 }
}

if ($Incremental -and -not $ForceFull) {
  $uploadItems = @($items | Where-Object { -not $previous.ContainsKey($_.Path) -or $previous[$_.Path] -ne $_.SHA256 })
} else {
  $uploadItems = @($items)
}
$unchanged = $items.Count - $uploadItems.Count
$sourceBytes = ($items | Measure-Object Bytes -Sum).Sum
$uploadBytes = ($uploadItems | Measure-Object Bytes -Sum).Sum

if ($DryRun) {
  Write-Output ([pscustomobject]@{
    DeviceIp=$DeviceIp; Target="$DeviceDrive\$RemoteDir"; Total=$items.Count; Changed=$uploadItems.Count
    Unchanged=$unchanged; Excluded=$excludedCount; Bytes=$sourceBytes; UploadBytes=$uploadBytes
    Incremental=[bool]$Incremental; ForceFull=[bool]$ForceFull; StateFile=$stateFile; StateMissing=$stateWasMissing
  })
  return
}

if ($uploadItems.Count -eq 0) {
  Write-Output ([pscustomobject]@{
    Target="${DeviceIp}:$Port/$DeviceDrive/$RemoteDir"; Total=$items.Count; Changed=0; Uploaded=0
    Unchanged=$unchanged; Excluded=$excludedCount; Failed=0; Bytes=0; Seconds=0; StateFile=$stateFile
  })
  if ($Restart) { & (Join-Path $PSScriptRoot 'restart-device.ps1') -DeviceIp $DeviceIp }
  return
}

$control = [Net.Sockets.TcpClient]::new()
$control.ReceiveTimeout = $TimeoutMs
$control.SendTimeout = $TimeoutMs
$control.Connect($DeviceIp, $Port)
$stream = $control.GetStream()
$reader = [IO.StreamReader]::new($stream, [Text.Encoding]::ASCII)
$writer = [IO.StreamWriter]::new($stream, [Text.Encoding]::ASCII)
$writer.NewLine = "`r`n"
$writer.AutoFlush = $true

function Read-FtpReply {
  $lines = [Collections.Generic.List[string]]::new()
  $line = $reader.ReadLine()
  if ($null -eq $line) { throw 'FTP control connection closed' }
  $lines.Add($line)
  if ($line -match '^(\d{3})-') {
    $code = $matches[1]
    do {
      $line = $reader.ReadLine()
      if ($null -eq $line) { throw 'FTP multiline reply interrupted' }
      $lines.Add($line)
    } while ($line -notmatch ("^" + $code + " "))
  }
  return ($lines -join ' | ')
}

function Send-FtpCommand([string]$Command, [string]$ExpectedCode) {
  $writer.WriteLine($Command)
  $reply = Read-FtpReply
  if ($reply -notmatch ("^" + $ExpectedCode)) { throw "$Command => $reply" }
  return $reply
}

function Enter-RemotePath([string]$RelativeDirectory) {
  [void](Send-FtpCommand 'CWD /' '250')
  [void](Send-FtpCommand "CWD $DeviceDrive" '250')
  $segments = @($RemoteDir) + @(($RelativeDirectory -split '[\\/]' | Where-Object { $_ }))
  foreach ($segment in $segments) {
    $writer.WriteLine("CWD $segment")
    $reply = Read-FtpReply
    if ($reply -notmatch '^250') {
      [void](Send-FtpCommand "MKD $segment" '257|250')
      [void](Send-FtpCommand "CWD $segment" '250')
    }
  }
}

$uploaded = 0
$uploadedBytes = 0L
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
try {
  $banner = Read-FtpReply
  if ($banner -notmatch '^220') { throw $banner }
  [void](Send-FtpCommand "USER $UserName" '331')
  [void](Send-FtpCommand "PASS $Password" '230')
  [void](Send-FtpCommand 'TYPE I' '200')

  $currentDirectory = $null
  foreach ($item in $uploadItems) {
    $file = $item.File
    $relative = $item.Path
    $relativeDirectory = $item.Directory
    if ($relativeDirectory -ne $currentDirectory) {
      Enter-RemotePath $relativeDirectory
      $currentDirectory = $relativeDirectory
    }

    $pasv = Send-FtpCommand 'PASV' '227'
    if ($pasv -notmatch '\((\d+),(\d+),(\d+),(\d+),(\d+),(\d+)\)') { throw "Bad PASV reply: $pasv" }
    $dataPort = ([int]$matches[5] * 256) + [int]$matches[6]
    $data = [Net.Sockets.TcpClient]::new()
    $data.SendTimeout = $TimeoutMs
    $data.Connect($DeviceIp, $dataPort)

    $writer.WriteLine('STOR ' + $file.Name)
    $start = Read-FtpReply
    if ($start -notmatch '^150') { $data.Close(); throw "STOR $relative => $start" }
    $dataStream = $data.GetStream()
    $fileStream = [IO.File]::OpenRead($file.FullName)
    try {
      $fileStream.CopyTo($dataStream)
      $dataStream.Flush()
    } finally {
      $fileStream.Dispose()
      $dataStream.Dispose()
      $data.Close()
    }
    $done = Read-FtpReply
    if ($done -notmatch '^226') { throw "STOR complete $relative => $done" }

    $uploaded++
    $uploadedBytes += $file.Length
    if (($uploaded % 50) -eq 0 -or $uploaded -eq $uploadItems.Count) {
      Write-Host "FTP progress: $uploaded/$($uploadItems.Count)"
    }
  }
  [void](Send-FtpCommand 'QUIT' '221')
} finally {
  $control.Dispose()
  $stopwatch.Stop()
}

$manifest = [ordered]@{
  version = 1
  recordedAt = [DateTime]::UtcNow.ToString('o')
  deviceIp = $DeviceIp
  target = "$DeviceDrive\$RemoteDir"
  source = $source
  files = @($items | ForEach-Object { [ordered]@{path=$_.Path;bytes=$_.Bytes;sha256=$_.SHA256} })
}
New-Item -ItemType Directory -Force -Path $StateDir | Out-Null
$tempState = $stateFile + '.tmp'
[IO.File]::WriteAllText($tempState, ($manifest | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))
Move-Item -LiteralPath $tempState -Destination $stateFile -Force

[pscustomobject]@{
  Target = "${DeviceIp}:$Port/$DeviceDrive/$RemoteDir"
  Total = $items.Count
  Changed = $uploadItems.Count
  Uploaded = $uploaded
  Unchanged = $unchanged
  Excluded = $excludedCount
  Failed = $uploadItems.Count - $uploaded
  Bytes = $uploadedBytes
  Seconds = [math]::Round($stopwatch.Elapsed.TotalSeconds, 1)
  StateFile = $stateFile
}
if ($Restart) { & (Join-Path $PSScriptRoot 'restart-device.ps1') -DeviceIp $DeviceIp }
