# Video object (`EVideo`) — canvas video with poster, converted at export

> Since Designer 2.9.4 / firmware V6.04 / simulator 2.9.4 the Video is a **canvas object**: it sits at
> `left/top/width/height` like a button, shows a **poster frame** when the screen opens and plays
> **inside its own rectangle** when code starts it. You add an ordinary MP4 to the project; Designer
> converts it to the device movie format (`.emf`, motion-JPEG at the object's size) at export. No
> external tool, no manual conversion. Older Designers treated Video as a tray item that copied the
> raw file — that path is gone.

## 1. Workflow
1. **Resource**: Designer `Resources > Add Video` (or by hand): the file is copied to `<project>\videos\`
   and listed in `resources.videos[]`. Tested: **MP4 / H.264**. AVI, MOV, MKV are accepted when Windows
   can decode them (Windows Media Foundation; HEVC needs the Store "HEVC Video Extensions" — when a
   file cannot be decoded Designer still imports it and shows a film icon; export then fails with an
   explanation). Prepare the clip **at the object's resolution** beforehand (a 1080p source into a
   400×240 object only costs conversion time; it is scaled anyway).
2. **Object**: toolbox *Media → Video*, place it, size it (**even width/height**, fully on screen),
   set `fileName` to the resource file name, choose `fps`, `quality`, `loop`, `autoPlay`, `posterTimeMs`.
3. **Code**: `Video_Play("<objectName>", 100);` in a button `onDown`, `VideoPause()/VideoContinue()/
   VideoStop()`, progress from `Video_ElapsedGet()/Video_DurationGet()` in a timer (§4).
4. **Export**: Designer converts the source to `<Screen>_<Name>.emf` + `<Screen>_<Name>_poster.raw|jpg`
   (poster at the object's size), lists both in `files.ini`; the raw MP4 is **not** copied. The first
   export of a clip takes seconds to a few minutes (progress overlay in Designer; headless export prints
   progress lines to stderr / `outputLines`); later exports copy from the cache
   (`%LOCALAPPDATA%\AIRHMI\cache\video\`, movable with the `AIRHMI_VIDEO_CACHE_DIR` environment
   variable). Designer also pre-converts in the background as soon as the source or `fps/quality/W/H/
   posterTimeMs` changes (status bar "Converting video … in background").
5. **Simulator**: plays the `.emf` in the object's rectangle with the same functions (log
   `C:\Users\Public\airhmi\video_debug.log`). `capture-sim.ps1` (PrintWindow) captures the poster, not
   the running frames — capture while stopped.
6. **Device**: the `.emf` goes with the package to `D:\prog` (FTP or SD). FTP: Designer's window skips
   `.emf` files that did not change since the last upload to that device (manifest in
   `%LOCALAPPDATA%\AIRHMI\deploy-state\`); tick **Resend unchanged video files** to force. Serial/YMODEM
   (~11 KB/s) is impractical for videos — a 20 MB movie takes half an hour.

## 2. JSON (component in `screens[].components[]`)
```json
{
  "componentType": "EVideo",
  "name": "vidIntro", "ownerScreen": "MainScreen",
  "left": 200, "top": 80, "width": 400, "height": 240,
  "order": 5, "visible": true,
  "fileName": "intro.mp4",
  "mediaPath": "",
  "fps": 15, "quality": 5,
  "loop": false, "autoPlay": false,
  "volume": 100, "posterTimeMs": 0,
  "storage": "SD", "controlSetting": false
}
```
| Field | Type / range | Default | Meaning |
|---|---|---|---|
| `fileName` | string | "" | File name of the `resources.videos[]` entry (`intro.mp4`) |
| `mediaPath` | string | "" | Leave empty. A legacy `.ahi` import sets it to a ready-made `.emf`: that file is copied unchanged, W/H come from its header, no conversion |
| `fps` | int **5–30** | 15 | Conversion frame rate (source is resampled). 15 is the size/smoothness sweet spot |
| `quality` | int **1–31** | 5 | JPEG quality of the frames, **1 = best / largest**, 31 = smallest |
| `loop` | bool | false | Restart at the end |
| `autoPlay` | bool | false | Start when the screen opens (after it is drawn). **At most one per screen** |
| `volume` | int 0–100 | 100 | Reserved — **no audio in this version** (written to the package, not used) |
| `posterTimeMs` | int | 0 | Time of the poster frame (shown while not playing) |
| `storage`, `controlSetting` | legacy | `SD`, false | Ignored; the movie always travels with the package to `D:\prog`. Keep the defaults |

Resource entry (`resources.videos[]`):
```json
{ "id": "video_intro", "name": "intro.mp4", "relativePath": "videos\\intro.mp4", "embeddedHex": "" }
```
`upload.startVideoStorage` in the project root is the **boot splash video** setting of the device and has
nothing to do with Video objects.

## 3. Rules and limits (validation codes in `export-result.json → validation.issues[]`)
| Rule | Code | Severity |
|---|---|---|
| Resource file exists / is referenced | `VIDEO_FILE_MISSING` / `VIDEO_RESOURCE_UNUSED` | error / warning |
| `width`/`height` even (JPEG 4:2:0; export rounds down) | `VIDEO_SIZE_ODD` | warning |
| No other visual object inside the video rectangle — the frames are drawn **on top of everything** while playing; put Play/Pause buttons beside the video | `VIDEO_OVERLAP` | warning |
| One `autoPlay` per screen | `VIDEO_MULTI_AUTOPLAY` | warning |
| Object name usable as a file name (it becomes `<Screen>_<Name>.emf`) | `VIDEO_NAME_NOT_FILESAFE` | error |
| `fps` 5–30, `quality` 1–31 | `VIDEO_FPS_OUT_OF_RANGE` / `VIDEO_QUALITY_OUT_OF_RANGE` | error |
| Estimated movie size: **> 20 MB warning, > 200 MB error** | reported by the converter at export | — |

- **One video plays at a time** on the device (several Video objects per screen are fine, up to 8).
- **Leaving the screen stops the video**; `ChangeScreenSet` always lands on a fully drawn screen.
- The Video object has **no events**. While nothing plays, touches inside its rectangle go to objects
  underneath — but that layout triggers `VIDEO_OVERLAP`; design the controls next to the video.
- Size budget, quality 5: 400×240 @ 15 fps, 30 s ≈ **4 MB**; 800×480 @ 15 fps, 60 s ≈ **20 MB**. Keep
  intros short and the object small; fullscreen 800×480 at 25 fps is ~30 KB per frame and only worth it
  for short clips.
- Dot syntax: only `vidIntro.Visible = 0;` / `v = vidIntro.Visible;` (hide = poster hidden **and**
  playback stopped; show = poster back). Everything else goes through the functions below.

## 4. Functions (verified signatures)
```c
Video_Play("vidIntro", 100);          // object name → file, position, size, loop come from the object
Video_Play("intro.mp4", 100);         // not an object name → treated as a file name (legacy path)
Video_Play_XY("clip.emf", 100, 0, 0); // file at given coordinates (an object name uses the object's position)
VideoPause();                         // last frame stays on screen
VideoContinue();
VideoStop();                          // poster is shown again
int st  = Video_StatusGet();          // 1 while playing OR paused, 0 otherwise
int dur = Video_DurationGet();        // ms, 0 when nothing is loaded
int el  = Video_ElapsedGet();         // ms
vidIntro.Visible = 0;                 // dot syntax (old code: VideoSet("vidIntro","Visible","0"))
```
`VideoPlay` / `VideoPlayXY` (old spellings) are rewritten to `Video_Play` / `Video_Play_XY` at export.
`Video_StatusGet` cannot tell "paused" from "playing" — keep your own flag (variable) when a single
Play/Pause button toggles.

**Cookbook**
```c
// btnPlay_OnDown.c — toggle play/pause with an int variable "vidPaused"
#include "stk.h"
int paused;
VarGeti("vidPaused", &paused);
if (Video_StatusGet() == 0)      { Video_Play("vidIntro", 100); VarSeti("vidPaused", 0); btnPlay.Text = "PAUSE"; }
else if (paused == 0)            { VideoPause();    VarSeti("vidPaused", 1); btnPlay.Text = "PLAY"; }
else                             { VideoContinue(); VarSeti("vidPaused", 0); btnPlay.Text = "PAUSE"; }

// btnStop_OnDown.c
#include "stk.h"
VideoStop(); VarSeti("vidPaused", 0); btnPlay.Text = "PLAY";

// tmrVideo_Event.c (500 ms) — time label + progress bar; also resets the button at the natural end
#include "stk.h"
#include "stdio.h"
int dur, el; char b[32];
dur = Video_DurationGet(); el = Video_ElapsedGet();
if (Video_StatusGet() == 1 && dur > 0) {
    sprintf(b, "%d:%02d / %d:%02d", el / 60000, (el / 1000) % 60, dur / 60000, (dur / 1000) % 60);
    lblTime.Text = b;
    pbVideo.Value = el * 100 / dur;
} else { btnPlay.Text = "PLAY"; pbVideo.Value = 0; }
```
Intro screen pattern: `autoPlay=true`, `loop=false`, a global timer polls `Video_StatusGet()` and calls
`ChangeScreenSet("MainScreen")` when it drops to 0 (or a "Skip" button next to the video does it).

## 5. Mockup → object
In the HTML mockup draw the video area as a `<div data-dynamic>` with the poster as background image
(same W×H as the object, even numbers) and a centred play icon; convert it 1:1 to the `EVideo` with
`posterTimeMs` chosen so the poster matches the mockup. Controls (Play/Pause/Stop, time label,
progress bar) are separate widgets outside the rectangle.

## 6. Troubleshooting
| Symptom | Cause / fix |
|---|---|
| Canvas shows "No video" / film icon | Source not decodable on this PC (codec) or `fileName` not in `resources.videos[]` |
| Export takes minutes, Designer shows a progress overlay | First conversion of a long/large clip; Cancel stops the export. Lower `fps`/size or wait; later exports use the cache |
| `Video_Play` does nothing on the device | Name spelled differently from the object (case-sensitive) → falls back to a file name that does not exist; or the `.emf` was not uploaded (FTP skipped it? check `files.ini` vs card) |
| Black remnant after Stop | Known cosmetic firmware issue; redraw happens on the next screen change |
| Simulator screenshot shows only the poster | Expected — PrintWindow does not capture the running frames |
