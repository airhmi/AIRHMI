# Host side — talking to the screen from your own board

> An AIRHMI screen runs on its own; a host board (PLC, MCU, Arduino, PC) is optional. Two ways to
> connect: the **UART text protocol** (any board, no library) and the **AIRDUINO library** (Arduino
> ecosystem). The project's `host.target` only switches Designer's helpers on/off (`None` /
> `CustomUart` / `Airduino`); design, export and simulator are the same in all three.

## 1. Which one?
| Situation | Choose | Why |
|---|---|---|
| Screen is self-sufficient (touch control + GPIO from screen code) | `None` | hardware functions run on the screen itself (`script-api.md` §6) |
| Own board / PLC / any UART device | `CustomUart` | line-based text protocol, testable from a serial terminal, ~40-line parser |
| Arduino / AIRDUINO board | `Airduino` | ready classes, Designer validates object names against the `.ino` |

The design rule that matters for the host: **component `name` is the protocol identity**. Renaming a
component later means changing host firmware too — fix names in the scenario stage.

## 2. UART text protocol (`CustomUart`)

### Physical layer
| Item | Value |
|---|---|
| Line | UART TTL (RS232/RS485 converters are transparent) |
| Default | **115200 baud, 8N1** |
| Charset | UTF-8 |
| Line end | `\n` (`\r\n` accepted) |
| Max line | 512 bytes (longer → dropped + `!sys.err=linetoolong`) |
| Case | component/property names compared case-insensitively; replies echo the Designer spelling |

### Grammar — four line kinds
```text
write  :  name.Property=value          host → screen   (silent by default)
read   :  ?name.Property               host → screen   (reply names itself)
event  :  !name.Event[=value]          screen → host   (spontaneous, after sys.events=1)
error  :  !sys.err=code[:detail]
ack    :  ok | ok:n                    (only with sys.ack=1)
```
Values: numbers (`26`, `-3`, `12.5`), booleans `0`/`1`, free text to end of line, quoted text with
escapes `"line1\nline2"` (the wire never carries a real newline inside a value), colours `#RRGGBB` or int.

### Writes (host → screen)
```text
lblStatus.Text=Running
pbProgress.Value=75
gTemperature.Value=42
btnStart.Visible=0
sldSpeed.Value=30
tglPump.State=1
tmrPoll.Interval=500
tmrPoll.Enabled=1
varSetpoint.Value=55.5
graph1.Add=42
log1.Append=Alarm acknowledged      (ELog, 3.5.0+: one line; log1.Clear=1 empties it; ?log1.LineCount)
menu1.SelPos=1                      (EMenu, 3.5.0+: select from the host; menu1.Items=A;B;C; ?menu1.SelVal)
screen=SettingsScreen
```
- The writable property set is **the same as the C `XxxSet` surface** (`script-api.md` §1 table);
  property names are passed through, aliases like `Text`/`Caption`, `Enabled`/`Enable` work.
- Writes are silent unless `sys.ack=1`; errors always come back as `!sys.err`.
- A host write **never produces an event** (no echo storms).

### Reads (host → screen → host)
```text
Host  → ?gTemperature.Value
Screen→ gTemperature.Value=42
```
Replies come back in FIFO order (pipelining allowed); events may interleave — the parser decides by
the first character (`!` = event/error, otherwise = reply). Unknown name → `!sys.err=unknown:gTemp.Value`
instead of silence. Suggested host timeout: 100 ms.

### Events (screen → host)
Off by default; the host enables them once with `sys.events=1`.
| Line | When |
|---|---|
| `!btnStart.Down` / `!btnStart.Up` | touch press / release (also images, shapes) |
| `!sldSpeed.Change=75` | slider released — last value is inside the event |
| `!tglPump.Change=1` | toggle changed by the user |
| `!listMenu.Change=3` | list selection changed |
| `!sys.screen=SettingsScreen` | active screen changed (touch, C code or host command) |
| `!sys.ready=1` | screen booted and accepts commands — **watch this to detect screen resets** |

Per-component muting: `sldSpeed.Report=0`. Rapid slider changes are rate-limited (~50 ms, last value guaranteed).

### `sys.*`
| Command / query | Effect |
|---|---|
| `?sys.proto` → `sys.proto=1` · `?sys.ver` · `?sys.model` | protocol / firmware / model (read-only) |
| `?sys.screen` / `sys.screen=X` (`screen=X`) | read / change the active screen |
| `sys.events=1` | enable event lines |
| `sys.ack=1` | every successful write answers `ok` (`#17:pb.Value=5` → `ok:17`) |
| `sys.crc=1` | NMEA-style `*XX` XOR checksum on every line (both directions) |
| `sys.bright=80` · `sys.sleep=1` · `sys.beep=100` · `sys.baud=115200` · `sys.reset=1` | where the firmware supports them |

Error codes: `unknown`, `type`, `range`, `readonly`, `linetoolong`, `crc`, `parse`, `busy`.

### Connection life cycle
```text
1. screen boots            → !sys.ready=1
2. host → ?sys.proto       ← sys.proto=1          (version handshake)
3. host → sys.events=1                             (if events are wanted)
4. host → ?<critical values>                       (start-up sync)
5. normal flow: writes + events + rare reads
```
Host reset: ask `?sys.proto`, resync. Screen reset: the host sees `!sys.ready=1` and resyncs.

### Minimal host loop (any C-like firmware)
```c
uart_init(115200);
uart_println("sys.events=1");
while (1) {
    char *line = uart_readline();            // up to '\n'
    if (line[0] == '!') handle_event(line);  // "!btnStart.Up", "!sldSpeed.Change=75", "!sys.err=..."
    else handle_reply(line);                 // answer to a pending "?name.Prop"
    if (tick_100ms) {
        uart_printf("gTemperature.Value=%d\n", read_temp());
        uart_printf("lblStatus.Text=%s\n", status_text());
    }
}
```

### Legacy formats still accepted on the same line
`fn("p1","p2");` function-call lines (`LabelSet("lblA","Text","7");`, `ChangeScreenSet("Main");`) and
the comma wire format keep working next to the text protocol. New hosts should use the text protocol.
Lines with a comma before `=` are treated as the old comma format — avoid commas in names/properties.

### Testing without a device
- **Simulator socket 8890** accepts the same lines: `Send-Hmi 'lblStatus.Text=Running'`,
  `Send-Hmi '?gTemperature.Value'` (`simulator-socket.md`). Events are not pushed over the one-shot
  socket; verify them with the serial terminal on the device.
- **Designer Serial Terminal** (View menu or `--show-serial-terminal`): type protocol lines by hand to a
  connected device, watch events. The `test-scenario.ps1` of a host project should include at least one
  write, one read and one event check (device) per critical value.

## 3. AIRDUINO (Arduino)

1. Library: `https://github.com/airhmi/AIRHMI` (Arduino library + examples); add to the Arduino IDE.
2. Wire the screen and the board over UART, same baud on both sides.
3. Project `host.target = Airduino`; Designer then validates names between the `.ino` and the project.

**Name matching is everything:** the object name in the sketch equals the component `name`.
```c
AirButton bStart    = AirButton("bStart");     // Designer: name=bStart
AirLabel  lblStatus = AirLabel("lblStatus");

void onStartPop() {                            // called when bStart is released
    machine_start();
    lblStatus.setText("Running");
}
void setup() {
    // AIRDUINO init + baud (same as the screen)
    bStart.attachPop(onStartPop);              // attachPush = press, attachPop = release
}
void loop() {
    AirProgressBar("pbProgress").Set_Value(machine_progress());
    AirGauge("gTemp").Set_value(read_temperature());
}
```
| Component | Class | Typical methods |
|---|---|---|
| Button | `AirButton` | `attachPush`, `attachPop` |
| Label / LabelBox | `AirLabel` | `setText` |
| Image | `AirPicture` | picture / rotation |
| Slider / Gauge / ProgressBar | `AirSlider` / `AirGauge` / `AirProgressBar` | `Set_Value` |
| Graph | `AirGraph` | `addValue`, `clear` |
| Variable | `AirVariable` | int/float/string set-get |
| Timer | `AirTimer` | interval / enable |
| Screen | `AirPage` | `ChangeScreen` |
Helpers: `AirGpio`, `AirRtc`, `AirBuzzer`.

Designer helpers in `Airduino` mode: **Open INO**, auto "listen list" for touchable components, callback
stubs for Button/Toggle, Validate warnings for name mismatches. The three classic warnings are all name
mismatches; the fix is always to make both sides identical and re-run Validate. Baud mismatch is the
number-one cause of "nothing happens".

## 4. Design checklist for host projects (add to SCENARIO.md §5)
- For every live value: direction (host→screen write / screen→host event / host read), period, owner.
- Which touches must reach the host (events) and which are handled on the screen only.
- Start-up sync list (what the host writes right after `!sys.ready=1`).
- Error display on the screen when the host is silent (watchdog timer + "no communication" label).
