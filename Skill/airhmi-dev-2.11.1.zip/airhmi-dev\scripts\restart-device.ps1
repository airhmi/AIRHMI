﻿<#
.SYNOPSIS  Restarts the AIRHMI device over the network (port 80 command) and waits until it is back.
.DESCRIPTION
  Sends `WDT_SoftReset();` to the device's command port 80, then waits for the port to CLOSE and to OPEN again,
  plus a settle time so the project is loaded. No power cycle and no user action needed.
  Firmware from 2026-11-07 resets within ~1 s and is back on the network ~10 s later (total ~15 s with the settle
  time). Older firmware waits for its watchdog first: the old session stays open 20-24 s, then ~10-40 s to come
  back (~70 s total). "Closed" means 4 consecutive failed connects: a single failure right after the command is
  only port 80 being busy for a moment, not the reset.
  The device IP defaults to Designer's FTP device setting (workspace-settings.json -> FtpDevice, via env-check.ps1).
.EXAMPLE
  .\restart-device.ps1
  .\restart-device.ps1 -DeviceIp 192.168.2.150 -SettleSec 20
#>
param(
  [string]$DeviceIp = '',
  [int]$Port = 80,
  [int]$DownTimeoutSec = 60,
  [int]$UpTimeoutSec = 120,
  [int]$SettleSec = 5,
  [switch]$NoWait
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'env-check.ps1')
if (-not $DeviceIp) { $DeviceIp = (Get-AirHmiEnvironment).FtpHost }
if (-not $DeviceIp) { throw 'Device IP unknown: pass -DeviceIp or set it once in Designer (File > Export to Device (FTP)).' }

function Test-Port([int]$WaitMs) {
  $c = [Net.Sockets.TcpClient]::new()
  try { $iar = $c.BeginConnect($DeviceIp, $Port, $null, $null); return ($iar.AsyncWaitHandle.WaitOne($WaitMs) -and $c.Connected) }
  catch { return $false }
  finally { $c.Close() }
}

if (-not (Test-Port 3000)) { throw "Device ${DeviceIp}:$Port does not answer - check the network / IP (Designer Hardware settings)." }
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
$c = [Net.Sockets.TcpClient]::new()
$c.Connect($DeviceIp, $Port)
$bytes = [Text.Encoding]::ASCII.GetBytes('WDT_SoftReset();')
$c.GetStream().Write($bytes, 0, $bytes.Length)
Start-Sleep -Milliseconds 300
$c.Close()
Write-Host "Restart sent to ${DeviceIp}:$Port (WDT_SoftReset)."
if ($NoWait) { return }

# 1) port must go DOWN first - otherwise the still-open old session looks like "device ready".
#    4 consecutive failed connects = down (one failure is just port 80 busy for a moment after the command).
$deadline = (Get-Date).AddSeconds($DownTimeoutSec); $wentDown = $false; $fails = 0
while ((Get-Date) -lt $deadline) {
  if (Test-Port 500) { $fails = 0 } else { $fails++; if ($fails -ge 4) { $wentDown = $true; break } }
  Start-Sleep -Milliseconds 200
}
if (-not $wentDown) { Write-Warning "Port $Port stayed open for $DownTimeoutSec s - the device may not have restarted." }

# 2) port UP again, then settle while the project loads
$deadline = (Get-Date).AddSeconds($UpTimeoutSec); $up = $false
while ((Get-Date) -lt $deadline) { if (Test-Port 2000) { $up = $true; break }; Start-Sleep -Seconds 2 }
if (-not $up) { throw "Device did not come back on port $Port within $UpTimeoutSec s." }
Start-Sleep -Seconds $SettleSec
$stopwatch.Stop()

[pscustomobject]@{
  Device = "${DeviceIp}:$Port"
  WentDown = $wentDown
  Back = $up
  Seconds = [math]::Round($stopwatch.Elapsed.TotalSeconds, 1)
}
