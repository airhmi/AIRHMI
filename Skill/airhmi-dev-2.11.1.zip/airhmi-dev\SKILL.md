---
name: airhmi-dev
description: >
  Build AIRHMI touch-screen (HMI) projects with the installed AIRHMI Designer: idea → scenario →
  HTML mockup → .airhmi.json project → event code (dot syntax only, `label1.Text = "Ready";`)
  → headless export → simulator test (socket 8890) → mockup-vs-simulator visual
  comparison → device (SD card / FTP / VNC check). Covers Modbus TCP and TCP/UDP sockets, Fs_* files,
  the Video object (MP4 converted at export), Hardware / Startup Settings, old .ahi migration and the
  host side (UART text protocol / AIRDUINO). Use when the user wants to design, create, convert, code,
  test or deploy an AIRHMI screen/project, or says "AIRHMI", "HMI screen", "Designer project",
  ".airhmi.json", ".ahi", "simulator", "export to device", "SD card", "FTP upload", "mockup", "Modbus",
  "PLC screen", "video", "ekran tasarla", "AIRHMI projesi", "eski proje", "simülatör", "cihaza gönder".
  Requires AIRHMI Designer to be installed (3.5.0+ for the Log and Menu objects; 2.9.4+ for the rest of
  the feature set; 2.8.0+ for automated export; 2.7.x works with one manual Export click). Does NOT modify Designer/simulator/firmware
  source — platform bugs are reported, not patched.
---

# AIRHMI project development (installed Designer)

You are helping a developer build a project for an AIRHMI touch display. Your only tools are the
**installed AIRHMI Designer** (`%LOCALAPPDATA%\Programs\AIRHMI Designer\`), its bundled simulator,
this skill's references and scripts, and the user's project folder. Nothing in this skill depends
on AIRHMI source code or on the vendor's internal files.

**Answer in the user's language.** The skill text is English; the conversation is not.

## Precedence
If rules conflict, **the most specific rule wins**; if still unclear, ask the user. The parenthesis
at the end of a rule is its reason — keep it when you quote the rule.

## Working style (always)
1. **Before every tool call say in 1-2 sentences what you are about to do and why.** No silent chains.
2. **Announce expected duration for anything over ~30 s** (headless export 3-10 s, simulator start
   ~5 s, mockup render ~5 s, FTP upload depends on size; a few MB takes a minute).
3. **Long jobs run detached** (`Start-Process ... -RedirectStandardOutput`) and are polled; never
   block the foreground with `sleep` loops (tool timeout 10 min).
4. **Scope: do the requested change, then STOP.** Side findings get one line ("X has the same
   problem — want me to look?") and wait for an answer. Do not spread to other screens/files or
   open extra analyses (multi-language, other products, pixel audits) on your own.
5. **Project docs (ROADMAP/DECISIONS/SCENARIO) are updated at approval points**, not after every
   edit. Intermediate steps change only code/JSON/HTML.
6. **Never write into the Designer install folder.** Writable places: the project folder,
   `C:\Users\Public\airhmi\simulator` (export), `C:\Users\Public\airhmi\sd_card` (simulator SD root).
7. **Do not "fix" `componentType` spellings** — `EListWhell`, `EveGauge`, `EveSlider`,
   `EveProgressBar` are intentional and must match the firmware byte for byte.
8. **No stage is skipped without the user's explicit approval** (mockup approval before conversion;
   clean export before any "it works" claim; visual comparison before deployment).

## References and scripts (all inside this skill — no external documents needed)
| File | Use it for |
|---|---|
| `references/ide-inventory.md` | What the installed Designer contains, paths, command-line switches, `workspace-settings.json`, version table, user-guide chapter map |
| `references/widget-reference.md` | Every component type: JSON fields + defaults, project root/screen skeletons, colour format |
| `references/html-to-airhmi.md` | Mockup rules, layering (bake static → background, dynamic → widgets), element→widget mapping, image recipe, constraints, timers |
| `references/script-api.md` | Event code: project code layout (files, Screen Functions, timers), C subset limits, dot syntax, verified signatures, traps, simulator mocks, cookbook, catalog |
| `references/network-api.md` | Ethernet / TCP-UDP sockets / HTTP / Modbus TCP functions with return codes, Hardware & Startup Settings (`hardware` JSON block → `init.pcc` + `hw.cfg`), PLC polling patterns, traps |
| `references/file-api.md` | `Fs_*` file functions (flash `C:` / SD `D:`), path and return rules, recipes, timings, simulator mapping, `File_*` migration |
| `references/video-object.md` | Video canvas object: MP4 resource → `.emf` at export, JSON fields (`fps`, `quality`, `loop`, `autoPlay`, `posterTimeMs`), play/pause/stop/progress functions, size budget, validation codes |
| `references/host-protocol.md` | Host board side: UART text protocol (`name.Prop=value`, `?name.Prop`, `!events`, `sys.*`), AIRDUINO library, host project checklist |
| `references/legacy-ahi-migration.md` | Old `.ahi` projects: headless conversion (`--open-project X.ahi --validate-out`), what changes, post-import checklist |
| `references/simulator-socket.md` | TCP 8890 test interface: formats, `Touch`, `Var*` comma format, debugger `Dbg*` |
| `references/device-deploy.md` | SD card layout, Designer FTP window, `upload-ftp.ps1`, serial `ScreenCapture` → `download-ftp.ps1` |
| `references/design-tokens.css`, `references/examples/` | Mockup styling tokens and approved example designs to imitate |
| `references/templates/` | `SCENARIO.md`, `ROADMAP.md`, `DECISIONS.md`, minimal projects for 480×272 / 800×480 / 1024×600 |
| `scripts/README.md` | All scripts with parameters. Start with `env-check.ps1`. |

**Never type a path or command from memory — copy it from `ide-inventory.md` / `scripts/README.md`.**
(Remembered paths pointed at stale executables before.)

## Stage 0 — Environment check (every session, 5 s)
Run `scripts\env-check.ps1`. It reads the install folder and `%APPDATA%\AIRHMI\Designer\workspace-settings.json`
and prints Designer version, simulator exe, export dir, SD dir, and `HeadlessExport` (true when
Designer ≥ 2.8.0). Report one line to the user, e.g. "Designer 2.9.4, simulator OK, headless export
available". If Designer is missing, stop and tell the user to install it (link in `ide-inventory.md`).
Designer older than 2.9.4 has no Video object, Modbus TCP, `Fs_*` or Hardware / Startup Settings; older
than 3.5.0 has no Log (`ELog`) / Menu (`EMenu`) objects — say so before the scenario needs one of them
(`ide-inventory.md` version table).
If `HeadlessExport=false`, every export step below becomes: "Please press Export in Designer's
Simulator panel" and the script waits for `export-manifest.json` to change.

## Stage 0b — Existing project instead of a new idea
- `.airhmi.json` exists: read `docs\ROADMAP.md` if present, else run `lint-project.ps1` + `run-sim.ps1`,
  capture all screens as the baseline, then continue at the stage the user's request needs.
- Old `.ahi`: follow `legacy-ahi-migration.md` (headless convert → checklist → baseline screenshots →
  save in Designer → commit). Never edit the `.ahi`; the converted `.airhmi.json` is the source from then on.

## Stage 1 — Idea → scenario (light)
- Ask (do not assume): **device size** (4.3" → 480×272 · 5"/7" → 800×480 · 10" → 1024×600),
  **theme** (dark/light), **language(s)**, **host** (standalone screen / UART host board / Arduino),
  **network** (none / Modbus TCP PLC / TCP-UDP service — IPs, unit id, register map), **media**
  (video clips? → `video-object.md` size budget).
  (Wrong resolution shifts every coordinate later; multi-language added late rewrites all text; a
  register map discovered late rewrites every live-value row.)
- With a PLC over Modbus TCP: read `network-api.md` first; every live value gets unit / address / count /
  poll period in the live values table, the server IP goes into Hardware / Startup Settings.
- With a host board: read `host-protocol.md` first and add its checklist to SCENARIO §5 — every live
  value gets a direction (host write / screen event / host read); component names become the protocol
  and must be final before the mockup.
- Research the domain briefly (how the machine/process works, who operates it, which values matter)
  and look at 2-3 real HMI examples of that domain before proposing screens.
- Write `docs\SCENARIO.md` from `references/templates/SCENARIO.md`: actors, state table,
  numbered use cases S-xx with acceptance criteria, edge cases E-xx, **live values table**
  (value | source function on device | period | widget), **screen list derived from scenarios**.
  Cross-check: no screen without a scenario, no scenario step without a screen.
- Exit: the user approved screen list + resolution + theme + language. Record in `docs\DECISIONS.md`.

## Stage 2 — HTML mockup
- One screen = one file `mockup\<ScreenName>.html`, sized exactly to the device resolution,
  **`position:absolute` pixel layout only** (no flex/grid — coordinates are copied 1:1 later).
- Use `references/design-tokens.css`; imitate the style of `references/examples/`.
- Mark dynamic elements with `data-dynamic` (they are hidden when the background is baked).
- Only use what AIRHMI can draw — constraints list in `html-to-airhmi.md` §7 (no shadows, blur,
  web fonts, free border-radius except buttons, no translucent panels unless baked into the image).
- Simple JS navigation between screens is fine; no live values/timers in the mockup.
- Text boxes get **slack**: width = longest expected text + ~20 % (≥ 10 px), height ≈ fontSize × 1.6
  (the device font engine measures differently from the PC; tight boxes wrap or vanish on the device).
- Every iteration: render a screenshot (`scripts\render-mockup.ps1`) and show it; approved versions
  are saved to `test\shots\mockup\<ScreenName>.png` (per theme: `<ScreenName>_<theme>.png`).
- Screen names ≤ 20 characters, English, PascalCase (`MainScreen`); component ids with type prefix
  (`btnStart`, `lblTemp`) — these become component names. (Firmware stores the owner screen in a
  20-char buffer.)
- Exit: user says "vN approved". Never convert an unapproved mockup.

## Stage 3 — Convert to `.airhmi.json`
Follow `html-to-airhmi.md`. Order of work:
1. **Behaviour plan** (`docs\BEHAVIOUR.md`, short): screen transition map, variables (screen-local vs
   global), each interactive widget's event, static/dynamic split per element, live-value table with
   "how it comes alive in the simulator" (demo drift or socket injection). The mockup shows looks;
   this plan defines behaviour.
2. **Project skeleton** from `references/templates/project-<WxH>.airhmi.json` (or
   `scripts\new-project.ps1`): `device.width/height` = resolution, screens, `resources`.
3. **Per screen, layered:** bake the background (mockup rendered with `[data-dynamic]` hidden →
   PNG at device resolution → `backgroundImage`), then add **only dynamic elements** as widgets with
   the mockup's exact left/top/width/height. Text → always `ELabelBox` (`keyboard="None"` when
   read-only). Pressable area whose face is baked → invisible `EShape` hotspot, or `EButton` when a
   press effect is wanted. Press feedback pattern (hidden pressed-state `EImage` shown on `onDown`)
   in `html-to-airhmi.md` §1.
4. **Image recipe** (exact): PNG only, scaled to the widget's W×H, `resources.images[]` entry with
   id `img_<name lowercased, non-alnum → _>`, `pictureName: "id:<id>"` **and** `picturePath`, `scaleX/Y = 1`.
5. **`order`** per screen: background first `0`, then `1..N-1` without gaps or repeats (the exporter
   does not normalize; all-zero orders break touch routing).
6. Colours: property fields are **signed 32-bit ARGB ints** (`#FF0000` → `-65536`); in event code
   colours are `"#RRGGBB"` strings. Never mix.
7. **Video objects** per `video-object.md` §2-3 (even W×H, nothing overlapping, controls beside it,
   `fps` 15 / `quality` 5, ≤ 20 MB estimate). **Network / startup**: the project root `hardware` block
   (`network-api.md` §1) carries IP, Modbus TCP server, UART framing, GPIO/PWM start levels — never
   put that setup into a screen `OnStart`.
8. After each screen: `scripts\lint-project.ps1` then `scripts\run-sim.ps1 -NoLaunch` (headless
   validate + export). Fix errors per screen; do not accumulate. The first export of a video converts
   it (seconds to minutes; cached afterwards).
- Exit: lint clean, export `ok`, every screen captured once in the simulator and compared against
  its mockup (quick pre-check; the formal comparison is Stage 5).

## Stage 4 — Event code ("our format")
Read `script-api.md` before writing a line. Rules:
- Code lives where Designer expects it: per-event `.c` files (`code\<Object>_<Event>.c`, referenced
  from the JSON event field) or inline strings for 1-3 line events; `Screen OnStart`,
  `Screen Functions` (shared C functions of a screen), timer events. Start files with
  `#include "stk.h"` (+ `#include "stdio.h"` for `sprintf`). Layout and compile model:
  `script-api.md` §0b; C subset limits: §1b (every event is its own program — state goes into
  EVariable objects, function definitions only in Screen Functions).
- **Dot syntax only for object properties** (compiler 1.2.0+, Designer 2.7.0+):
  `label1.Text = "Ready";` · `gauge1.Value = x + 1;` · `x = slider1.Value;` · `timer1.Enable = 1;` ·
  `log1.Append = "Heater on";` · `menu1.Items = "A;B";`. Do **not** write the classic property functions
  (`LabelSet`, `ButtonSet`, `ImageSet`, `TimerSet`, `ArcSet`, `LogAppend`, `MenuSet` … any
  `XxxSet/XxxGet("obj","Prop",…)`) in new code — they are kept only for reading old projects; when you
  touch such a line in an existing project, rewrite it in dot syntax. The few calls without a dot form stay
  as functions (`LineAddPoint/LineSetPoint/LineClear`, `ListViewGetXY/SetXY`, `ListViewSet(...,"UPDATE",...)`).
  Limits: no `++/--` on properties, no `a.b.c`, no chained assignment, object names must be C identifiers
  (not `7seg1` — rename the object), float writes are formatted `%.2f`, text properties assigned to numeric
  variables get automatic `atoi/atof`, unknown property names are passed through silently.
- Screen change: `ChangeScreenSet("MainScreen");` (**not** `ScreenSet`). Button actions on `onDown`
  (responsive); destructive actions on `onUp`.
- `Get` results are **text** — read into a `char buf[32..256]` or use dot syntax.
- Variables: `EVariable` with `dataType` `int`/`float`/`String` — `VarSeti` writes only to `int`
  variables (silently ignored otherwise). Globals: `globalVariables[]` + `GlobalIntVarSet/Get`.
- Live values: an `ETimer` per periodically updated value (`html-to-airhmi.md` §8). In the simulator,
  board I/O (`ADC_Read`, `GPIO_Read`, `uartDataGet`, `I2C_*`, `SPI_*`) is mocked — keep the screen alive
  with demo drift or socket-injected variables, swap for real reads on the device. **Network is real
  in the simulator** (`ModbusTCP_*`, `SocketTCP_*`, `SocketUDP_*`, `HTTP_PostGet` use the PC's network).
- PLC / network data: `network-api.md` — poll from a timer, check return values, `ModbusTCP_GetLastError`
  on `-1`, never wait with `Delay`. Server address and Ethernet come from Hardware / Startup Settings.
- Files: `Fs_*` only (`file-api.md`; paths start with `C:`/`D:`, pass the real buffer size). `File_*`
  is legacy (`LEGACY_FILE_API` warning). Single values: `VariableSave`.
- Video: `Video_Play("<objectName>", 100)` / `VideoPause` / `VideoContinue` / `VideoStop`, progress in a
  timer from `Video_ElapsedGet/DurationGet` (`video-object.md` §4). No audio in this version.
- Before writing, check `script-api.md` §Traps (ListView `GetXY` is **column, row**; string-returning
  ternary, etc.).

## Stage 5 — Simulator test + visual comparison
- `scripts\run-sim.ps1 -ProjectFile <p>` : lint → headless export → copies project TTFs → starts the
  simulator with `--sd <project>\sd_card` → scans the log (`PCC1`, `illegal character`, `Exception`
  must be 0) and confirms the window title `Airhmi Simulator 2.x`.
- **Socket tests**: `test\test-scenario.ps1` drives S-xx/E-xx one block per scenario via TCP 8890
  (`scripts\AirHmiSocket.psm1`: `Send-Hmi`, `Touch x,y`, `Wait-Screen`). `VarSet/VarGet` only work in
  **comma format** (`name,value,,VarSet,,`). Each run writes `test\logs\test-scenario-<timestamp>.log`.
- **Screenshots**: `scripts\capture-sim.ps1 -ProjectFile <p> -OutDir test\shots\sim [-Theme t]`
  (navigates by socket, polls `ScreenGet`, settles 150 ms, crops the canvas with `PrintWindow`).
  Video objects show their poster only — capture while nothing plays.
- **Comparison**: `scripts\compare-shots.ps1 -Screen <name>` builds
  `test\shots\compare\<Screen>\compare.png` = mockup | simulator | (device). Compare position, size,
  font, colour, alignment **screen by screen**; record each screen as its own ROADMAP line
  ("MainScreen — visual match ✓"). A bulk "all match" is invalid.
- Differences → fix in Stage 3/4, re-capture **only the affected screens**, re-run the **whole**
  `test-scenario.ps1` (fixing looks often breaks behaviour).
- Platform limitation you cannot fix → show the user, get it accepted in `DECISIONS.md`.
- Exit: every screen visually accepted and `test-scenario.ps1` passes.

## Stage 6 — Device
See `device-deploy.md`. Two routes:
- **SD card**: `run-sim.ps1 -ExportDir <card>:\prog -NoLaunch -NoDebugInfo`; copy `sd_card\*`
  (list files, media) to the **card root**. Verify the drive letter with `Get-Volume` first.
- **FTP** (device on the network): prefer Designer's `File > Export to Device (FTP)` window (safe,
  shows progress). For automation: `scripts\upload-ftp.ps1 -Incremental` (settings read from
  `workspace-settings.json → FtpDevice`; remote path is `CWD D:` then `CWD prog`). Video `.emf` files
  are large: Designer's window skips the ones unchanged since the last upload (*Resend unchanged video
  files* forces them), `-Incremental` skips every unchanged file; serial/YMODEM is not for videos.
- **Restart after the upload yourself — never ask the user to power-cycle the device:**
  `upload-ftp.ps1 -Incremental -Restart`, or `scripts\restart-device.ps1` alone (port 80 `WDT_SoftReset();`,
  waits until the device is back: ~15 s, ~70 s on firmware older than 2026-11-07).
- **Live check over VNC**: `Tools > VNC Viewer` (device IP, port 5900, password `admin`) shows the
  device screen inside Designer and forwards mouse clicks as touches — walk the S-xx scenarios on the
  mounted device with it. The comparison screenshot still comes from `ScreenCapture` (next bullet).
- Device screenshot for the comparison: serial `ScreenCapture("<Screen>.bmp");` →
  `download-ftp.ps1 -RemoteFile prog/<Screen>.bmp` → convert to PNG → `test\shots\device\`.
- Firmware updates are **out of scope** (vendor task).
- Exit: the user confirms "verified on device". The project is not finished before that.

## Error protocol
1. Classify: **project error** (wrong field, coordinate, code) → fix here. **Simulator mock
   difference** (`script-api.md` §Simulator) → not a bug. **Platform suspicion** (Designer /
   compiler / simulator / firmware misbehaves with a correct project) → step 2.
2. Build a repro package `support\repro-<yyyyMMdd>\`: minimal `.airhmi.json`, steps, expected vs
   actual, Designer/simulator versions (`env-check.ps1 -AsJson`), `export-result.json`,
   `export-manifest.json`, simulator log. Give the user the support channel from `ide-inventory.md`.
3. Apply a documented workaround if one exists (`script-api.md` §Traps); **never attempt to patch
   Designer, simulator or firmware** and never edit files under the install folder.

## Change protocol (new screen / changed behaviour mid-project)
Never restart the whole flow; keep the chain order for the new part:
1. Record `CR-nn` in `ROADMAP.md` (date, what, why) and the approval in `DECISIONS.md`.
2. **Update SCENARIO first** — a screen that serves no scenario is not added.
3. Impact list: which existing screens get a new button (their baked background and events change),
   new variables/timers, theme/language consistency.
4. Mini-loop for the new screen: mockup → approval → convert → lint/export → capture → compare.
5. Affected existing screens are updated and **re-captured**; unaffected ones are not.
6. Add S-xx blocks to `test-scenario.ps1` and re-run **all** of it.
7. If already deployed: re-export to the device and re-verify.

## Project folder (created by `scripts\new-project.ps1`)
```text
<Project>\
  <Project>.airhmi.json          the project (canonical source)
  img\      fonts\     code\     PNG assets · extra TTFs · .c event files
  sd_card\                       list files / media → simulator SD root and device card root
  mockup\                        <Screen>.html + tokens.css
  docs\     SCENARIO.md · ROADMAP.md · DECISIONS.md · BEHAVIOUR.md
  test\     test-scenario.ps1 · shots\{mockup,sim,device,compare}\ · logs\
  support\                       repro packages (if ever needed)
```
Make the folder a git repository (`git init`) and commit at every approval point; mockups and the
JSON are overwritten in place, history lives in git. Read `docs\ROADMAP.md` at session start and
continue from the first unchecked item.

## Negative rules
- No Designer/simulator/firmware source edits, no files written under the install folder.
- No conversion before mockup approval; no "works" report without a clean export and a simulator run.
- No `pictureHex`/`backgroundPictureHex` hand-filling (legacy fallback fields).
- No Unicode subscript characters (`₂`) in dynamic text — write `CO2`.
- No `ScreenSet(`, no `LabelSets(` in event code (wrong/legacy names — see `script-api.md`).
- No classic property functions (`LabelSet`, `ButtonSet`, `XxxSet/XxxGet("obj","Prop",…)`) in new event code —
  dot syntax only (`lint-project.ps1` warns `CLASSIC_PROPERTY_CALL`).
- No ELabel (removed in Designer 2.9.6 - use ELabelBox); no EShape as visible decoration (it is an invisible hotspot).
- No `File_*` in new code (`Fs_*` with drive paths); no `Delay()` loops waiting for network data.
- No network/IP setup in a screen `OnStart` (Hardware / Startup Settings); no `ModbusTCP_Open` / HTTP in `onDown`.
- No raw MP4 handling by hand (the Video object converts at export); no object overlapping a video.

## End of session
If something went wrong twice or a rule proved wrong, tell the user in one line and suggest reporting
it through the support channel so the skill can be improved. Do not edit the skill files yourself.
