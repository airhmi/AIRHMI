# Getting the project onto the device (SD card, FTP, serial)

> The export package (what the simulator runs) is exactly what the device runs. Two transfer routes,
> one verification route (device screenshot). Firmware updates are a vendor task and out of scope.

## 1. What goes where
| Content | PC (simulator) | Device |
|---|---|---|
| Export package (`*.js`, `files.ini`, `options.ini`, `*.pcc`, `*.raw`, `*.ttf`, media) | `C:\Users\Public\airhmi\simulator` (or the project's export dir) | **`D:\prog`** on the device's SD card (= `<card>:\prog` in a PC reader) |
| List files, media referenced by name (`listFile`, SD sounds) | simulator SD root (`--sd <project>\sd_card`) | **card root** (`D:\` on the device = `<card>:\`) |
| Video objects: `<Screen>_<Name>.emf` + `_poster.raw\|jpg` (converted at export, MP4 not copied) | with the package | `D:\prog` — large files, see §3 |
| Hardware / Startup Settings: `init.c`, `init.pcc`, `hw.cfg` (only when enabled) | with the package | `D:\prog` (listed in `files.ini`) |

Export for the device **without debugger files**: `run-sim.ps1 -NoDebugInfo` (or Designer
`--no-debug-info`) — `.pccdbg` files are useless on the device.

## 2. Route A — SD card in a reader
1. Find the card: `Get-Volume | Where-Object DriveType -eq 'Removable'` → drive letter (e.g. `F:`).
   **Verify before writing** — never assume the letter.
2. Export straight onto the card: `scripts\run-sim.ps1 -ProjectFile <p> -ExportDir F:\prog -NoLaunch -NoDebugInfo`.
3. Copy `<project>\sd_card\*` to `F:\` (card root).
4. Eject, insert into the device, power on. The device starts the screen named in `openFirstScreen`.

## 3. Route B — FTP over the network (device stays in place)
**Preferred: Designer's built-in window** — `File > Export to Device (FTP)`: fill Host / Port (21) /
User / Pass / Drive (`D:`) / Dir (`prog`), press **Upload**. Designer exports to a temp folder (stops
on validation errors) and uploads file by file with a progress bar; the result line says
`Uploaded X/Y file(s)`. The values are remembered in `workspace-settings.json → FtpDevice`.
The window skips `.emf` video files that did not change since the last upload to that host (client-side
manifest in `%LOCALAPPDATA%\AIRHMI\deploy-state\`, result line "N unchanged video file(s) skipped");
tick **Resend unchanged video files** to force them. The device FTP server answers no `SIZE`/`LIST`, so a
client-side manifest is the only skip mechanism — the same idea `upload-ftp.ps1 -Incremental` applies to
every file. Serial/YMODEM upload (~11 KB/s) is fine for code-only changes, not for videos (20 MB ≈ 30 min).

**Automation:** `scripts\upload-ftp.ps1` (defaults from `FtpDevice`; override with parameters):
```powershell
& "$env:USERPROFILE\.claude\skills\airhmi-dev\scripts\upload-ftp.ps1" -SourceDir C:\Users\Public\airhmi\simulator -Incremental
```
- One FTP control session for all files (hundreds of per-file sessions are far too slow).
- Sequence per file: `CWD /` → `CWD D:` → `CWD prog` → `TYPE I` → `PASV` → `STOR` → expect `150` then `226`.
  The remote path is **not** `/prog`; it must be drive then directory.
- `-Incremental` keeps a SHA-256 manifest in `C:\Users\Public\airhmi\deploy-state\<ip>.json` and sends
  only new/changed files; first run = full baseline. `-ForceFull` resends everything. `-DryRun` previews.
- `socket_debug.log` is excluded by default. Remote files are never deleted automatically.
- Success = `Uploaded=N, Failed=0`. `LIST`/`SIZE`/`RETR` may return empty or `550` on this FTP server —
  do not use listing as the success check.
- After the upload restart the device and verify the start screen.

| Reply / symptom | Meaning | Fix |
|---|---|---|
| `530` | wrong user/password | check credentials |
| `552 Create file failed` with target `/prog` | wrong root | use `D:` then `prog` |
| `552` even with `D:/prog` | SD not mounted / write-protected / full | check the card |
| no response for 30 s | device unreachable | IP, network, FTP service on the device |
| upload cancelled half-way | mixed package on the card | upload again fully before starting the device |

## 4. Device screenshot for the visual comparison (`3_device.png`)
The device can save its current screen to the SD card; use the **serial port** for the command (the
network path blocks on long commands):
| Item | Value |
|---|---|
| Port | the device's UART (USB-UART bridge), **115200 8-N-1** |
| Command format | function call + `;` + `\r\n` — e.g. `ScreenCapture("MainScreen.bmp");` |
| Reply | `OK` (or `NOK`) plus the command's own printf lines |
| Result | `D:\prog\MainScreen.bmp` on the card (16-bit BMP, ~750 KB at 800×480) |

```powershell
$port = New-Object System.IO.Ports.SerialPort("COM6", 115200, 'None', 8, 'One')
$port.ReadTimeout = 8000; $port.Open(); Start-Sleep -Milliseconds 300
if ($port.BytesToRead -gt 0) { $port.ReadExisting() | Out-Null }
$port.Write('ChangeScreenSet("MainScreen");' + "`r`n"); Start-Sleep -Milliseconds 800
$port.Write('ScreenCapture("MainScreen.bmp");' + "`r`n")
$resp = ""; $sw = [Diagnostics.Stopwatch]::StartNew()
while ($sw.ElapsedMilliseconds -lt 8000 -and $resp -notmatch 'OK|NOK') {
    Start-Sleep -Milliseconds 200; if ($port.BytesToRead -gt 0) { $resp += $port.ReadExisting() } }
$port.Close(); $resp
```
Then fetch it: `scripts\download-ftp.ps1 -RemoteFile "prog/MainScreen.bmp" -LocalPath test\shots\device\MainScreen.bmp`
and convert BMP → PNG (`compare-shots.ps1` does this when it finds a `.bmp`). Repeat per screen with
`ChangeScreenSet` — the same screen is then compared across mockup, simulator and device.

Designer also has a **serial terminal** (`--show-serial-terminal` or View menu) for sending these
commands by hand. Only one application can hold the COM port — close other terminals first.

## 4b. Live check over VNC (no cable, no card swap)
`Tools > VNC Viewer` (toolbar **VNC**): Host = device IP (empty → the FTP host), Port `5900`, Password
`admin`, **Auto** reconnects after a device reset, **Fit** scales the view. The device screen appears live
inside Designer and a mouse click is sent as a touch — walk the S-xx scenarios on the mounted device
and watch the result. Needs firmware V6.04+ with Ethernet enabled (Hardware / Startup Settings or the
factory default `192.168.2.150`). It is a viewer for behaviour checks; the pixel comparison still uses
`ScreenCapture` (§4) — VNC frames travel RGB565 over a throttled link.

## 5. Behaviour differs between simulator and device?
1. Simulator mock? (`script-api.md` §Simulator) — hardware functions return fixed values on the PC.
2. Font metrics (text wraps/vanishes on the device) → widen the box (`html-to-airhmi.md` §6).
3. Missing file on the card (`files.ini` vs card content; `export-manifest.json → missingInputs`).
4. Still wrong with a correct project → repro package + support channel (`SKILL.md` → Error protocol).
