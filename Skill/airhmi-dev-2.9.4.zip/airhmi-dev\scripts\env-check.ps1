﻿<#
.SYNOPSIS
    Finds the installed AIRHMI Designer, simulator and paths; reports what the skill can automate.

.DESCRIPTION
    Reads the install folder (%LOCALAPPDATA%\Programs\AIRHMI Designer, then %ProgramFiles%) and
    %APPDATA%\AIRHMI\Designer\workspace-settings.json (read-only). Returns an object (or JSON with -AsJson):
      DesignerExe, DesignerVersion, HeadlessExport (Designer >= 2.8.0), SimulatorExe, SimulatorVersion,
      ExportDir, SdDir, ManualIndex, FtpHost/FtpPort/FtpUser/FtpDrive/FtpDir, Problems[]
    Other skill scripts dot-source this file and call Get-AirHmiEnvironment.

.EXAMPLE
    .\env-check.ps1
.EXAMPLE
    .\env-check.ps1 -AsJson
#>
[CmdletBinding()]
param([switch]$AsJson, [switch]$Quiet)

$ErrorActionPreference = 'Stop'

function Get-AirHmiEnvironment {
    $problems = New-Object System.Collections.Generic.List[string]
    # AIRHMI_DESIGNER_EXE overrides the lookup (portable copies, several versions side by side, testing).
    $candidates = @(
        $env:AIRHMI_DESIGNER_EXE,
        (Join-Path $env:LOCALAPPDATA 'Programs\AIRHMI Designer\AirHMI.Designer.App.exe'),
        (Join-Path $env:ProgramFiles 'AIRHMI Designer\AirHMI.Designer.App.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'AIRHMI Designer\AirHMI.Designer.App.exe')
    )
    $designerExe = $candidates | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
    $designerVersion = $null
    $headless = $false
    if ($designerExe) {
        $fv = (Get-Item -LiteralPath $designerExe).VersionInfo.FileVersion
        if ($fv) {
            $designerVersion = ($fv -split '\+')[0]
            try {
                $v = [Version](($designerVersion -split '-')[0])
                $headless = ($v -ge [Version]'2.8.0')
            } catch { $problems.Add("Designer version could not be parsed: $fv") }
        }
    } else {
        $problems.Add('AIRHMI Designer is not installed (expected %LOCALAPPDATA%\Programs\AIRHMI Designer). Download: https://airhmi.com')
    }
    $installDir = if ($designerExe) { Split-Path -Parent $designerExe } else { $null }

    $settingsPath = Join-Path $env:APPDATA 'AIRHMI\Designer\workspace-settings.json'
    $settings = $null
    if (Test-Path -LiteralPath $settingsPath) {
        try { $settings = Get-Content -LiteralPath $settingsPath -Raw -Encoding UTF8 | ConvertFrom-Json }
        catch { $problems.Add("workspace-settings.json could not be read: $($_.Exception.Message)") }
    }

    $simulatorExe = $null
    if ($settings -and $settings.SimulatorExePath -and (Test-Path -LiteralPath $settings.SimulatorExePath)) {
        $simulatorExe = $settings.SimulatorExePath
    } elseif ($installDir -and (Test-Path -LiteralPath (Join-Path $installDir 'Simulator\Airhmi_Simulator.exe'))) {
        $simulatorExe = Join-Path $installDir 'Simulator\Airhmi_Simulator.exe'
    } else {
        $problems.Add('Simulator exe not found (Simulator\Airhmi_Simulator.exe next to Designer, or SimulatorExePath in workspace-settings.json).')
    }
    $simulatorVersion = if ($simulatorExe) { (Get-Item -LiteralPath $simulatorExe).VersionInfo.FileVersion } else { $null }

    $exportDir = if ($settings -and $settings.SimulatorExportPath) { $settings.SimulatorExportPath } else { 'C:\Users\Public\airhmi\simulator' }
    $sdDir = 'C:\Users\Public\airhmi\sd_card'
    $manual = if ($installDir) { Join-Path $installDir 'manual\index.html' } else { $null }
    if ($manual -and -not (Test-Path -LiteralPath $manual)) { $manual = $null }

    $ftp = if ($settings) { $settings.FtpDevice } else { $null }

    [pscustomobject]@{
        DesignerExe      = $designerExe
        DesignerVersion  = $designerVersion
        HeadlessExport   = $headless
        InstallDir       = $installDir
        SimulatorExe     = $simulatorExe
        SimulatorVersion = $simulatorVersion
        ExportDir        = $exportDir
        SdDir            = $sdDir
        ManualIndex      = $manual
        SettingsPath     = $(if (Test-Path -LiteralPath $settingsPath) { $settingsPath } else { $null })
        FtpHost          = $(if ($ftp) { $ftp.Host } else { $null })
        FtpPort          = $(if ($ftp -and $ftp.Port) { [int]$ftp.Port } else { 21 })
        FtpUser          = $(if ($ftp) { $ftp.UserName } else { $null })
        FtpPassword      = $(if ($ftp) { $ftp.Password } else { $null })
        FtpDrive         = $(if ($ftp -and $ftp.DeviceDrive) { $ftp.DeviceDrive } else { 'D:' })
        FtpDir           = $(if ($ftp -and $ftp.RemoteDirectory) { $ftp.RemoteDirectory } else { 'prog' })
        Problems         = $problems.ToArray()
    }
}

# Only report when executed directly (dot-sourcing just defines the function).
if ($MyInvocation.InvocationName -ne '.') {
    $envInfo = Get-AirHmiEnvironment
    if ($AsJson) {
        $envInfo | ConvertTo-Json -Depth 4
    } elseif (-not $Quiet) {
        $headlessText = if ($envInfo.HeadlessExport) { 'yes (--export-sim-out)' } else { 'no - export manually in Designer (Simulator panel > Export)' }
        Write-Host ("Designer  : {0}  v{1}" -f $envInfo.DesignerExe, $envInfo.DesignerVersion)
        Write-Host ("Headless  : {0}" -f $headlessText)
        Write-Host ("Simulator : {0}  v{1}" -f $envInfo.SimulatorExe, $envInfo.SimulatorVersion)
        Write-Host ("Export dir: {0}" -f $envInfo.ExportDir)
        Write-Host ("SD dir    : {0}" -f $envInfo.SdDir)
        Write-Host ("Manual    : {0}" -f $envInfo.ManualIndex)
        if ($envInfo.FtpHost) { Write-Host ("FTP device: {0}:{1} {2}\{3} (user {4})" -f $envInfo.FtpHost, $envInfo.FtpPort, $envInfo.FtpDrive, $envInfo.FtpDir, $envInfo.FtpUser) }
        foreach ($p in $envInfo.Problems) { Write-Host ("PROBLEM   : {0}" -f $p) -ForegroundColor Yellow }
    }
    if ($envInfo.Problems.Count -gt 0 -and -not $envInfo.DesignerExe) { exit 2 }
    exit 0
}
