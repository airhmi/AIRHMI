# airhmi-dev changelog

## 2.9.4 — 2026-10-20
- Built against AIRHMI Designer 2.9.4 / simulator 2.9.4 / firmware V6.04.
- New references: `network-api.md` (Ethernet, TCP/UDP sockets, HTTP, Modbus TCP with return codes,
  Hardware / Startup Settings `hardware` block → `init.pcc` + `hw.cfg`, PLC polling patterns),
  `file-api.md` (`Fs_*` file functions, recipes, timings, simulator mapping, `File_*` migration),
  `video-object.md` (Video canvas object: MP4 resource → `.emf` at export, JSON fields, play/pause/
  progress functions, size budget, validation codes, incremental FTP).
- `script-api.md`: board I/O signatures corrected to the real names (`GPIO_Write("GPIO_n", v)`,
  `GPIO_Read`, `ADC_Read(n, &d)`, `printf` as UART write, `uartDataGet`, `BuzzerSet`), memory limits
  (8192 B globals / 4096 B per function), `EVideo.Visible`, new EImage/EBarChart properties, new traps
  (`Delay` vs network, legacy `File_*`), simulator section (network and files are real), catalog rewrite.
- `ide-inventory.md`: 2.9.x windows (Hardware / Startup Settings, VNC Viewer, F1 context help, FTP
  unchanged-video skip), new export files, cache/deploy-state paths, version table.
- `widget-reference.md`, `html-to-airhmi.md`, `device-deploy.md` (VNC check, video upload),
  `legacy-ahi-migration.md`, `simulator-socket.md`, `SKILL.md` stages and negative rules updated.

## 2.8.0 — 2026-10-12 (initial)
- First public version, built against AIRHMI Designer 2.8.0 (headless `--export-sim-out` /
  `--validate-out`, font copy), simulator socket 8890, PCC compiler 1.2.0 (dot syntax).
- Workflow: scenario → mockup → convert → code → simulate/compare → device.
- Scripts: env-check, new-project, lint-project, run-sim, AirHmiSocket module, capture-sim,
  compare-shots, render-mockup, upload-ftp, download-ftp.
- References: IDE inventory, widget reference, HTML→AIRHMI, script API (project code layout, C subset,
  dot syntax, cookbook), host protocol (UART text protocol + AIRDUINO), legacy .ahi migration (headless
  convert + checklist), simulator socket, device deploy,
  templates (scenario/roadmap/decisions + minimal projects), example design.
