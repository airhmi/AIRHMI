# Network API — Ethernet, TCP/UDP sockets, HTTP, Modbus TCP, startup settings

> Firmware V6.04 or newer (Designer 2.9.4 code completion). The device has one script TCP socket, one
> UDP receive port, one HTTP helper and one Modbus TCP client. Everything here is **real in the
> simulator too**: the simulator opens genuine TCP/UDP connections from the PC's network stack, so a
> Modbus TCP server on the LAN (or a Modbus simulator on `127.0.0.1:502`) can be used for testing.
> Only the Ethernet configuration functions do nothing on the PC.

## 1. Where network setup belongs — Hardware / Startup Settings (not OnStart)
`Screen > Hardware / Startup Settings...` writes **project-level** settings that the device applies at
every boot, before the first screen's `OnStart`: Ethernet (None / DHCP / Static IP), Modbus TCP server
(IP, port, timeout — saved with `ModbusTCP_Config`, **connected on the first read/write**, so a
powered-off PLC does not delay the boot), UART framing, GPIO 1–9 direction + start level, PWM 0/1,
backlight, volume, and free **user startup code**. Tick *Use hardware / startup settings* to enable it.

Why not `OnStart`: it runs every time the screen opens, is skipped when the first screen changes, and
re-applying the IP closes open connections. Startup settings run exactly once.

On export Designer generates `init.c` → **`init.pcc`** (runs once after the project loads) and
**`hw.cfg`** (GPIO/PWM applied right after power-on, before the logo). Both are listed in `files.ini`.
The simulator runs `init.pcc` too and lists the `hw.cfg` lines in its log (no real pins).
Values are validated against the firmware limits; export is blocked while they are invalid
(`HARDWARE_SETTING_INVALID`). `NetStat();` on the serial port prints `init=<state>:<code>` and
`hw=<applied>/<errors>` for diagnosis.

Project JSON (root key `hardware`; omit it for the old behaviour):
```json
"hardware": {
  "enabled": true,
  "ethernetMode": "Static", "ipAddress": "192.168.2.150", "netmask": "255.255.255.0", "gateway": "192.168.2.1",
  "modbusTcpEnabled": true, "modbusTcpIp": "192.168.2.10", "modbusTcpPort": 502, "modbusTcpTimeoutMs": 500,
  "uartEnabled": false, "uartDataBits": 8, "uartStopBits": 1, "uartParity": 0,
  "gpios": [ { "pin": 1, "mode": "Out", "initialValue": 1 }, { "pin": 2, "mode": "In", "initialValue": 0 } ],
  "pwms":  [ { "channel": 0, "enabled": true, "frequencyHz": 1000, "dutyPercent": 50 } ],
  "backlightEnabled": true, "backlight": 100,
  "volumeEnabled": false, "volume": 50,
  "userCode": ""
}
```
`ethernetMode`: `None` | `Dhcp` | `Static` · `gpios[].mode`: `None` | `In` | `Out` (pins 1–9) ·
`pwms[].channel` 0/1, `frequencyHz` 1–100000, `dutyPercent` 0–100 · `uartParity` 0 none / 1 odd / 2 even;
the UART baud rate is the project's `upload.baudRate`. Keep `userCode` to configuration only — a blocking
call there (`ModbusTCP_Open`, HTTP) delays the first screen.

## 2. Return values (read before writing error handling)
| Group | Success | Failure |
|---|---|---|
| `SocketTCP_Read`, `SocketTCP_SendRead`, `SocketUDP_Read` | byte count `> 0` | `0` timeout / no data · `-2` not connected · `-4` bad parameter |
| `SocketTCP_Create*`, `EthernetInit_*`, `SocketUDP_*` | `0` | `-1` |
| `ModbusTCP_*` read/write | `0` | `-1` → `ModbusTCP_GetLastError()`: `1..255` slave exception code, `-1` timeout, `-2` not connected, `-3` bad frame, `-4` bad parameter, `-5` send failed |
| `HTTP_PostGet` | `1` | `0` |

## 3. Functions
### Ethernet
```c
EthernetInit_Static("192.168.2.150", "255.255.255.0", "192.168.2.1");  // may be called again at runtime (changes the IP, closes open connections); -1 on a bad address
EthernetInit_DHCP();                                                    // only as the FIRST Ethernet start (-1 afterwards)
char ip[20]; EthernetGet_IP(ip);   char mac[20]; EthernetGet_MAC(mac);  // text
```
Prefer the startup settings over calling these from code.

### TCP client (one socket)
| Function | Notes |
|---|---|
| `SocketTCP_Create(ip, port)` | connect, waits 1 s; same target again = no change |
| `SocketTCP_CreateTimeout(ip, port, ms)` | connect wait 50–10000 ms |
| `SocketTCP_Send(data, length)` | reconnects to the last target if the connection dropped |
| `SocketTCP_Read(buffer, max, ms)` | **recommended receive**: ≤ `max` bytes, waits ≤ `ms` (0 = no wait, max 10000); unread bytes stay for the next call |
| `SocketTCP_SendRead(data, length, buffer, max, ms)` | send (length may be 0) + read the reply; collects segments until 20 ms of silence or `max` |
| `SocketTCP_Available()` | bytes waiting (`-2` = not connected) |
| `SocketTCP_GetStatus()` | `10` connected, `1` closed |
| `SocketTCP_Close()` | |
| `SocketTCP_Receive(buffer, &length)`, `SocketTCP_SendReceive(data, length, buffer, &length)` | **legacy** — wait 3 s, ignore the buffer size; do not use in new code |

### UDP (one receive port)
| Function | Notes |
|---|---|
| `SocketUDP_Create(port)` | open the receive port (first call only) |
| `SocketUDP_Send(ip, port, data, length)` | one datagram, **max 1472 bytes** |
| `SocketUDP_Read(buffer, max, ms)` | one packet, ≤ `max` bytes (rest of the packet dropped) |
| `SocketUDP_Available()` | size of the waiting packet |
| `SocketUDP_Receive(buffer, &length)` | legacy, no wait, unchecked buffer |

### HTTP
`HTTP_PostGet(host, request, response, &length)` — raw HTTP request text; host names go through DNS
(a name no DNS answers blocks ~19 s); response cut at 4095 bytes, chunked bodies returned raw, status
code not parsed. Use it from a slow timer, never from `onDown`.

### Modbus TCP client (FC01–06, 15, 16)
```c
ModbusTCP_Config("192.168.2.10", 502);  // remember the server, connect on first use (what startup settings do)
ModbusTCP_Open("192.168.2.10", 502);    // connect now (blocks); 0 / -1
ModbusTCP_SetTimeout(500);              // 50–10000 ms, default 500; returns the applied value
ModbusTCP_IsConnected();                // 1 while connected
ModbusTCP_Close();
int v[4];
ModbusTCP_ReadCoils(unit, address, count, v);            // FC01, max 2000 → int array of 0/1
ModbusTCP_ReadDiscreteInputs(unit, address, count, v);   // FC02
ModbusTCP_ReadHoldingRegisters(unit, address, count, v); // FC03, max 125, values 0–65535
ModbusTCP_ReadInputRegisters(unit, address, count, v);   // FC04
ModbusTCP_WriteSingleCoil(unit, address, value);         // FC05
ModbusTCP_WriteSingleRegister(unit, address, value);     // FC06
ModbusTCP_WriteMultipleCoils(unit, address, count, v);   // FC15, max 1968
ModbusTCP_WriteMultipleRegisters(unit, address, count, v); // FC16, max 123
ModbusTCP_GetLastError();
```
`unit` = slave/unit id (often 1), `address` = 0-based register/coil offset (a PLC address "40001" is
holding register 0). **The runtime cannot see your array size: `count` must never exceed the array.**
Modbus **RTU** (serial) functions of old board examples (`ReadHoldingRegisters`, `Modbus_*`) still
compile but are legacy; new projects use Modbus TCP.

## 4. Patterns
**PLC polling (timer 500–1000 ms, Modbus server set in startup settings)**
```c
#include "stk.h"
int regs[4]; int r;
r = ModbusTCP_ReadHoldingRegisters(1, 0, 4, regs);        // unit 1, registers 0..3
if (r == 0) {
    lblTemp.Text = regs[0]; lblPressure.Text = regs[1];
    ledLink.State = 1;
} else {
    ledLink.State = 0;
    lblStatus.Text = ModbusTCP_GetLastError();            // -1 timeout, -2 not connected, 1..255 exception
}
```
**Setpoint write (button / slider release — `onUp`)**
```c
#include "stk.h"
if (ModbusTCP_WriteSingleRegister(1, 10, sldSpeed.Value) != 0) { lblStatus.Text = "PLC write failed"; }
```
**Coils → LEDs**: `ModbusTCP_ReadCoils(1, 0, 8, c);` then `ledPump.State = c[0];` …
**TCP line protocol to a PC service**
```c
#include "stk.h"
#include "string.h"
char rx[128]; int n;
if (SocketTCP_GetStatus() != 10) { SocketTCP_CreateTimeout("192.168.2.20", 5000, 500); }
n = SocketTCP_SendRead("GET TEMP\n", 9, rx, 127, 300);
if (n > 0) { rx[n] = 0; lblTemp.Text = rx; }
```
**Without startup settings** (older projects): open once from the first screen's `OnStart`, guarded by a
global flag, or put `ModbusTCP_Config(...)` into the startup user code.

## 5. Traps
| Trap | Correct |
|---|---|
| Network setup in a screen `OnStart` | Hardware / Startup Settings (runs once, before the first screen) |
| `Delay(ms)` while waiting for data | `Delay` stops network processing (packets are not received, a dropped link still reads connected) and does not feed the watchdog (≥ 20 s resets the device). Wait with the `ms` parameter of `SocketTCP_Read` / `SocketUDP_Read` |
| `ModbusTCP_Open` / HTTP in `onDown` or startup code | they block the screen while connecting; call from a timer, keep timeouts short |
| `count` larger than the `int` array | memory corruption with no error — size arrays to the largest `count` |
| Host name instead of IP | DNS lookup can block ~19 s when no server answers; use IPs on machine networks |
| UDP datagram > 1472 bytes | split it |
| `SocketTCP_Receive` / `SocketUDP_Receive` in new code | `SocketTCP_Read` / `SocketUDP_Read` with `max` and `ms` |
| `EthernetInit_DHCP()` after a static start | returns `-1`; DHCP only as the first start |
| Expecting the simulator to mock Modbus | it is real: no server → `-1` / `-2`. Run a Modbus TCP simulator on the PC or test against the PLC |
