# Migrating an old `.ahi` project to the new format

> Projects made with the old AIRHMI Designer are `.ahi` files (one file, images embedded as hex).
> The new Designer **imports** them: the `.ahi` is read, converted to `.airhmi.json`, embedded images
> are extracted to `img\`. The `.ahi` is never modified; the conversion is one-way (no export back).

## 1. Convert

**Headless (Designer 2.8.0+, no clicks):**
```powershell
$designer = "$env:LOCALAPPDATA\Programs\AIRHMI Designer\AirHMI.Designer.App.exe"
& $designer --open-project "C:\Projects\Old\Panel.ahi" --validate-out "C:\Projects\Old\convert-result.json"
```
Result: `C:\Projects\Old\Panel.airhmi.json` next to the `.ahi` (same name, new extension), `img\` with
the extracted PNGs, and the validation report in `convert-result.json` (exit 0 = no validation errors).
Designer reuses an existing `Panel.airhmi.json` if it is newer than the `.ahi`; delete it to force a fresh
conversion.

**In Designer:** `File > Import Legacy AHI` → pick the `.ahi` → the project opens → `File > Save`.
(Also: `File > Open` on a `.ahi` does the same import.)

**Before converting:** copy the whole old folder (`.ahi` + images + fonts + list files) to a new project
folder created with `scripts\new-project.ps1` (or at least keep them together) — a `.ahi` copied alone
is the number-one cause of "missing resource" after import.

## 2. What the converted file looks like
- `format` is `"legacy-ahi"` (not `"airhmi-project"`); `lint-project.ps1` reports it as a warning.
  Designer writes `airhmi-project` when you save the project after import.
- Every component keeps its original values in `legacyProperties` (dozens of keys) — informational,
  do not edit; the real fields are the normal camelCase ones.
- `order` values are numbered across all screens (e.g. Screen1 2..9, Screen2 11..14); that is fine —
  the rule that matters is **unique per screen**.
- Events arrive as inline code (`"onDown": "#include \"stk.h\"\n\nButtonSet(...)"`), all four keys
  present even when empty. Old `.c`/`.pcc` references next to the `.ahi` are kept as references.
- Embedded images become `resources.images[]` + `img\<name>.png`; `pictureName` uses `id:` references.
- `device` is filled from the old project size (profile/modelId/series guessed from width×height — check
  it matches the real device).

## 3. Post-import checklist (do it screen by screen, record in ROADMAP)
- [ ] Screen count equals the old project; walk every screen.
- [ ] Component placement: overlapping and edge-aligned items first.
- [ ] Images: nothing red in Designer's Resources panel; `convert-result.json → validation.issues[]` lists
      `*_FILE_MISSING` items — point Designer's **Browse** to the file or copy it into `img\`.
- [ ] Fonts: non-Roboto fonts need their TTF in the project (`COMPONENT_FONT_FILE_MISSING` warning).
- [ ] Event code: open a few, `Check C`; old helper names still compile (`LabelSetf`, `VideoPlay` aliases
      are normalized at export), but prefer rewriting hot paths to dot syntax when you touch them.
      `File_*` calls raise `LEGACY_FILE_API` → migrate to `Fs_*` (`file-api.md` §7) when you touch them.
- [ ] Video objects: the import keeps `mediaPath` = the old ready-made `.emf`, copied unchanged (W/H from
      its header). To re-encode (new size, fps, quality) point `fileName` at an MP4 resource and clear
      `mediaPath` (`video-object.md`).
- [ ] `scripts\lint-project.ps1` → `scripts\run-sim.ps1` → simulator behaves like the old one; differences
      → `test\shots\sim\` screenshots + repro package if it looks like a platform difference.
- [ ] Save in Designer once (`File > Save`) so `format` becomes `airhmi-project`, then `git commit`
      the "clean imported state" before changing anything.

## 4. Known differences to expect
| Area | Status |
|---|---|
| Screens, components, position/size | 1:1 (originals also in `legacyProperties`) |
| Event code | carried over; compile check needed; dot syntax available from now on |
| Images / fonts | carried over when the files are found; otherwise listed by Validate |
| Behaviour differences of very old firmware versions | test in the simulator; report with a sample if real |
| Going back to the old Designer | not possible — keep the `.ahi` |

## 5. Typical workflow with this skill
1. `new-project.ps1 -Name <Old> -Device <size>` → copy `.ahi` + assets into the folder.
2. Headless convert (above) → read `convert-result.json`, fix missing resources.
3. `lint` → `run-sim` → capture every screen (`capture-sim.ps1`) as the **baseline** of the old design
   (`test\shots\legacy\` — keep them; they replace the mockup in `compare-shots.ps1` when you redesign).
4. Continue with the normal stages (scenario for new features, mockup only for redesigned screens).
