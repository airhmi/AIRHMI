# Example: Wall panel (smart-home audio/channel control, 7", 800×480)

<!-- Liked: dark background with large clock/value typography; keypad panel on the right; bottom
     action bar (icon + coloured underline); card grid for channel selection; full keyboard screen. -->

Use this as a **style and density reference** when producing new mockups: spacing, type sizes,
touch-target sizes, how dynamic elements are marked.

## Contents
- `mockup\` — HTML source of 6 screens + `tokens.css` (design tokens) + `i18n.js` (multi-language
  text pattern). Screen navigation works in a browser; dynamic elements carry `data-dynamic`
  (hidden when the background is baked).
- `screenshots\` — approved renders of the screens (theme 1).

## Patterns demonstrated
- One HTML file per screen, absolute pixel layout at device resolution.
- Static decoration (panels, frames, key faces) that is baked into the screen background; only text,
  values and touch areas become widgets.
- Keyboard/numpad screens: key faces in the background, invisible `EShape` hotspots on top, pressed
  state shown with a hidden `EImage` toggled on `onDown`/`onUp`.
- Multi-language text kept in one place (`i18n.js`) so the same layout serves several languages.
- Four colour themes handled at runtime by swapping background images (`ImageSet(...,"IMAGE_FILE_REPLACE",...)`).

## Screens
| Screen | Purpose |
|---|---|
| LockScreen | PIN lock with clock |
| MainScreen | Volume/channel overview with large value readouts |
| ChannelSelectScreen | Card grid of channels |
| ChannelEditScreen | Edit a channel's name/level |
| SettingsScreen | Language, theme, network |
| KeyboardScreen / NumpadScreen | Text and numeric entry |
