﻿<#
.SYNOPSIS
    Lint -> export (headless Designer) -> start the simulator and check its log. One command per iteration.

.DESCRIPTION
    1) lint-project.ps1 (errors stop the run)
    2) Export: Designer >= 2.8.0 -> AirHMI.Designer.App.exe --open-project <p> --export-sim-out <dir> [--no-debug-info]
               older Designer   -> prints "press Export in Designer" and waits for export-manifest.json to change
       Result: <dir>\export-result.json (ok/exitCode/validation/outputLines). Errors are printed.
    3) Safety net: copies <project>\fonts\*.ttf and <project>\*.ttf next to the export (older Designers skip them)
    4) Simulator started detached with --sd <project>\sd_card (if the folder exists), log scanned for
       PCC1 / illegal character / Exception / Hata: ; window title must start with "Airhmi Simulator"

.PARAMETER ProjectFile   .airhmi.json
.PARAMETER ExportDir     default: Designer's SimulatorExportPath (C:\Users\Public\airhmi\simulator). Use <card>:\prog for SD cards.
.PARAMETER SdDir         default: <project>\sd_card when it exists, else the simulator's fixed SD root
.PARAMETER NoLaunch      export only
.PARAMETER NoDebugInfo   device package: no .pccdbg files
.PARAMETER SkipLint      skip lint-project.ps1
.PARAMETER ManualExportTimeoutSec  how long to wait for a manual Export on Designer < 2.8 (default 180)

.EXAMPLE
    .\run-sim.ps1 -ProjectFile C:\Projects\Panel\Panel.airhmi.json
.EXAMPLE
    .\run-sim.ps1 -ProjectFile .\Panel.airhmi.json -ExportDir F:\prog -NoLaunch -NoDebugInfo
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$ProjectFile,
    [string]$ExportDir = '',
    [string]$SdDir = '',
    [switch]$NoLaunch,
    [switch]$NoDebugInfo,
    [switch]$SkipLint,
    [int]$ManualExportTimeoutSec = 180
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'env-check.ps1')
$airEnv = Get-AirHmiEnvironment
if (-not $airEnv.DesignerExe) { throw ($airEnv.Problems -join ' ') }

function Step($n, $msg) { Write-Host "`n[$n] $msg" -ForegroundColor Cyan }
function Ok($msg) { Write-Host "    OK  $msg" -ForegroundColor Green }
function Warn2($msg) { Write-Host "    !!  $msg" -ForegroundColor Yellow }

if (-not (Test-Path -LiteralPath $ProjectFile)) { throw "Project file not found: $ProjectFile" }
$ProjectFile = (Resolve-Path -LiteralPath $ProjectFile).Path
$projectDir = Split-Path -Parent $ProjectFile
if (-not $ExportDir) { $ExportDir = $airEnv.ExportDir }
New-Item -ItemType Directory -Force -Path $ExportDir | Out-Null
$ExportDir = (Resolve-Path -LiteralPath $ExportDir).Path
if (-not $SdDir) { $candidate = Join-Path $projectDir 'sd_card'; if (Test-Path -LiteralPath $candidate) { $SdDir = $candidate } }

Write-Host "==== AIRHMI run-sim ====" -ForegroundColor Magenta
Write-Host "Project : $ProjectFile"
Write-Host "Export  : $ExportDir"
Write-Host "Designer: $($airEnv.DesignerVersion)  headless=$($airEnv.HeadlessExport)"

# ---- 1) lint -----------------------------------------------------------------------------------------------
if (-not $SkipLint) {
    Step 1 'lint-project.ps1'
    & (Join-Path $PSScriptRoot 'lint-project.ps1') -ProjectFile $ProjectFile
    if ($LASTEXITCODE -ne 0) { throw "lint found errors - fix them before exporting." }
    Ok 'lint clean'
}

# ---- 2) export ---------------------------------------------------------------------------------------------
Step 2 'export'
$manifest = Join-Path $ExportDir 'export-manifest.json'
$resultFile = Join-Path $ExportDir 'export-result.json'
if ($airEnv.HeadlessExport) {
    if (Test-Path -LiteralPath $resultFile) { Remove-Item -LiteralPath $resultFile -Force }
    $designerArgs = @('--open-project', "`"$ProjectFile`"", '--export-sim-out', "`"$ExportDir`"")
    if ($NoDebugInfo) { $designerArgs += '--no-debug-info' }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $proc = Start-Process -FilePath $airEnv.DesignerExe -ArgumentList $designerArgs -PassThru -Wait -WindowStyle Hidden
    $code = $proc.ExitCode
    $result = if (Test-Path -LiteralPath $resultFile) { Get-Content -LiteralPath $resultFile -Raw -Encoding UTF8 | ConvertFrom-Json } else { $null }
    if ($result) {
        foreach ($issue in @($result.validation.issues)) {
            $color = if ($issue.severity -eq 'Error') { 'Red' } else { 'Yellow' }
            Write-Host ("    {0,-7} {1} {2}: {3}" -f $issue.severity, $issue.code, $issue.reference, $issue.message) -ForegroundColor $color
        }
        foreach ($line in @($result.outputLines)) { if ($line -match 'fail|error|Error') { Write-Host "    > $line" -ForegroundColor Red } }
    }
    switch ($code) {
        0 { Ok ("export done in {0:n1} s -> {1}" -f $sw.Elapsed.TotalSeconds, $ExportDir) }
        1 { throw 'Designer validation reported errors (see above) - nothing was exported.' }
        2 { throw "Designer could not open the project: $($result.error)" }
        default { throw "Export failed (exit $code): $($result.error)" }
    }
} else {
    $before = if (Test-Path -LiteralPath $manifest) { (Get-Item -LiteralPath $manifest).LastWriteTimeUtc } else { [DateTime]::MinValue }
    Warn2 "Designer $($airEnv.DesignerVersion) has no command-line export. Please:"
    Write-Host "       1. open $ProjectFile in Designer"
    Write-Host "       2. Simulator panel -> set export path to $ExportDir (once)"
    Write-Host "       3. press Export (or Run). Waiting up to $ManualExportTimeoutSec s for export-manifest.json ..."
    if (-not (Get-Process AirHMI.Designer.App -ErrorAction SilentlyContinue)) {
        Start-Process -FilePath $airEnv.DesignerExe -ArgumentList @('--open-project', "`"$ProjectFile`"") | Out-Null
    }
    $deadline = (Get-Date).AddSeconds($ManualExportTimeoutSec); $done = $false
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Milliseconds 1000
        if ((Test-Path -LiteralPath $manifest) -and (Get-Item -LiteralPath $manifest).LastWriteTimeUtc -gt $before) { $done = $true; break }
    }
    if (-not $done) { throw 'No new export detected (export-manifest.json unchanged).' }
    Ok 'export detected'
}

# ---- 3) font safety net ------------------------------------------------------------------------------------
$ttfs = @(Get-ChildItem -LiteralPath $projectDir -Filter *.ttf -File -ErrorAction SilentlyContinue)
$fontsDir = Join-Path $projectDir 'fonts'
if (Test-Path -LiteralPath $fontsDir) { $ttfs += @(Get-ChildItem -LiteralPath $fontsDir -Filter *.ttf -File) }
foreach ($ttf in $ttfs) {
    $dst = Join-Path $ExportDir $ttf.Name
    if (-not (Test-Path -LiteralPath $dst)) { Copy-Item -LiteralPath $ttf.FullName -Destination $dst; Ok "font copied -> $($ttf.Name)" }
}

if ($NoLaunch) { Write-Host "`n-NoLaunch: simulator not started." -ForegroundColor Yellow; exit 0 }

# ---- 4) simulator ------------------------------------------------------------------------------------------
Step 3 'simulator'
if (-not $airEnv.SimulatorExe) { throw 'Simulator exe not found (see env-check.ps1).' }
if ($ExportDir -ne $airEnv.ExportDir) { Warn2 "Simulator reads $($airEnv.ExportDir); you exported to $ExportDir (SD card / custom). Not launching." ; exit 0 }
Get-Process Airhmi_Simulator -ErrorAction SilentlyContinue | ForEach-Object { try { $_.Kill(); $_.WaitForExit(3000) } catch {} }
$logFile = Join-Path $env:TEMP ("airhmi_sim_{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$spArgs = @{ FilePath = $airEnv.SimulatorExe; WorkingDirectory = (Split-Path -Parent $airEnv.SimulatorExe); RedirectStandardOutput = $logFile; RedirectStandardError = "$logFile.err"; PassThru = $true }
if ($SdDir) { if (-not (Test-Path -LiteralPath $SdDir)) { throw "SdDir not found: $SdDir" }; $spArgs.ArgumentList = @('--sd', ('"' + $SdDir.TrimEnd('\') + '"')) }
$proc = Start-Process @spArgs
Ok "started PID $($proc.Id)  log: $logFile$(if ($SdDir) { "  (SD: $SdDir)" })"

$deadline = (Get-Date).AddSeconds(10); $title = ''
while ((Get-Date) -lt $deadline) {
    Start-Sleep -Milliseconds 400
    $p = Get-Process -Id $proc.Id -ErrorAction SilentlyContinue
    if (-not $p) { break }
    if ($p.MainWindowTitle) { $title = $p.MainWindowTitle }
    if ($title -and (Test-Path -LiteralPath $logFile) -and (Get-Item -LiteralPath $logFile).Length -gt 500) { break }
}
if ($title) { Write-Host "    window  : $title" -ForegroundColor Green } else { Warn2 'no window title yet (simulator may still be starting)' }
$errs = 0
foreach ($f in @($logFile, "$logFile.err")) {
    if (Test-Path -LiteralPath $f) { $errs += @(Select-String -Path $f -Pattern 'illegal character|PCC1|Exception|Unhandled|Hata:' -ErrorAction SilentlyContinue).Count }
}
if ($errs -eq 0) { Ok 'log scan: 0 problems'; Write-Host "`nOK - simulator running. Socket 8890 ready for tests." -ForegroundColor Green; exit 0 }
Warn2 "log scan: $errs problem line(s) - see $logFile"; exit 1
