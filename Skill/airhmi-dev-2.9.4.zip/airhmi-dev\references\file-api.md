# File API — `Fs_*` (flash + SD card), recipes, simulator mapping

> Firmware V6.04 or newer (Designer 2.9.3+ completion). 22 functions with one path rule and a return
> value on every call. They replace the old `File_*` family: the old names still compile but Designer
> flags them with the `LEGACY_FILE_API` warning and completion no longer offers them.

## 1. Paths
Every path **starts with a drive letter**: `C:` = root of the device's internal SPI flash (the whole
flash, system files included), `D:` = SD card. Case does not matter, `/` is converted to `\`, double
separators collapse, max **199 characters**. In C write `"D:/log/a.txt"` (or `"D:\\log\\a.txt"`).
`Fs_Write/Append/WriteAt/Copy/Rename/Unzip` create missing target folders.

⚠️ `C:` is the whole flash — a wrong `Fs_Delete/Fs_DeleteTree/Fs_Write/Fs_Rename` under `C:` can damage
files the device needs. Keep your own files in `C:/user/`.

## 2. Return values
| Kind | Success | Error / not found |
|---|---|---|
| counts / sizes (`Fs_Read`, `Fs_Size`, `Fs_FreeKB` …) | `0` or positive | `-1` |
| yes/no (`Fs_Exists`, `Fs_Delete`, `Fs_Copy` …) | `1` | `0` |

⚠️ **Buffer size is your responsibility**: pass the array's real size (or less) as `size`; the runtime
cannot see the array and a larger `size` overwrites neighbouring variables.

## 3. Functions
| Function | Signature | Meaning |
|---|---|---|
| `Fs_Read` / `Fs_Write` / `Fs_Append` | `(path, buffer, size)` | read / rewrite / append; bytes or `-1` |
| `Fs_ReadAt` / `Fs_WriteAt` | `(path, offset, buffer, size)` | read from / write at a position |
| `Fs_ReadLine` | `(path, offset, buffer, size)` | one line; returns the offset of the next line, `0` at the end |
| `Fs_Size` / `Fs_Exists` | `(path)` | size (`-1` missing) / `1`/`0` |
| `Fs_Delete` / `Fs_DeleteTree` | `(path)` | delete a file or empty folder / a folder with contents |
| `Fs_Copy` / `Fs_Rename` | `(src, dst)` | copy (flash ↔ SD allowed) / rename or move (same drive) |
| `Fs_List` | `(dirPath, buffer, size)` | folder contents, one name per line |
| `Fs_ListFilter` | `(dirPath, pattern, sort, buffer, size)` | `*.csv` style filter; `sort` by name/date/size (`3` = oldest first) |
| `Fs_MakeDir` | `(dirPath)` | nested folders |
| `Fs_DirInfo` | `(dirPath, &fileCount, &totalKB)` | |
| `Fs_DriveReady` / `Fs_FreeKB` / `Fs_TotalKB` | `(drive)` e.g. `"D:"` | |
| `Fs_Crc32` / `Fs_Md5` | `(path, hex)` | `char hex[9]` / `char hex[33]` |
| `Fs_Unzip` | `(zipPath, dirPath)` | number of files extracted |

## 4. Recipes
```c
// CSV line by line
int pos = 0; char line[128];
while (1) { pos = Fs_ReadLine("D:/log/day.csv", pos, line, 128); if (pos <= 0) break; /* use line */ }

// Log line (frequently written data → SD)
char row[64]; sprintf(row, "%d,%d\n", counter, value);
Fs_Append("D:/log/day.csv", row, strlen(row));

// Settings that change rarely → flash
Fs_Write("C:/user/settings.txt", settings, strlen(settings));
n = Fs_Read("C:/user/settings.txt", settings, 64);

// Keep the newest 30 logs: with sort=3 the first line is the oldest file
char list[512], name[64], path[80]; int n, i = 0;
n = Fs_ListFilter("D:/log", "*.csv", 3, list, 512);
if (n > 30) { while (list[i] != '\n' && i < 63) { name[i] = list[i]; i++; } name[i] = 0;
              sprintf(path, "D:/log/%s", name); Fs_Delete(path); }

// Update package: verify, then extract
char md5[33];
if (Fs_Md5("D:/package.zip", md5) == 1 && strcmp(md5, "expected32hex") == 0) { Fs_Unzip("D:/package.zip", "D:/package"); }

// SD present and space left?
if (Fs_DriveReady("D:") == 1 && Fs_FreeKB("D:") > 1024) { /* write */ }
```
Persisting a single variable is simpler with `VariableSave("name")` (`script-api.md` §1b).

## 5. Performance (the screen freezes while a script runs)
| Operation | SD `D:` | Flash `C:` |
|---|---|---|
| read / size / list | 5–12 ms | ~45 ms |
| write | 17–33 ms (4 KB ≈ 90 ms) | ~550 ms |
| append | 17–33 ms | ~220 ms |
| delete | 17–33 ms | ~330 ms |
| make folder | — | ~820 ms |
- First new file/folder on SD after boot can take **~2.7 s**.
- Flash cost is per operation, not per byte: unzip of 3 files to flash ≈ 4.4 s, delete-tree ≈ 2.5 s.
- Rule: logs and counters → SD; rarely changing settings → flash; no heavy file work in fast timers.

## 6. Simulator
| | Simulator |
|---|---|
| `D:` | the SD folder (`run-sim.ps1` passes `<project>\sd_card`; default `C:\Users\Public\airhmi\sd_card`) |
| `C:` | `C:\Users\Public\airhmi\flash` |
| `Fs_DriveReady("D:")` | always `1` |
| `Fs_FreeKB` / `Fs_TotalKB` | the PC disk |
| rules and return values | identical to the device |

## 7. Migrating `File_*` code
| Old | New |
|---|---|
| `File_read(name, buf, n)` / `File_write(name, data, n)` | `Fs_Read("C:/user/name", …)` / `Fs_Write("C:/user/name", …)` |
| `File_readSD(name, buf, n)` / `File_writeSD(name, data, n)` | `Fs_Read("D:/name", …)` / `Fs_Append("D:/name", …)` (the old one appended too) |
| `File_Size`, `File_SizeSD`, `File_IsExist` | `Fs_Size`, `Fs_Exists` with a drive path |
| `File_CopyFlash2SD(s, d)` / `File_CopySD2Flash(s, d)` / `File_Copy` | `Fs_Copy("C:/user/s", "D:/d")` etc. |
| `File_Delete`, `File_DeleteSD` | `Fs_Delete` with a drive path |
Known defects of the old family (reasons to migrate): a file written with `File_write` is not found by
`File_Size`/`File_IsExist`; `File_CopyFlash2SD` deletes the target when the source is missing.
