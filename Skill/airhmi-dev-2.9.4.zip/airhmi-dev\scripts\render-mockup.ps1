﻿<#
.SYNOPSIS
    Renders an HTML mockup screen to PNG at device resolution with headless Microsoft Edge (or Chrome).

.DESCRIPTION
    Used for (a) the approved mockup screenshot (test\shots\mockup\<Screen>.png) and (b) the baked
    background (-HideDynamic hides [data-dynamic] elements; output goes to img\<Screen>_bg.png).
    Resolution is read from the project file when -ProjectFile is given, else -Width/-Height (default 800x480).
    If no browser is found the script tells you how to take the screenshot manually.

.PARAMETER Html         mockup\<Screen>.html
.PARAMETER Out          output PNG
.PARAMETER HideDynamic  hide [data-dynamic] elements (background bake)
.PARAMETER ProjectFile  read device.width/height from the project
.PARAMETER Width/Height resolution override

.EXAMPLE
    .\render-mockup.ps1 -Html .\mockup\MainScreen.html -Out .\test\shots\mockup\MainScreen.png -ProjectFile .\Panel.airhmi.json
.EXAMPLE
    .\render-mockup.ps1 -Html .\mockup\MainScreen.html -Out .\img\MainScreen_bg.png -HideDynamic -Width 800 -Height 480
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Html,
    [Parameter(Mandatory = $true)][string]$Out,
    [switch]$HideDynamic,
    [string]$ProjectFile = '',
    [int]$Width = 0,
    [int]$Height = 0,
    [int]$WaitMs = 800
)

$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $Html)) { throw "HTML not found: $Html" }
if ($ProjectFile -and (Test-Path -LiteralPath $ProjectFile)) {
    $p = Get-Content -LiteralPath $ProjectFile -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($Width -eq 0) { $Width = [int]$p.device.width }
    if ($Height -eq 0) { $Height = [int]$p.device.height }
}
if ($Width -eq 0) { $Width = 800 }
if ($Height -eq 0) { $Height = 480 }

$browser = @(
    "$env:ProgramFiles (x86)\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
) | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $browser) {
    Write-Host "No Edge/Chrome found. Manual fallback: open $Html in a browser at 100% zoom, use DevTools device" -ForegroundColor Yellow
    Write-Host "toolbar with ${Width}x${Height}, 'Capture screenshot', and save as $Out" -ForegroundColor Yellow
    exit 3
}

$source = (Resolve-Path -LiteralPath $Html).Path
$workHtml = $source
$tmp = $null
if ($HideDynamic) {
    # inject a style that hides dynamic elements; keep relative asset paths by writing next to the source
    $tmp = Join-Path (Split-Path -Parent $source) ("~bake_" + [IO.Path]::GetFileName($source))
    $text = Get-Content -LiteralPath $source -Raw -Encoding UTF8
    $style = '<style data-bake>[data-dynamic]{visibility:hidden !important;}</style>'
    if ($text -match '</head>') { $text = $text -replace '</head>', ($style + '</head>') } else { $text = $style + $text }
    [IO.File]::WriteAllText($tmp, $text, [Text.UTF8Encoding]::new($false))
    $workHtml = $tmp
}

$outFull = [IO.Path]::GetFullPath($Out)
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $outFull) | Out-Null
$uri = ([Uri]$workHtml).AbsoluteUri
$args = @('--headless=new', '--disable-gpu', '--hide-scrollbars', '--force-device-scale-factor=1', "--window-size=$Width,$Height", "--virtual-time-budget=$WaitMs", "--screenshot=$outFull", $uri)
try {
    $proc = Start-Process -FilePath $browser -ArgumentList $args -PassThru -Wait -WindowStyle Hidden
} finally {
    if ($tmp -and (Test-Path -LiteralPath $tmp)) { Remove-Item -LiteralPath $tmp -Force }
}
if (-not (Test-Path -LiteralPath $outFull)) { throw "Screenshot was not produced (browser exit $($proc.ExitCode))." }

Add-Type -AssemblyName System.Drawing
$bmp = [System.Drawing.Bitmap]::FromFile($outFull)
$w = $bmp.Width; $h = $bmp.Height; $bmp.Dispose()
if ($w -ne $Width -or $h -ne $Height) {
    # headless chrome sometimes adds a few px; crop to the exact device size
    $src = [System.Drawing.Bitmap]::FromFile($outFull)
    $crop = $src.Clone([System.Drawing.Rectangle]::new(0, 0, [Math]::Min($Width, $w), [Math]::Min($Height, $h)), $src.PixelFormat)
    $src.Dispose()
    $crop.Save($outFull + '.tmp.png', [System.Drawing.Imaging.ImageFormat]::Png); $crop.Dispose()
    Move-Item -LiteralPath ($outFull + '.tmp.png') -Destination $outFull -Force
    Write-Host "cropped $w x $h -> $Width x $Height"
}
Write-Host "Rendered: $outFull ($Width x $Height$(if ($HideDynamic) { ', dynamic hidden' }))"
