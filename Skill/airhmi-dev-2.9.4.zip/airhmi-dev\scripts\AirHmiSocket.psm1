﻿# AirHmiSocket.psm1 - PowerShell client for the AIRHMI simulator command socket (TCP 127.0.0.1:8890).
# Import-Module "<skill>\scripts\AirHmiSocket.psm1" -Force
# Functions: Send-Hmi, Get-HmiScreen, Wait-Screen, Touch-Hmi, Set-HmiVar, Get-HmiVar, Test-HmiSocket

$script:HmiHost = '127.0.0.1'
$script:HmiPort = 8890

function Set-HmiEndpoint {
    param([string]$HostName = '127.0.0.1', [int]$Port = 8890)
    $script:HmiHost = $HostName
    $script:HmiPort = $Port
}

function Send-Hmi {
    <#
    .SYNOPSIS Sends one command to the simulator and returns the trimmed reply (one connection per command).
    .EXAMPLE Send-Hmi 'LabelSet("lblStatus","Text","Ready");'
    .EXAMPLE Send-Hmi 'MainScreen,,,ChangeScreenSet,,'
    .EXAMPLE Send-Hmi '?button1.Text'
    #>
    param(
        [Parameter(Mandatory = $true)][string]$Command,
        [int]$SettleMs = 120,
        [int]$TimeoutMs = 3000
    )
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $client.Connect($script:HmiHost, $script:HmiPort)
        $client.ReceiveTimeout = $TimeoutMs
        $client.SendTimeout = $TimeoutMs
        $stream = $client.GetStream()
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Command)
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush()
        Start-Sleep -Milliseconds $SettleMs
        $response = ''
        $buffer = New-Object byte[] 8192
        $deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMs)
        while ([DateTime]::UtcNow -lt $deadline) {
            if ($stream.DataAvailable) {
                $n = $stream.Read($buffer, 0, $buffer.Length)
                if ($n -le 0) { break }
                $response += [System.Text.Encoding]::UTF8.GetString($buffer, 0, $n)
                Start-Sleep -Milliseconds 30
                if (-not $stream.DataAvailable) { break }
            } else {
                if ($response.Length -gt 0) { break }
                Start-Sleep -Milliseconds 20
            }
        }
        return $response.Trim()
    } finally {
        $client.Close()
    }
}

function Test-HmiSocket {
    <# .SYNOPSIS True when the simulator socket answers. #>
    try {
        $client = New-Object System.Net.Sockets.TcpClient
        $async = $client.BeginConnect($script:HmiHost, $script:HmiPort, $null, $null)
        $ok = $async.AsyncWaitHandle.WaitOne(1000)
        $client.Close()
        return $ok
    } catch { return $false }
}

function Get-HmiScreen {
    <# .SYNOPSIS Name of the active screen. #>
    return (Send-Hmi ',,,ScreenGet,,')
}

function Wait-Screen {
    <# .SYNOPSIS Polls ScreenGet until the given screen is active. Returns $true/$false. #>
    param([Parameter(Mandatory = $true)][string]$Name, [int]$TimeoutMs = 3000, [int]$PollMs = 50)
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($sw.ElapsedMilliseconds -lt $TimeoutMs) {
        if ((Get-HmiScreen) -eq $Name) { return $true }
        Start-Sleep -Milliseconds $PollMs
    }
    return $false
}

function Touch-Hmi {
    <# .SYNOPSIS Tap (press+release) at HMI coordinates; -Press / -Release for hold scenarios. #>
    param([Parameter(Mandatory = $true)][int]$X, [Parameter(Mandatory = $true)][int]$Y, [switch]$Press, [switch]$Release)
    $verb = 'Touch'
    if ($Press) { $verb = 'Press' } elseif ($Release) { $verb = 'Release' }
    return (Send-Hmi "$verb,$X,$Y,,,")
}

function Set-HmiVar {
    <# .SYNOPSIS Writes a project variable (comma format - the only format that really writes). #>
    param([Parameter(Mandatory = $true)][string]$Name, [Parameter(Mandatory = $true)][string]$Value)
    return (Send-Hmi "$Name,$Value,,VarSet,,")
}

function Get-HmiVar {
    <# .SYNOPSIS Reads a project variable. Returns the value part of "type,value". #>
    param([Parameter(Mandatory = $true)][string]$Name)
    $raw = Send-Hmi "$Name,,,VarGet,,"
    if ($raw -match '^\d+,(.*)$') { return $matches[1] }
    return $raw
}

Export-ModuleMember -Function Set-HmiEndpoint, Send-Hmi, Test-HmiSocket, Get-HmiScreen, Wait-Screen, Touch-Hmi, Set-HmiVar, Get-HmiVar
