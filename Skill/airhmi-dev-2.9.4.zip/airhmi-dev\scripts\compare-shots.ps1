﻿<#
.SYNOPSIS
    Builds the side-by-side comparison image for one screen: mockup | simulator | (device).

.DESCRIPTION
    Looks in <ShotsDir>\mockup, \sim, \device for <Screen>[_<Theme>].png (device may be .bmp from
    ScreenCapture; it is converted). Writes <ShotsDir>\compare\<Screen>[_<Theme>]\compare.png with labelled
    columns and copies the inputs next to it as 1_html.png / 2_sim.png / 3_device.png. Prints a rough pixel
    difference percentage between mockup and simulator (information only - judge by eye).

.PARAMETER Screen    Screen name (file stem)
.PARAMETER ShotsDir  default: .\test\shots
.PARAMETER Theme     optional theme suffix (<Screen>_<Theme>.png)

.EXAMPLE
    .\compare-shots.ps1 -Screen MainScreen -ShotsDir C:\Projects\Panel\test\shots
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Screen,
    [string]$ShotsDir = (Join-Path (Get-Location).Path 'test\shots'),
    [string]$Theme = ''
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$stem = if ($Theme) { "${Screen}_$Theme" } else { $Screen }

function Find-Shot([string]$sub) {
    foreach ($ext in @('png', 'bmp', 'jpg')) {
        $p = Join-Path (Join-Path $ShotsDir $sub) "$stem.$ext"
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}

$sources = @(
    @{ Label = '1 mockup (HTML)'; Path = (Find-Shot 'mockup'); Out = '1_html.png' },
    @{ Label = '2 simulator';     Path = (Find-Shot 'sim');    Out = '2_sim.png' },
    @{ Label = '3 device';        Path = (Find-Shot 'device'); Out = '3_device.png' }
) | Where-Object { $_.Path }
if ($sources.Count -lt 2) { throw "Need at least mockup and simulator shots for '$stem' under $ShotsDir (found: $($sources.Count))." }

$outDir = Join-Path (Join-Path $ShotsDir 'compare') $stem
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

$images = @()
foreach ($s in $sources) {
    $bmp = [System.Drawing.Bitmap]::FromFile($s.Path)
    $copy = New-Object System.Drawing.Bitmap $bmp   # detach from file
    $bmp.Dispose()
    $copy.Save((Join-Path $outDir $s.Out), [System.Drawing.Imaging.ImageFormat]::Png)
    $images += @{ Label = $s.Label; Bitmap = $copy }
}

$gap = 16; $labelH = 28
[int]$w = ($images | ForEach-Object { $_.Bitmap.Width } | Measure-Object -Sum).Sum + $gap * ($images.Count + 1)
[int]$h = ($images | ForEach-Object { $_.Bitmap.Height } | Measure-Object -Maximum).Maximum + $labelH + $gap * 2
$sheet = New-Object System.Drawing.Bitmap -ArgumentList ([int]$w), ([int]$h)
$g = [System.Drawing.Graphics]::FromImage($sheet)
$g.Clear([System.Drawing.Color]::FromArgb(255, 40, 40, 44))
$font = New-Object System.Drawing.Font 'Segoe UI', 12
$brush = [System.Drawing.Brushes]::White
$x = $gap
foreach ($img in $images) {
    $g.DrawString($img.Label, $font, $brush, $x, $gap / 2)
    $g.DrawImage($img.Bitmap, $x, $labelH + $gap, $img.Bitmap.Width, $img.Bitmap.Height)
    $x += $img.Bitmap.Width + $gap
}
$g.Dispose()
$sheetPath = Join-Path $outDir 'compare.png'
$sheet.Save($sheetPath, [System.Drawing.Imaging.ImageFormat]::Png)
$sheet.Dispose()

# rough difference mockup vs simulator (same size required)
$a = $images[0].Bitmap; $b = $images[1].Bitmap
if ($a.Width -eq $b.Width -and $a.Height -eq $b.Height) {
    $step = [Math]::Max(1, [int]($a.Width / 200)); $diff = 0; $total = 0
    for ($yy = 0; $yy -lt $a.Height; $yy += $step) {
        for ($xx = 0; $xx -lt $a.Width; $xx += $step) {
            $pa = $a.GetPixel($xx, $yy); $pb = $b.GetPixel($xx, $yy)
            $d = [Math]::Abs($pa.R - $pb.R) + [Math]::Abs($pa.G - $pb.G) + [Math]::Abs($pa.B - $pb.B)
            if ($d -gt 60) { $diff++ }
            $total++
        }
    }
    $pct = [Math]::Round(100.0 * $diff / [Math]::Max(1, $total), 1)
    Write-Host ("mockup vs simulator: ~{0}% of sampled pixels differ (information only)" -f $pct)
} else {
    Write-Host ("size mismatch: mockup {0}x{1}, simulator {2}x{3} - check device resolution" -f $a.Width, $a.Height, $b.Width, $b.Height) -ForegroundColor Yellow
}
foreach ($img in $images) { $img.Bitmap.Dispose() }
Write-Host "compare sheet: $sheetPath"
