﻿<#
.SYNOPSIS
    Static checks on an .airhmi.json project that catch the mistakes Designer's validator does not
    (or reports too late). Run before every export.

.DESCRIPTION
    Checks (ERR = must fix, WARN = look at it):
      ERR  JSON parses; format/version/screens present; device.width/height match the profile table
      ERR  componentType is a known type (exact spelling: EListWhell, EveGauge, EveSlider, EveProgressBar, ESevenSeg, EQR)
      ERR  component name unique across the project and a C identifier; ownerScreen equals the screen name
      ERR  screen name <= 20 chars, unique, C identifier; openFirstScreen exists
      ERR  order of visual components per screen is 0..N-1 without gaps/duplicates (background first)
      ERR  colour fields are integers (not "#RRGGBB" strings)
      ERR  image references: pictureName "id:x" / backgroundImage "id:x" exist in resources.images[] and the file exists
      ERR  ChangeScreenSet("X") targets an existing screen; ScreenSet( / LabelSets( with 3 args flagged
      ERR  component outside the screen bounds
      WARN ELabel used for text (prefer ELabelBox); EShape with non-default colours
      WARN scaleX/scaleY = 0 on EImage; relativePath not relative; listFile not found in sd_card\
      WARN non-Roboto fontName without <font>.ttf in project / fonts\ (Designer 2.8 copies from Windows Fonts)
      WARN Unicode sub/superscript characters in captions; empty event strings
      WARN schema violations of obvious kinds (unknown top-level keys)

.PARAMETER ProjectFile   Path to the .airhmi.json
.PARAMETER AsJson        Emit findings as JSON instead of text
.OUTPUTS  Exit code 0 = no errors (warnings allowed), 1 = errors found, 2 = file/parse problem

.EXAMPLE
    .\lint-project.ps1 -ProjectFile C:\Projects\Panel\Panel.airhmi.json
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$ProjectFile,
    [switch]$AsJson
)

$ErrorActionPreference = 'Stop'
$findings = New-Object System.Collections.Generic.List[object]
function Add-Finding([string]$Level, [string]$Where, [string]$Message) {
    $findings.Add([pscustomobject]@{ level = $Level; where = $Where; message = $Message })
}

if (-not (Test-Path -LiteralPath $ProjectFile)) { Write-Host "ERR project file not found: $ProjectFile"; exit 2 }
$projectDir = Split-Path -Parent (Resolve-Path -LiteralPath $ProjectFile)
try {
    $raw = Get-Content -LiteralPath $ProjectFile -Raw -Encoding UTF8
    $p = $raw | ConvertFrom-Json
} catch { Write-Host "ERR JSON parse failed: $($_.Exception.Message)"; exit 2 }

# --- known types and the colour / visual tables -----------------------------------------------------------
$knownTypes = @('EButton','ELabel','ELabelBox','EImage','EShape','EveGauge','EArc','ELine','EGraph','EBarChart','EPieChart','EQR','EToggle','ELed','ESevenSeg','ESpinner','EMultiIcon','EveSlider','EveProgressBar','EListView','EListWhell','ETimer','EVariable','EFile','ESound','EVideo')
$nonVisual = @('ETimer','EVariable','EFile','ESound')
$colourFields = @('color','colorTo','borderColor','pressColor','pressColorTo','pressFontColor','fontColor','fillColor','backgroundColor','needleColor','needleCenterColor','trackColor','valueColor','lineColor','line1Color','line2Color','line3Color','line4Color','headerBackgroundColor','headerFontColor','gridFontColor','selectedItemColor','selectedColor','unselectedColor','separatorColor','thumbColor','backgroundColorOff','backgroundColorOn','onColor','offColor','barColor','axisColor','buttonColor','blendColor')
$profiles = @{ 'AIRHMI_4_3' = @(480,272); 'AIRHMI_5' = @(800,480); 'AIRHMI_7' = @(800,480); 'AIRHMI_10' = @(1024,600) }
$identifier = '^[A-Za-z_][A-Za-z0-9_]*$'

# --- project level --------------------------------------------------------------------------------------------
if ($p.format -eq 'legacy-ahi') { Add-Finding WARN 'project' "format 'legacy-ahi': converted from an old .ahi (see legacy-ahi-migration.md); run the post-import checklist, then File > Save in Designer" }
elseif ($p.format -ne 'airhmi-project') { Add-Finding ERR 'project' "format must be 'airhmi-project' (got '$($p.format)')" }
if ($p.version -ne 2) { Add-Finding ERR 'project' "version must be 2" }
if (-not $p.screens -or @($p.screens).Count -eq 0) { Add-Finding ERR 'project' 'no screens'; }
if ($p.device) {
    if ($profiles.ContainsKey([string]$p.device.profile)) {
        $exp = $profiles[[string]$p.device.profile]
        if ([int]$p.device.width -ne $exp[0] -or [int]$p.device.height -ne $exp[1]) {
            Add-Finding ERR 'device' "profile $($p.device.profile) expects $($exp[0])x$($exp[1]), project says $($p.device.width)x$($p.device.height)"
        }
    } else { Add-Finding WARN 'device' "unknown device profile '$($p.device.profile)' (AIRHMI_4_3 / AIRHMI_5 / AIRHMI_7 / AIRHMI_10)" }
} else { Add-Finding ERR 'project' 'device block missing' }

$screenNames = @($p.screens | ForEach-Object { [string]$_.name })
$dupScreens = $screenNames | Group-Object | Where-Object Count -gt 1
foreach ($g in $dupScreens) { Add-Finding ERR 'screens' "duplicate screen name '$($g.Name)'" }
if ($p.openFirstScreen -and ($screenNames -notcontains [string]$p.openFirstScreen)) { Add-Finding ERR 'project' "openFirstScreen '$($p.openFirstScreen)' is not a screen" }

# image resources
$imageIds = @{}
if ($p.resources -and $p.resources.images) {
    foreach ($img in $p.resources.images) {
        $imageIds[[string]$img.id] = $img
        if ($img.relativePath) {
            if ([IO.Path]::IsPathRooted([string]$img.relativePath)) { Add-Finding WARN "resources.images/$($img.id)" "relativePath is absolute; must be relative to the project folder" }
            elseif (-not (Test-Path -LiteralPath (Join-Path $projectDir $img.relativePath))) { Add-Finding ERR "resources.images/$($img.id)" "file not found: $($img.relativePath)" }
            elseif ([IO.Path]::GetExtension([string]$img.relativePath).ToLower() -ne '.png') { Add-Finding WARN "resources.images/$($img.id)" "Designer accepts PNG only ($($img.relativePath))" }
        }
    }
}
function Test-ImageRef([string]$where, [string]$ref) {
    if (-not $ref) { return }
    if ($ref -like 'id:*') {
        $id = $ref.Substring(3)
        if (-not $imageIds.ContainsKey($id)) { Add-Finding ERR $where "image reference '$ref' has no resources.images[] entry (id rule: img_<name lowercased, non-alnum -> _>)" }
    } elseif ($ref -match '[\\/]' ) {
        Add-Finding ERR $where "pictureName/backgroundImage must be 'id:<resource id>', not a path ('$ref')"
    }
}

# all component names (project-wide uniqueness)
$allNames = @{}
$allComponents = @()
foreach ($s in $p.screens) { foreach ($c in @($s.components)) { $allComponents += $c; $n = [string]$c.name; if ($allNames.ContainsKey($n)) { $allNames[$n]++ } else { $allNames[$n] = 1 } } }
foreach ($v in @($p.globalVariables) + @($p.globalTimers)) { if ($v) { $n = [string]$v.name; if ($allNames.ContainsKey($n)) { $allNames[$n]++ } else { $allNames[$n] = 1 } } }
foreach ($kv in $allNames.GetEnumerator()) { if ($kv.Value -gt 1) { Add-Finding ERR "component/$($kv.Key)" "name used $($kv.Value) times (names must be unique across the project)" } }

$fontNames = @{}

foreach ($s in $p.screens) {
    $sn = [string]$s.name
    $sw = if ($s.width) { [int]$s.width } else { [int]$p.device.width }
    $sh = if ($s.height) { [int]$s.height } else { [int]$p.device.height }
    if (-not $sn) { Add-Finding ERR 'screen' 'screen without a name'; continue }
    if ($sn.Length -gt 20) { Add-Finding ERR "screen/$sn" "name longer than 20 characters (firmware buffer)" }
    if ($sn -notmatch $identifier) { Add-Finding ERR "screen/$sn" "name must be a C identifier (letters/digits/_, no spaces)" }
    Test-ImageRef "screen/$sn" ([string]$s.backgroundImage)
    if ($s.backgroundPictureHex) { Add-Finding WARN "screen/$sn" "backgroundPictureHex is a legacy field - use backgroundImage + resources.images" }

    $orders = @()
    foreach ($c in @($s.components)) {
        $cn = [string]$c.name; $ct = [string]$c.componentType
        $where = "$sn/$cn"
        if (-not $cn) { Add-Finding ERR "$sn/?" 'component without a name'; continue }
        if ($cn -notmatch $identifier) { Add-Finding ERR $where "name must be a C identifier (dot syntax needs it)" }
        if ($knownTypes -notcontains $ct) { Add-Finding ERR $where "unknown componentType '$ct' (check spelling: EListWhell, EveGauge, EveSlider, EveProgressBar, ESevenSeg, EQR)" }
        if ([string]$c.ownerScreen -ne $sn) { Add-Finding ERR $where "ownerScreen '$($c.ownerScreen)' must equal the screen name '$sn'" }
        if ($nonVisual -notcontains $ct) {
            $orders += [int]$c.order
            $l = [int]$c.left; $t = [int]$c.top; $w = [int]$c.width; $h = [int]$c.height
            if ($w -le 0 -or $h -le 0) { Add-Finding ERR $where "width/height must be > 0" }
            if ($l -lt 0 -or $t -lt 0 -or ($l + $w) -gt $sw -or ($t + $h) -gt $sh) { Add-Finding ERR $where "outside the ${sw}x${sh} screen (left=$l top=$t w=$w h=$h)" }
        }
        foreach ($f in $colourFields) {
            $v = $c.PSObject.Properties[$f]
            if ($v -and $null -ne $v.Value -and $v.Value -is [string]) { Add-Finding ERR $where "$f must be a signed ARGB int, not '$($v.Value)' (#RRGGBB -> R*65536+G*256+B-16777216)" }
        }
        switch ($ct) {
            'ELabel'  { Add-Finding WARN $where 'ELabel used - prefer ELabelBox for text (keyboard="None" when read-only)' }
            'EShape'  {
                if (($c.PSObject.Properties['borderColor'] -and [int]$c.borderColor -ne -16728065) -or ($c.PSObject.Properties['fillColor'] -and [int]$c.fillColor -ne 540223160)) {
                    Add-Finding WARN $where 'EShape with non-default colours - keep defaults (borderColor -16728065, fillColor 540223160) so it stays visible in Designer'
                }
            }
            'EImage'  {
                Test-ImageRef $where ([string]$c.pictureName)
                if ($c.PSObject.Properties['scaleX'] -and [double]$c.scaleX -eq 0) { Add-Finding WARN $where 'scaleX = 0 hides the image (use 1)' }
                if ($c.PSObject.Properties['scaleY'] -and [double]$c.scaleY -eq 0) { Add-Finding WARN $where 'scaleY = 0 hides the image (use 1)' }
                if ($c.pictureHex) { Add-Finding WARN $where 'pictureHex is a legacy field - use pictureName id: + picturePath' }
            }
            'EveGauge' { Test-ImageRef $where ([string]$c.pictureName) }
            'EListView' {
                if ($c.listFile) {
                    $lf = Join-Path (Join-Path $projectDir 'sd_card') ([string]$c.listFile)
                    if (-not (Test-Path -LiteralPath $lf)) { Add-Finding WARN $where "listFile '$($c.listFile)' not found in sd_card\ (simulator SD root / card root)" }
                }
            }
            'EVariable' {
                if (@('String','int','float','Struct') -notcontains [string]$c.dataType) { Add-Finding ERR $where "dataType must be String | int | float | Struct (got '$($c.dataType)')" }
            }
        }
        # fonts
        foreach ($ff in @('fontName','gridFont')) {
            $fv = $c.PSObject.Properties[$ff]
            if ($fv -and $fv.Value -and ([string]$fv.Value).Trim() -and ([string]$fv.Value).Trim().ToLower() -ne 'roboto') { $fontNames[([string]$fv.Value).Trim()] = $where }
        }
        # captions
        $cap = $c.PSObject.Properties['caption']
        if ($cap -and $cap.Value -and ([string]$cap.Value) -match '[\u2070-\u209F]') { Add-Finding WARN $where 'Unicode sub/superscript characters are not rendered - write CO2 instead of CO\u2082' }
        # events
        if ($c.events) {
            foreach ($ev in $c.events.PSObject.Properties) {
                $code = [string]$ev.Value
                if (-not $code -or $code.Trim() -eq '') { continue }   # Designer itself writes all four keys as "" - normal
                if ($code -match '\.c$' -or $code -match '\.C$') {
                    if (-not (Test-Path -LiteralPath (Join-Path $projectDir $code))) { Add-Finding ERR "$where/$($ev.Name)" "event file not found: $code" }
                    else { $code = Get-Content -LiteralPath (Join-Path $projectDir $code) -Raw -Encoding UTF8 }
                }
                foreach ($m in [regex]::Matches($code, 'ChangeScreenSet\(\s*"([^"]+)"')) {
                    if ($screenNames -notcontains $m.Groups[1].Value) { Add-Finding ERR "$where/$($ev.Name)" "ChangeScreenSet target '$($m.Groups[1].Value)' is not a screen" }
                }
                if ($code -match '(?<![A-Za-z_])ScreenSet\s*\(') { Add-Finding ERR "$where/$($ev.Name)" 'ScreenSet( is not a navigation function - use ChangeScreenSet("Screen")' }
                if ($code -match 'LabelSets\s*\(\s*"[^"]*"\s*,\s*"[^"]*"\s*,') { Add-Finding ERR "$where/$($ev.Name)" 'LabelSets takes 2 arguments (name, string) - use LabelSet(name,"Text",value)' }
                if ($code -match '%g') { Add-Finding WARN "$where/$($ev.Name)" 'sprintf %g is not supported on the device - use %.2f' }
            }
        }
    }
    # order: must be unique per screen (duplicates - typically everything left at 0 in hand-written JSON -
    # break touch routing between EImage and EShape). Gaps are fine; Designer itself numbers across screens.
    if ($orders.Count -gt 1) {
        $dups = $orders | Group-Object | Where-Object Count -gt 1 | ForEach-Object { $_.Name }
        if ($dups) {
            Add-Finding ERR "screen/$sn" "component order values repeat ($($dups -join ', ')) - give every visual component a unique order (background 0, then 1..N)"
        }
    }
}

# fonts present?
foreach ($kv in $fontNames.GetEnumerator()) {
    $fn = $kv.Key
    $found = @((Join-Path $projectDir "$fn.ttf"), (Join-Path $projectDir "fonts\$fn.ttf"), (Join-Path $env:WINDIR "Fonts\$fn.ttf")) | Where-Object { Test-Path -LiteralPath $_ }
    $covered = $false
    if ($p.resources -and $p.resources.fonts) { $covered = @($p.resources.fonts | Where-Object { $_.relativePath -and (($_.name -eq $fn) -or ([IO.Path]::GetFileNameWithoutExtension([string]$_.relativePath) -eq $fn)) }).Count -gt 0 }
    if (-not $found -and -not $covered) { Add-Finding WARN $kv.Value "font '$fn' has no $fn.ttf in the project, fonts\ or Windows Fonts - simulator/device fall back to the default font" }
}

# --- report ---------------------------------------------------------------------------------------------------
$errors = @($findings | Where-Object level -eq 'ERR').Count
$warnings = @($findings | Where-Object level -eq 'WARN').Count
if ($AsJson) {
    [pscustomobject]@{ projectFile = $ProjectFile; errors = $errors; warnings = $warnings; findings = $findings } | ConvertTo-Json -Depth 4
} else {
    foreach ($f in $findings) {
        $color = if ($f.level -eq 'ERR') { 'Red' } else { 'Yellow' }
        Write-Host ("{0,-4} {1}: {2}" -f $f.level, $f.where, $f.message) -ForegroundColor $color
    }
    $summaryColor = if ($errors -eq 0) { 'Green' } else { 'Red' }
    Write-Host ("lint: {0} error(s), {1} warning(s) - {2}" -f $errors, $warnings, (Split-Path -Leaf $ProjectFile)) -ForegroundColor $summaryColor
}
exit $(if ($errors -gt 0) { 1 } else { 0 })
