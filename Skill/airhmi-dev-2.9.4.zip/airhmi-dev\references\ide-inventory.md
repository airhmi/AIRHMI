# Installed AIRHMI Designer — inventory, paths, switches

> Everything the skill relies on from the **installed** product. Verified against Designer 2.8.0 /
> 2.9.4 setups (2026-10). If a path differs on the user's machine, `scripts\env-check.ps1` resolves it
> from `workspace-settings.json`; never hard-code paths from memory.

## Install folder
Default (per-user install): `%LOCALAPPDATA%\Programs\AIRHMI Designer\`
(Admin install: `%ProgramFiles%\AIRHMI Designer\`. The uninstaller `unins000.exe` sits next to the exe.)

| Item | Path (relative to install folder) | Notes |
|---|---|---|
| Designer | `AirHMI.Designer.App.exe` | Single-file app. Version: `(Get-Item $exe).VersionInfo.FileVersion` |
| PCC compiler | `AirHmiCompiler.dll` | Compiles event C code to `.pcc` bytecode; 1.2.0+ supports dot syntax |
| Simulator | `Simulator\Airhmi_Simulator.exe` | + `PccVmCLR.dll`, `PicocCLR.dll` next to it |
| User guide (HTML) | `manual\index.html` → `manual\tr\`, `manual\en\` | Also `Help > User Guide` / F1 in Designer |
| Icon | `AIRHMI.Designer.ico` | |

Not shipped: command-line tools project, example projects (`File > New Project` has starter templates),
firmware, source code. Example projects are on GitHub: `https://github.com/airhmi/AIRHMI` (Examples/).

## User data
| Item | Path |
|---|---|
| Workspace settings | `%APPDATA%\AIRHMI\Designer\workspace-settings.json` |
| Simulator export (default) | `C:\Users\Public\airhmi\simulator` (`SimulatorExportPath`) |
| Simulator SD root (default) | `C:\Users\Public\airhmi\sd_card` — or any folder via `Airhmi_Simulator.exe --sd <dir>` |
| Simulator socket log | `C:\Users\Public\airhmi\socket_debug.log` |
| Debugger state | `C:\Users\Public\airhmi\debugger\` |
| Simulator theme cache | `%APPDATA%\AIRHMI\Designer\simulator-theme.json` |
| Simulator flash root (`C:` of `Fs_*`) | `C:\Users\Public\airhmi\flash` |
| Simulator video log | `C:\Users\Public\airhmi\video_debug.log` |
| Video conversion cache | `%LOCALAPPDATA%\AIRHMI\cache\video\` (override with env `AIRHMI_VIDEO_CACHE_DIR`) |
| Designer FTP upload state (unchanged-video skip) | `%LOCALAPPDATA%\AIRHMI\deploy-state\ftp-<host>-<drive>-<dir>.json` |

`workspace-settings.json` keys the scripts read: `SimulatorExePath`, `SimulatorExportPath`,
`FtpDevice { Host, Port, UserName, Password, DeviceDrive, RemoteDirectory, TimeoutSeconds, ResendUnchangedVideos }`,
`VncDevice { Host, Port, Password, AutoConnect }`, `RecentProjects`. Treat the file as read-only; Designer owns it.

## Designer command-line switches (useful ones)
| Switch | Effect | Since |
|---|---|---|
| `--open-project <file>` | Open a `.airhmi.json` (or `.ahi`) at start | 2.6 |
| `--select-screen <name>` | Select a screen after opening | 2.6 |
| `--export-sim-out <dir>` | **Headless**: validate + export the opened project into `<dir>`, write `<dir>\export-result.json`, exit with code | **2.8.0** |
| `--validate-out <file.json>` | **Headless**: validate only, write result JSON, exit with code | **2.8.0** |
| `--no-debug-info` | Headless export without `.pccdbg` debugger side files (device packages) | 2.8.0 |
| `--exit` | Close when the headless job is done (default when either headless switch is present) | 2.8.0 |
| `--show-serial-terminal` | Open the serial terminal panel | 2.6 |

Exit codes (headless): **0** ok · **1** validation errors (nothing exported) · **2** project not
loaded · **3** exception during export (e.g. compile error in event code) or 120 s timeout.
A headless run shows no window and never writes `workspace-settings.json`.

Example:
```powershell
$designer = "$env:LOCALAPPDATA\Programs\AIRHMI Designer\AirHMI.Designer.App.exe"
& $designer --open-project "C:\Projects\Panel\Panel.airhmi.json" --export-sim-out "C:\Users\Public\airhmi\simulator"
$LASTEXITCODE
```

`export-result.json`: `ok`, `mode` (`export`|`validate`), `exitCode`, `projectPath`, `exportPath`,
`exportManifestPath`, `designerVersion`, `durationMs`, `validation { errors, warnings, issues[] {severity,
code, message, objectName, referenceKind, reference} }`, `outputLines[]` (Designer Output panel lines
written during the job — compiler errors appear here), `error`.

### Designer older than 2.8.0 (no headless switches)
Export is manual: open the project in Designer → Simulator panel → **Export** (or **Run**, which exports
and starts the simulator). `scripts\run-sim.ps1` detects this, prints the instruction and waits until
`<export>\export-manifest.json` changes. Everything else (lint, simulator socket, screenshots, FTP) works.

## Designer windows and features this skill relies on (2.9.x)
| Feature | Where | Since |
|---|---|---|
| Hardware / Startup Settings: Ethernet (None/DHCP/Static), Modbus TCP server, UART framing, GPIO 1–9 direction + start level, PWM 0/1, backlight, volume, user startup code → generated `init.pcc` + `hw.cfg` (`network-api.md` §1) | `Screen > Hardware / Startup Settings...` | 2.9.3 |
| Video canvas object: MP4 resource → `.emf` at export, poster frame, background pre-conversion with progress overlay (`video-object.md`) | toolbox *Media → Video*, `Resources > Add Video` | 2.9.4 |
| VNC viewer: device screen live inside Designer, click = touch (port 5900, password `admin`, Auto reconnect, Fit) | `Tools > VNC Viewer` / toolbar **VNC** | 2.9.4 |
| Context help: **F1** in the code window opens the guide row of the function / `object.Property` / variable under the caret; guide language in *Code Editor Settings* | code window | 2.9.4 |
| Code completion for `ModbusTCP_*`, `SocketTCP_Read/SendRead/Available/CreateTimeout`, `SocketUDP_Read/Available`, `Fs_*`, `Video_*`, `VideoSet/Get`; legacy names (`File_*`, Modbus RTU, `VideoPlay`) compile but are not offered | code window | 2.9.3 |
| Export to Device (FTP): skips `.emf` videos unchanged since the last upload; *Resend unchanged video files* checkbox | `File > Export to Device (FTP)` | 2.9.4 |
| Compiler memory limits: 8192 bytes for all globals, 4096 bytes per function (compile errors, `script-api.md` §1b) | export / `Check C` | 2.9.3 |
| Export progress overlay for background video conversion (Cancel stops the export) | Run / Export | 2.9.4 |

## Export package (what the simulator / device reads)
| File | Meaning |
|---|---|
| `<Screen>.js` | Screen definition (screen + components) |
| `files.ini` | File list; first line = export timestamp |
| `options.ini` | COM port/baud, start screen, theme |
| `Globalvars.js`, `GlobalTimers.js` | Only when the project has globals |
| `*.pcc` (+ `*.pccdbg`) | Compiled event code (+ debugger symbols; dropped with `--no-debug-info`) |
| `*.raw` / `*.jpg`, `*.ttf`, sounds | Images converted to RGB565 raw (or JPEG), fonts, sound files |
| `<Screen>_<Video>.emf`, `<Screen>_<Video>_poster.raw\|jpg` | Converted Video objects: motion-JPEG movie + poster at the object's size; the source MP4 is **not** copied |
| `init.c`, `init.pcc`, `hw.cfg` | Only with Hardware / Startup Settings enabled: generated startup code (kept + compiled) and the GPIO/PWM boot file |
| `export-manifest.json` | `eventFiles[]`, `imageResources[]`, `fonts[] {name, outputName, source, copied}`, `generatedFiles[]`, `missingInputs[] {Kind, Reference}` |

**Fonts**: Roboto is built into the device and needs no file. Any other `fontName` needs
`<FontName>.ttf` in the package. Designer 2.8.0+ copies it from the project folder, `fonts\`, or
Windows Fonts and reports it in `fonts[]`; a missing file shows as `missingInputs kind="font"` and a
`COMPONENT_FONT_FILE_MISSING` validation warning. (Older Designers skip it silently — the simulator then
falls back to Arial without an error; `run-sim.ps1` copies TTFs itself as a safety net.)

## Simulator
- Window title `Airhmi Simulator 2.x`. Start: `Airhmi_Simulator.exe [--sd <dir>]` from its own folder;
  it reads the export from `SimulatorExportPath` (`options.ini` + screens).
- External command socket **TCP 127.0.0.1:8890** (8888 is the internal VM bridge, 8891 printf input).
  Details: `simulator-socket.md`.
- Console/log errors that mean "broken package": `PCC1`, `illegal character`, `Exception`, `Hata:`.
- Board I/O functions are mocks (`[MOCK]` in log); `dateSet/timeSet` are no-ops; `EthernetInit_*` change nothing.
- **Real**: `SocketTCP_*`, `SocketUDP_*`, `HTTP_PostGet`, `ModbusTCP_*` (PC network stack), `Fs_*`
  (`D:` = SD folder, `C:` = `C:\Users\Public\airhmi\flash`), Video objects (`.emf` playback),
  `init.pcc` run once at start (`hw.cfg` lines only logged).

## User guide chapter map (`manual\<lang>\...`)
| Chapter | Content worth pointing the user to |
|---|---|
| 01 Getting started | Device models, installation, first project, run in simulator |
| 02 Designer interface | Panels, toolbox, canvas, properties, objects, screens, resources, code panel, validation, shortcuts |
| 03 Project & screen design | Project structure, new project, screen settings, images, fonts, navigation, design rules, `.ahi` migration |
| 04 Component reference | One page per component (button … video) |
| 05 Interaction & code | Event model, C basics (memory limits), object properties (dot syntax), variables, timers, frequent functions, file functions (`Fs_*`), cookbook |
| 06 Communication | Host models, Airduino, custom UART, hardware functions, serial terminal, hardware / startup settings |
| 07 Test & deploy | Simulator, export anatomy (+ command line), SD card, FTP, serial/YMODEM, firmware & release, debugging in the simulator, VNC viewer |
| 08 AI assistant | Designer's built-in AI settings, commands, privacy |
| 09 Reference | Function reference, error reference, Nextion migration, glossary |
| 10 Troubleshooting | Symptoms, support |

## Versions this skill was built against
| Component | Version | Notes |
|---|---|---|
| Designer | 2.9.4 (2026-10-20) | Video object, Hardware / Startup Settings, VNC viewer, F1 help, network/file completion. 2.8.0: headless export/validate + font copy; 2.7.0 works with manual Export |
| Simulator | 2.9.4 | Socket 8890, `--sd`, debugger `Dbg*`, `Touch`, real TCP/UDP/Modbus TCP, `Fs_*`, Video objects, `init.pcc`; ships with the Designer setup |
| PCC compiler | 1.2.0 (DLL of 2026-10-20) | Dot syntax `obj.Prop = value`; global memory 8192 B, 4096 B per function |
| Firmware | V6.04 | Needed for Video objects, `ModbusTCP_*`, `SocketTCP_Read/SendRead`, `Fs_*`, startup settings, VNC, `TimerGet`. `?sys.ver` on the UART text protocol returns it (e.g. `V6.04 IC`) |

## Support channel
Platform suspicion (Designer/simulator/firmware behaves wrongly with a correct project):
GitHub issues at `https://github.com/airhmi/AIRHMI/issues` or the contact on `https://airhmi.com`,
with the repro package described in `SKILL.md` → Error protocol.
