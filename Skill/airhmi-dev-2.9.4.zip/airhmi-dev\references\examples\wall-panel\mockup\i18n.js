/* Mockup dil sözlüğü + tema + basit durum (localStorage).
 * AIRHMI dönüşümünde: diller sd_card text tablosuna, durum EVariable/globalVariables'a,
 * tema seçimi onStart renk kodu bloğuna gider.
 */
var I18N = {
  tr: {
    music: "MÜZİK", lighting: "AYDINLATMA", settings: "Ayarlar",
    channel: "Kanal", nowPlaying: "Çalan Kanal", selectChannel: "Kanal Seç",
    volume: "Ses Seviyesi", muted: "SESSİZ",
    lightOn: "Açık", lightOff: "Kapalı",
    lock: "Kilitle", enterPin: "Şifre Girin", wrongPin: "Hatalı şifre!", pinOk: "Giriş",
    zoneName: "Bölge Adı", ipAddress: "IP Adresi", deviceId: "Cihaz ID",
    channelNames: "Kanal Adları", channelName: "Kanal Adı",
    theme: "Tema", themeWave: "Dalga", themeTexture: "Doku", themeBokeh: "Işıklar", themeGradient: "Degrade",
    language: "Dil", about: "Hakkında", aboutValue: "Duvar Paneli v2 — AIRHMI",
    keyOk: "Tamam", keyCancel: "İptal", keySpace: "Boşluk"
  },
  en: {
    music: "MUSIC", lighting: "LIGHTING", settings: "Settings",
    channel: "Channel", nowPlaying: "Now Playing", selectChannel: "Select Channel",
    volume: "Volume", muted: "MUTED",
    lightOn: "On", lightOff: "Off",
    lock: "Lock", enterPin: "Enter PIN", wrongPin: "Wrong PIN!", pinOk: "Enter",
    zoneName: "Zone Name", ipAddress: "IP Address", deviceId: "Device ID",
    channelNames: "Channel Names", channelName: "Channel Name",
    theme: "Theme", themeWave: "Wave", themeTexture: "Texture", themeBokeh: "Lights", themeGradient: "Gradient",
    language: "Language", about: "About", aboutValue: "Wall Panel v2 — AIRHMI",
    keyOk: "OK", keyCancel: "Cancel", keySpace: "Space"
  }
};

/* Bake/press modu (render-bake.ps1; tokens.css sonundaki kurallar) */
var _bq = new URLSearchParams(location.search);
var BAKE = _bq.get("bake") === "1";
if (BAKE) document.documentElement.classList.add("bake");
if (_bq.get("press") === "1") document.documentElement.classList.add("pressall");

function lang() { return localStorage.getItem("panelLang") || "tr"; }
function t(key) {
  var v = I18N[lang()][key];
  return v === undefined ? key : v;
}
function applyI18n() {
  var nodes = document.querySelectorAll("[data-i18n]");
  for (var i = 0; i < nodes.length; i++) nodes[i].textContent = t(nodes[i].getAttribute("data-i18n"));
}

/* Tema = arka plan görseli (KARARLAR 2026-07-11: kırmızı/mavi vurgu iptal, amber sabit).
 * ?bg=bg1_wave parametresi test/önizleme içindir; kalıcı seçim localStorage'da.
 * AIRHMI dönüşümünde: ekran backgroundPicture (800×480 PNG → RGB565). */
var THEMES = [
  { bg: "bg1_wave",     key: "themeWave" },
  { bg: "bg2_texture",  key: "themeTexture" },
  { bg: "bg3_bokeh",    key: "themeBokeh" },
  { bg: "bg4_gradient", key: "themeGradient" }
];
function bgName() {
  var q = new URLSearchParams(location.search).get("bg");
  return q || localStorage.getItem("panelBg") || "bg1_wave";
}
function applyTheme() {
  var scr = document.querySelector(".screen");
  if (!scr) return;
  var bg = bgName();
  if (bg !== "none") {
    scr.style.backgroundImage = "url('../assets/bg/" + bg + ".png')";
    scr.setAttribute("data-bg", "on");
  } else {
    scr.style.backgroundImage = "none";
    scr.removeAttribute("data-bg");
  }
}
/* Vurgu ikonu (amber sabit): accIcon("lightbulb") → ../assets/icons/lightbulb_amber.png */
function accIcon(name) { return "../assets/icons/" + name + "_amber.png"; }

/* Mockup durumu — dönüşümde globalVariables karşılığı */
function stGet(key, def) {
  var v = localStorage.getItem(key);
  return v === null ? def : JSON.parse(v);
}
function stSet(key, val) { localStorage.setItem(key, JSON.stringify(val)); }

var DEFAULTS = {
  zoneName: "Salon", ip: "192.168.1.50", deviceId: "01", pin: "1234",
  vol: 42, muted: false, chIdx: 0, lightOn: true
};
/* 8 network yayın kanalı — adlar Ayarlar > Kanal Adları'ndan değiştirilir */
DEFAULTS.chNames = ["Kanal 1", "Kanal 2", "Kanal 3", "Kanal 4", "Kanal 5", "Kanal 6", "Kanal 7", "Kanal 8"];
function chNames() { return stGet("chNames", DEFAULTS.chNames); }
