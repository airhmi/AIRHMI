# Scenario: <Project Name>

> This file is the foundation of the project. The screen list, the behaviour plan and the socket test
> are all derived from it. Nothing is mocked up before it is approved. Changes get a version note in
> `DECISIONS.md` and the affected stages are revisited. Location: `docs\SCENARIO.md`
> Device: __" → ___×___ · Theme: ___ · Language(s): ___ · Host: standalone / UART host / Arduino

## 1. Actors and environment
<!-- Who uses it (operator / end user / technician), where (factory, home, cabin), under what conditions
     (gloves, distance, noise). Touch-target size and font size are justified from here. -->

## 2. System states
<!-- Modes of the device and transitions. One row per state: -->
| State | Entry condition | Screen shown | Exit (to where, by what) |
|---|---|---|---|
| Locked | power-up / timeout | LockScreen | correct PIN → Main |
| Main | unlocked | MainScreen | … |

## 3. Use cases (happy path)
<!-- Numbered, step by step: user does → system responds → which screen/widget. -->
### S-01: <name>
1. User … → system shows … (`MainScreen` / `lblStatus`)
2. …
- **Acceptance:** S-01 passes because: <observable result>

## 4. Edge and error cases
<!-- Wrong input, lost connection, first start after power loss, empty list/data, timeout,
     sensor fault (frozen / out-of-range value), two touches at once… Each one E-xx: -->
### E-01: <name>
- Trigger: … → Expected behaviour: … → Screen/warning: …

## 5. Live values (summary)
<!-- Every value that changes by itself: name | source on the device (function) | period | screen/widget
     | how it comes alive in the simulator (demo drift / socket injection). -->
| Value | Device source | Period | Widget | In simulator |
|---|---|---|---|---|

## 6. Screen list (derived from the scenarios)
<!-- CROSS-CHECK: every screen appears in at least one scenario step; every step's screen is listed.
     A screen without a scenario is unnecessary; a step without a screen is a design gap.
     Names ≤ 20 characters, PascalCase, English. -->
| Screen | Scenarios | Purpose (one sentence) |
|---|---|---|

## 7. Out of scope
<!-- Things deliberately NOT done — avoids "wasn't this included?" later. -->
