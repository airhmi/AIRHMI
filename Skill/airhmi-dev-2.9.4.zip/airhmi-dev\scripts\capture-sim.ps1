﻿# capture-sim.ps1 - screenshot of the running simulator's HMI canvas, one PNG per screen.
# Navigation: socket ChangeScreenSet + ScreenGet polling (no blind sleep) + settle margin.
# Capture: PrintWindow (works even when the window is behind others), cropped to the canvas.
# NOTE: ScreenGet confirms the switch was ACCEPTED, not that drawing finished -> SettleMs is required.
#
# Usage:
#   All screens (read from the project):
#     & capture-sim.ps1 -ProjectFile ...\project.airhmi.json -OutDir ...\test\shots\sim
#   Selected screens + theme suffix:
#     & capture-sim.ps1 -Screens MainScreen,LockScreen -OutDir ... -Theme dark
#   Single frame (no navigation, current screen):
#     & capture-sim.ps1 -OutDir ... -Current -Name LockScreen
param(
  [string]$ProjectFile,
  [string[]]$Screens,
  [Parameter(Mandatory=$true)][string]$OutDir,
  [string]$Theme = "",
  [switch]$Current,
  [string]$Name = "current",
  [int]$CanvasW = 0,           # 0 = device.width/height from ProjectFile; else 800x480
  [int]$CanvasH = 0,
  [int]$CanvasOffsetX = 12,    # X of the simulator workSpace panel inside the client area
  [int]$CanvasOffsetY = 12,    # Y of the simulator workSpace panel inside the client area
  [int]$SettleMs = 150,
  [int]$PollMs = 20,
  [int]$TimeoutMs = 5000
)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Win32Cap {
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr h, ref POINT p);
  [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr dc, uint flags);
  public struct RECT { public int Left, Top, Right, Bottom; }
  public struct POINT { public int X, Y; }
}
"@

function Send-Hmi([string]$cmd) {
    $c = New-Object System.Net.Sockets.TcpClient
    $c.Connect("127.0.0.1", 8890); $c.ReceiveTimeout = 3000; $c.SendTimeout = 3000   # 8890 = external command port (8888 is the internal bridge)
    $s = $c.GetStream()
    $b = [System.Text.Encoding]::UTF8.GetBytes($cmd)
    $s.Write($b, 0, $b.Length); $s.Flush(); Start-Sleep -Milliseconds 60
    $resp = ""; $buf = New-Object byte[] 4096
    if ($s.DataAvailable) { $n = $s.Read($buf,0,4096); $resp = [System.Text.Encoding]::UTF8.GetString($buf,0,$n) }
    $c.Close(); return $resp.Trim()
}

function Capture-Window([string]$outFile, [int]$w, [int]$h) {
    $p = Get-Process Airhmi_Simulator -ErrorAction Stop | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1
    if (-not $p) { throw "Simulator window not found (start it with run-sim.ps1 first)" }
    $hw = $p.MainWindowHandle
    $wr = New-Object Win32Cap+RECT; [Win32Cap]::GetWindowRect($hw, [ref]$wr) | Out-Null
    $full = New-Object System.Drawing.Bitmap(($wr.Right-$wr.Left), ($wr.Bottom-$wr.Top))
    $g = [System.Drawing.Graphics]::FromImage($full); $dc = $g.GetHdc()
    $ok = [Win32Cap]::PrintWindow($hw, $dc, 2)   # PW_RENDERFULLCONTENT
    $g.ReleaseHdc($dc); $g.Dispose()
    if (-not $ok) { $full.Dispose(); throw "PrintWindow failed" }
    $cr = New-Object Win32Cap+RECT; [Win32Cap]::GetClientRect($hw, [ref]$cr) | Out-Null
    $pt = New-Object Win32Cap+POINT; [Win32Cap]::ClientToScreen($hw, [ref]$pt) | Out-Null
    # The client area is the simulator window; the workSpace at (12,12) is the actual HMI canvas.
    # Cropping from the client origin alone leaves a 12 px gap and cuts the right/bottom edge.
    $offX = ($pt.X - $wr.Left) + $CanvasOffsetX
    $offY = ($pt.Y - $wr.Top) + $CanvasOffsetY
    $availableW = $cr.Right - $CanvasOffsetX
    $availableH = $cr.Bottom - $CanvasOffsetY
    if ($availableW -lt $w -or $availableH -lt $h) {
        $full.Dispose()
        throw "Simulator canvas too small: wanted=${w}x${h}, available=${availableW}x${availableH}, offset=${CanvasOffsetX},${CanvasOffsetY}"
    }
    $crop = $full.Clone([System.Drawing.Rectangle]::new($offX, $offY, $w, $h), $full.PixelFormat)
    $full.Dispose()
    $crop.Save($outFile, [System.Drawing.Imaging.ImageFormat]::Png); $crop.Dispose()
    Write-Output "Saved: $outFile ($w x $h, canvas offset $CanvasOffsetX,$CanvasOffsetY)"
}

# Screen list and canvas size
if ($ProjectFile) {
    $proj = Get-Content $ProjectFile -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($CanvasW -eq 0 -and $proj.device -and $proj.device.width)  { $CanvasW = [int]$proj.device.width }
    if ($CanvasH -eq 0 -and $proj.device -and $proj.device.height) { $CanvasH = [int]$proj.device.height }
    if (-not $Screens) { $Screens = @($proj.screens | ForEach-Object { $_.name }) }
}
if ($CanvasW -eq 0) { $CanvasW = 800 }
if ($CanvasH -eq 0) { $CanvasH = 480 }
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Force $OutDir | Out-Null }
$suffix = ""; if ($Theme -ne "") { $suffix = "_$Theme" }

if ($Current) {
    Capture-Window (Join-Path $OutDir "$Name$suffix.png") $CanvasW $CanvasH
    exit 0
}
if (-not $Screens) { throw "Pass -Screens or -ProjectFile (or use -Current)" }

foreach ($scr in $Screens) {
    Send-Hmi "$scr,,,ChangeScreenSet,," | Out-Null
    # ScreenGet polling until the target screen name comes back (no blind sleep)
    $sw = [System.Diagnostics.Stopwatch]::StartNew(); $ok = $false
    while ($sw.ElapsedMilliseconds -lt $TimeoutMs) {
        if ((Send-Hmi ",,,ScreenGet,,") -eq $scr) { $ok = $true; break }
        Start-Sleep -Milliseconds $PollMs
    }
    if (-not $ok) { Write-Warning "$scr : ScreenGet did not confirm within ${TimeoutMs}ms, capturing anyway" }
    Start-Sleep -Milliseconds $SettleMs   # drawing margin - ScreenGet does not guarantee the paint finished
    Capture-Window (Join-Path $OutDir "$scr$suffix.png") $CanvasW $CanvasH
}
