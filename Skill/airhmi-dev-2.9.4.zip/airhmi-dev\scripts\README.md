# Scripts

All scripts are PowerShell 5.1+, run them with `powershell -ExecutionPolicy Bypass -File <script> ...`
(or `& <script>` from a PowerShell prompt). Paths come from `env-check.ps1`; never hard-code the install folder.
`<skill>` = this skill's folder (`%USERPROFILE%\.claude\skills\airhmi-dev`).

| Script | Purpose | Key parameters | Exit codes |
|---|---|---|---|
| `env-check.ps1` | Find Designer/simulator/paths, headless capability, FTP settings. Dot-source it to get `Get-AirHmiEnvironment`. | `-AsJson`, `-Quiet` | 0 ok · 2 Designer missing |
| `new-project.ps1` | Create the project folder + minimal valid project + docs/test skeleton + `git init` | `-Name`, `-Device 4.3\|5\|7\|10`, `-Dir`, `-NoGit`, `-Force` | 0 / throws |
| `lint-project.ps1` | Static checks (orders, names, colours, image refs, fonts, event targets …) | `-ProjectFile`, `-AsJson` | 0 clean · 1 errors · 2 parse problem |
| `run-sim.ps1` | lint → headless export (or manual-export wait) → TTF safety copy → start simulator → log scan | `-ProjectFile`, `-ExportDir`, `-SdDir`, `-NoLaunch`, `-NoDebugInfo`, `-SkipLint` | 0 ok · 1 log problems / throws |
| `AirHmiSocket.psm1` | Module: `Send-Hmi`, `Get-HmiScreen`, `Wait-Screen`, `Touch-Hmi`, `Set-HmiVar`, `Get-HmiVar`, `Test-HmiSocket` | `Import-Module <skill>\scripts\AirHmiSocket.psm1` | — |
| `capture-sim.ps1` | Screenshot every screen of the running simulator (socket navigation + PrintWindow crop) | `-ProjectFile` or `-Screens`, `-OutDir`, `-Theme`, `-Current -Name` | 0 / throws |
| `render-mockup.ps1` | Headless Edge/Chrome render of a mockup HTML at device resolution; `-HideDynamic` for the background bake | `-Html`, `-Out`, `-HideDynamic`, `-ProjectFile` or `-Width/-Height` | 0 · 3 no browser |
| `compare-shots.ps1` | `compare.png` = mockup \| simulator \| device for one screen + rough pixel diff % | `-Screen`, `-ShotsDir`, `-Theme` | 0 / throws |
| `upload-ftp.ps1` | Upload the export package to the device (`D:\prog`), single FTP session, incremental manifest | `-SourceDir`, `-Incremental`, `-ForceFull`, `-DryRun`, `-DeviceIp` … | 0 / throws |
| `download-ftp.ps1` | Fetch one file from the device card (e.g. `prog/MainScreen.bmp`) | `-RemoteFile`, `-LocalPath`, `-DeviceIp` … | 0 / throws |

## Typical loop
```powershell
$skill = "$env:USERPROFILE\.claude\skills\airhmi-dev\scripts"
& $skill\env-check.ps1
& $skill\new-project.ps1 -Name Panel -Device 7 -Dir C:\Projects
# ... scenario, mockups ...
& $skill\render-mockup.ps1 -Html C:\Projects\Panel\mockup\MainScreen.html -Out C:\Projects\Panel\test\shots\mockup\MainScreen.png -ProjectFile C:\Projects\Panel\Panel.airhmi.json
& $skill\render-mockup.ps1 -Html C:\Projects\Panel\mockup\MainScreen.html -Out C:\Projects\Panel\img\MainScreen_bg.png -HideDynamic -ProjectFile C:\Projects\Panel\Panel.airhmi.json
# ... JSON + code ...
& $skill\run-sim.ps1 -ProjectFile C:\Projects\Panel\Panel.airhmi.json
& C:\Projects\Panel\test\test-scenario.ps1
& $skill\capture-sim.ps1 -ProjectFile C:\Projects\Panel\Panel.airhmi.json -OutDir C:\Projects\Panel\test\shots\sim
& $skill\compare-shots.ps1 -Screen MainScreen -ShotsDir C:\Projects\Panel\test\shots
# device
& $skill\run-sim.ps1 -ProjectFile C:\Projects\Panel\Panel.airhmi.json -ExportDir F:\prog -NoLaunch -NoDebugInfo
& $skill\upload-ftp.ps1 -SourceDir C:\Users\Public\airhmi\simulator -Incremental
```

## Notes
- Long-running steps (simulator start, FTP) should be launched detached by the agent and polled; the
  scripts themselves return as soon as their check is done.
- Scripts never write into the Designer install folder or `workspace-settings.json`.
- `capture-sim.ps1` assumes the simulator canvas starts at client offset (12,12); adjust
  `-CanvasOffsetX/-CanvasOffsetY` if a future simulator changes its layout.
