# Decisions: <Project Name>

> One dated line per approved decision. This is the audit trail for "why is it like this?".
> Format: `- YYYY-MM-DD — <decision> — <reason / who approved>`

- YYYY-MM-DD — Device 7" (800×480), dark theme, Turkish + English — approved by <user>
- YYYY-MM-DD — SCENARIO v1 approved (S-01…S-06, E-01…E-03, 4 screens)
- YYYY-MM-DD — Mockup v2 approved (MainScreen, SettingsScreen …)
- YYYY-MM-DD — Accepted platform limitation: <what> (visible difference in <screen>)
