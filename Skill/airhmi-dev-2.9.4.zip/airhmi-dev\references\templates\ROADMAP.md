# Roadmap: <Project Name>

> Status file. Tick a box the moment the step is done; at session start read this file and continue
> from the first unchecked item. Approvals get a version note ("mockup v2 approved — 2026-10-12").
> Device: __" → ___×___ · Theme: ___ · Language(s): ___

- [ ] Stage 1 — Scenario
  - [ ] Domain research done, 2-3 reference HMIs looked at
  - [ ] `docs\SCENARIO.md` written (states + S-xx/E-xx + live values + screen list)
  - [ ] Approved: scenario + resolution + theme + language(s)
- [ ] Stage 2 — HTML mockup (navigation works, assets in `img\`)
  - [ ] Screen: <name>
  - [ ] Approved (v_ — date) → `test\shots\mockup\<Screen>.png` saved
- [ ] Stage 3 — Conversion
  - [ ] `docs\BEHAVIOUR.md` (transitions, variables, events, static/dynamic split, live-value table)
  - [ ] Screen: <name> — baked background + widgets + lint clean + export ok
  - [ ] `sd_card\` list files generated from realistic data
- [ ] Stage 4 — Event code (dot syntax / verified signatures, timers for live values)
- [ ] Stage 5 — Simulator test + visual comparison
  - [ ] Simulator starts, log clean (PCC1 / illegal character / Exception = 0)
  - [ ] `test\test-scenario.ps1` written (one block per S-xx/E-xx) and passing
  <!-- ONE LINE PER SCREEN — a bulk "all match" is invalid -->
  - [ ] Screen: <name> [theme] — compare.png matches · behaviour regression passed
  - [ ] Differences fixed, affected screens re-captured
- [ ] Stage 6 — Device
  - [ ] Package on SD card / uploaded by FTP (`D:\prog`), `sd_card\*` on card root
  - [ ] Verified on device (user confirmation)

## Changes (CR)
<!-- - [ ] CR-01 (<date>): <what + why> — affected screens: <list> — state: scenario/mockup/convert/test/compare -->

## Open platform issues
<!-- - [ ] <summary> (component: Designer / simulator / compiler / firmware) — repro: support\repro-<date>\ — reported: <where/when> -->

## Notes
<!-- dated decisions and customer preferences that do not fit DECISIONS.md -->
