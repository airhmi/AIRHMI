﻿<#
.SYNOPSIS
    Creates the standard AIRHMI project folder with a minimal valid project for the chosen device.

.DESCRIPTION
    Layout (see SKILL.md):
      <Name>\<Name>.airhmi.json, img\, fonts\, code\, sd_card\, mockup\ (tokens.css), docs\ (SCENARIO,
      ROADMAP, DECISIONS), test\ (shots\{mockup,sim,device,compare}, logs), support\
    The project JSON comes from references\templates\project-<WxH>.airhmi.json with name/profile set.
    Runs `git init` unless -NoGit.

.PARAMETER Name
    Project name (also folder and file name). Letters, digits, _ and - only.
.PARAMETER Device
    4.3 | 5 | 7 | 10  (480x272 | 800x480 | 800x480 | 1024x600)
.PARAMETER Dir
    Parent folder. Default: current directory.
.PARAMETER Force
    Allow an existing, non-empty target folder (files are not overwritten unless they are templates).

.EXAMPLE
    .\new-project.ps1 -Name GreenhousePanel -Device 7 -Dir C:\Projects
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Name,
    [Parameter(Mandatory = $true)][ValidateSet('4.3', '5', '7', '10')][string]$Device,
    [string]$Dir = (Get-Location).Path,
    [switch]$NoGit,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
if ($Name -notmatch '^[A-Za-z][A-Za-z0-9_-]*$') { throw "Project name must start with a letter and contain only letters, digits, _ or -: '$Name'" }

$skillRoot = Split-Path -Parent $PSScriptRoot
$profile = switch ($Device) {
    '4.3' { @{ Id = 'AIRHMI_4_3'; Model = 'AIR480X272S43_E';  W = 480;  H = 272 } }
    '5'   { @{ Id = 'AIRHMI_5';   Model = 'AIR800X480S50_E';  W = 800;  H = 480 } }
    '7'   { @{ Id = 'AIRHMI_7';   Model = 'AIR800X480S70_E';  W = 800;  H = 480 } }
    '10'  { @{ Id = 'AIRHMI_10';  Model = 'AIR1024X600S101_E'; W = 1024; H = 600 } }
}
$templatePath = Join-Path $skillRoot ("references\templates\project-{0}x{1}.airhmi.json" -f $profile.W, $profile.H)
if (-not (Test-Path -LiteralPath $templatePath)) { throw "Template missing: $templatePath" }

$root = Join-Path $Dir $Name
if ((Test-Path -LiteralPath $root) -and -not $Force -and (Get-ChildItem -LiteralPath $root -Force | Select-Object -First 1)) {
    throw "Target folder exists and is not empty: $root (use -Force to continue)"
}
$folders = @('img', 'fonts', 'code', 'sd_card', 'mockup', 'docs', 'test', 'test\shots\mockup', 'test\shots\sim', 'test\shots\device', 'test\shots\compare', 'test\logs', 'support')
foreach ($f in $folders) { New-Item -ItemType Directory -Force -Path (Join-Path $root $f) | Out-Null }

# Project JSON from template
$json = Get-Content -LiteralPath $templatePath -Raw -Encoding UTF8
$json = $json.Replace('"name": "TemplateProject"', ('"name": "{0}"' -f $Name))
$json = $json.Replace('"profile": "AIRHMI_TEMPLATE"', ('"profile": "{0}"' -f $profile.Id))
$json = $json.Replace('"modelId": "AIRHMI_MODEL_TEMPLATE"', ('"modelId": "{0}"' -f $profile.Model))
$projectFile = Join-Path $root ("{0}.airhmi.json" -f $Name)
if (-not (Test-Path -LiteralPath $projectFile)) {
    [IO.File]::WriteAllText($projectFile, $json, [Text.UTF8Encoding]::new($false))
}

# Docs from templates (never overwrite existing)
$copies = @{
    'references\templates\SCENARIO.md'   = 'docs\SCENARIO.md'
    'references\templates\ROADMAP.md'    = 'docs\ROADMAP.md'
    'references\templates\DECISIONS.md'  = 'docs\DECISIONS.md'
    'references\design-tokens.css'       = 'mockup\tokens.css'
}
foreach ($entry in $copies.GetEnumerator()) {
    $src = Join-Path $skillRoot $entry.Key
    $dst = Join-Path $root $entry.Value
    if ((Test-Path -LiteralPath $src) -and -not (Test-Path -LiteralPath $dst)) {
        $text = Get-Content -LiteralPath $src -Raw -Encoding UTF8
        $text = $text.Replace('<Project Name>', $Name).Replace('__" → ___×___', ('{0}" → {1}×{2}' -f $Device, $profile.W, $profile.H))
        if ($entry.Value -like 'mockup\*') {
            $text = $text.Replace('--screen-w: 800px;', ('--screen-w: {0}px;' -f $profile.W)).Replace('--screen-h: 480px;', ('--screen-h: {0}px;' -f $profile.H))
        }
        [IO.File]::WriteAllText($dst, $text, [Text.UTF8Encoding]::new($false))
    }
}

# Test scenario skeleton
$testFile = Join-Path $root 'test\test-scenario.ps1'
if (-not (Test-Path -LiteralPath $testFile)) {
    $skillScripts = Join-Path $skillRoot 'scripts'
    $test = @'
# test-scenario.ps1 - drives SCENARIO.md S-xx/E-xx against the running simulator (socket 8890).
# Start the simulator first: <skill>\scripts\run-sim.ps1 -ProjectFile <project>
param([string]$LogDir = "$PSScriptRoot\logs")
$ErrorActionPreference = 'Stop'
Import-Module "__SKILL_SCRIPTS__\AirHmiSocket.psm1" -Force
if (-not (Test-HmiSocket)) { throw "Simulator socket 8890 is not answering. Start the simulator with run-sim.ps1." }
New-Item -ItemType Directory -Force $LogDir | Out-Null
$log = Join-Path $LogDir ("test-scenario-{0}.log" -f (Get-Date -Format yyyyMMdd-HHmmss))
$script:fail = 0
function Check([string]$Id, [bool]$Ok, [string]$Detail) {
    $line = "[{0}] {1} {2}" -f $(if ($Ok) { 'PASS' } else { 'FAIL' }), $Id, $Detail
    $line | Tee-Object -FilePath $log -Append
    if (-not $Ok) { $script:fail++ }
}

# S-01: first screen opens
Send-Hmi 'MainScreen,,,ChangeScreenSet,,' | Out-Null
Check 'S-01' (Wait-Screen 'MainScreen') 'MainScreen active'

# TODO: one block per S-xx / E-xx from docs\SCENARIO.md

"RESULT: $(if ($script:fail -eq 0) { 'PASS' } else { "FAIL ($script:fail)" }) - log $log" | Tee-Object -FilePath $log -Append
exit $script:fail
'@
    [IO.File]::WriteAllText($testFile, $test.Replace('__SKILL_SCRIPTS__', $skillScripts), [Text.UTF8Encoding]::new($false))
}

# .gitignore + git init
$gitignore = Join-Path $root '.gitignore'
if (-not (Test-Path -LiteralPath $gitignore)) {
    "test/logs/`nsupport/*.zip`n*.tmp`n" | Set-Content -LiteralPath $gitignore -Encoding UTF8
}
if (-not $NoGit -and -not (Test-Path -LiteralPath (Join-Path $root '.git'))) {
    $git = Get-Command git -ErrorAction SilentlyContinue
    if ($git) { Push-Location $root; try { git init -q; git add -A; git commit -q -m ("AIRHMI project skeleton ({0} inch, {1}x{2})" -f $Device, $profile.W, $profile.H) } finally { Pop-Location } }
    else { Write-Warning 'git not found - skipped git init' }
}

Write-Host ("Project created: {0}  ({1} inch, {2}x{3})" -f $projectFile, $Device, $profile.W, $profile.H)
Write-Host "Next: fill docs\SCENARIO.md, then mockups in mockup\<Screen>.html"
