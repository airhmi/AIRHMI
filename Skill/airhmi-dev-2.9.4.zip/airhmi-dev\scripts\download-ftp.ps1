﻿<#
.SYNOPSIS  Downloads one file from the AIRHMI device's SD card over FTP (RETR) - e.g. a ScreenCapture BMP.
.DESCRIPTION
  Defaults come from Designer's workspace-settings.json -> FtpDevice (via env-check.ps1); parameters override.
  RemoteFile is relative to the drive root: "prog/MainScreen.bmp".
.EXAMPLE
  .\download-ftp.ps1 -RemoteFile prog/MainScreen.bmp -LocalPath .\test\shots\device\MainScreen.bmp
#>
param(
  [string]$DeviceIp = '',
  [int]$Port = 0,
  [Parameter(Mandatory=$true)][string]$RemoteFile,      # relative to the drive root: "screen.bmp" or "prog/x.raw"
  [Parameter(Mandatory=$true)][string]$LocalPath,       # full local path
  [string]$UserName = '',
  [string]$Password = '',
  [string]$DeviceDrive = '',
  [int]$TimeoutMs = 60000
)


$ErrorActionPreference = 'Stop'
# Fill missing parameters from Designer's FtpDevice settings (workspace-settings.json), read-only.
. (Join-Path $PSScriptRoot 'env-check.ps1')
$airEnv = Get-AirHmiEnvironment
if (-not $DeviceIp)    { $DeviceIp = $airEnv.FtpHost }
if ($Port -le 0)       { $Port = $airEnv.FtpPort }
if (-not $UserName)    { $UserName = $airEnv.FtpUser }
if (-not $Password)    { $Password = $airEnv.FtpPassword }
if (-not $DeviceDrive) { $DeviceDrive = $airEnv.FtpDrive }
if (-not $DeviceIp)    { throw 'Device IP unknown: pass -DeviceIp or set it once in Designer (File > Export to Device (FTP)).' }
if (-not $UserName)    { $UserName = 'admin' }
if (-not $Password)    { $Password = 'admin' }

$control = [Net.Sockets.TcpClient]::new()
$control.ReceiveTimeout = $TimeoutMs
$control.SendTimeout = $TimeoutMs
$control.Connect($DeviceIp, $Port)
$stream = $control.GetStream()
$reader = [IO.StreamReader]::new($stream, [Text.Encoding]::ASCII)
$writer = [IO.StreamWriter]::new($stream, [Text.Encoding]::ASCII)
$writer.NewLine = "`r`n"
$writer.AutoFlush = $true

function Read-FtpReply {
  $lines = [Collections.Generic.List[string]]::new()
  $line = $reader.ReadLine()
  if ($null -eq $line) { throw 'FTP control connection closed' }
  $lines.Add($line)
  if ($line -match '^(\d{3})-') {
    $code = $matches[1]
    do {
      $line = $reader.ReadLine()
      if ($null -eq $line) { throw 'FTP multiline reply interrupted' }
      $lines.Add($line)
    } while ($line -notmatch ("^" + $code + " "))
  }
  return ($lines -join ' | ')
}

function Send-FtpCommand([string]$Command, [string]$ExpectedCode) {
  $writer.WriteLine($Command)
  $reply = Read-FtpReply
  if ($reply -notmatch ("^" + $ExpectedCode)) { throw "$Command => $reply" }
  return $reply
}

$sw = [Diagnostics.Stopwatch]::StartNew()
try {
  $banner = Read-FtpReply
  if ($banner -notmatch '^220') { throw $banner }
  [void](Send-FtpCommand "USER $UserName" '331')
  [void](Send-FtpCommand "PASS $Password" '230')
  [void](Send-FtpCommand 'TYPE I' '200')

  # Split the remote path into folders + file; enter the drive root, then CWD into subfolders.
  $remote = $RemoteFile -replace '\\','/'
  $segments = @($remote -split '/' | Where-Object { $_ })
  $fileName = $segments[-1]
  $dirs = @($segments[0..($segments.Count-2)])

  [void](Send-FtpCommand 'CWD /' '250')
  [void](Send-FtpCommand "CWD $DeviceDrive" '250')
  foreach ($d in $dirs) { [void](Send-FtpCommand "CWD $d" '250') }

  # PASV + RETR
  $pasv = Send-FtpCommand 'PASV' '227'
  if ($pasv -notmatch '\((\d+),(\d+),(\d+),(\d+),(\d+),(\d+)\)') { throw "Bad PASV reply: $pasv" }
  $dataPort = ([int]$matches[5] * 256) + [int]$matches[6]
  $data = [Net.Sockets.TcpClient]::new()
  $data.ReceiveTimeout = $TimeoutMs
  $data.Connect($DeviceIp, $dataPort)

  $writer.WriteLine("RETR $fileName")
  $start = Read-FtpReply
  if ($start -notmatch '^150|^125') { $data.Close(); throw "RETR $fileName => $start" }

  $dataStream = $data.GetStream()
  New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName($LocalPath)) | Out-Null
  $fileStream = [IO.File]::Create($LocalPath)
  try {
    $dataStream.CopyTo($fileStream)
    $fileStream.Flush()
  } finally {
    $fileStream.Dispose()
    $dataStream.Dispose()
    $data.Close()
  }
  $done = Read-FtpReply
  if ($done -notmatch '^226') { throw "RETR complete $fileName => $done" }

  [void](Send-FtpCommand 'QUIT' '221')
} finally {
  $control.Dispose()
  $sw.Stop()
}

$size = (Get-Item -LiteralPath $LocalPath).Length
[pscustomobject]@{
  Source = "${DeviceIp}:$Port/$DeviceDrive/$RemoteFile"
  Local = $LocalPath
  Bytes = $size
  Seconds = [math]::Round($sw.Elapsed.TotalSeconds, 1)
}
