# Event code API — dot syntax, verified signatures, traps

> Event code is a practical subset of C, compiled by Designer into PCC bytecode and executed on the
> device (and in the simulator). Two ways to talk to widgets: **dot syntax** (`label1.Text = "Hi";`) and
> **classic functions** (`LabelSet("label1","Text","Hi");`). Both compile to the same calls; mix freely.
> For the full function list use the installed user guide → `09-reference/01-function-reference`
> (same content as Designer's code completion). This file holds what the guide does not stress: the
> dot-syntax rules, the verified signatures, the traps and the simulator differences.

## 0. Every event file starts like this
```c
#include "stk.h"      // all HMI functions (LabelSet, ChangeScreenSet, TimerSet …)
#include "stdio.h"    // sprintf / printf  (optional)
#include "stdlib.h"   // atoi / atof       (optional)
#include "string.h"   // strcpy / strcmp   (optional)
```
Where code lives (Designer Code panel target selector): **Component event** (`onDown`/`onUp`/`onPress`),
**Screen OnStart** (runs on *every* open of the screen), **Screen Functions** (shared C functions of the
screen, callable from its events), **Timer** (periodic), **List Data** (ListView file). In the JSON an
event value is either inline code or a `.c` file name (`code\btnStart_OnDown.c`); keep anything longer
than ~3 lines in a file.

## 0b. Project code layout — where the files go and how they are compiled
A project is a folder; all code lives inside it and is referenced from the `.airhmi.json` by a path
relative to that folder. Designer's **Create** button writes `<Object>_<Event>.c` next to the project
file (`bStart_OnDown.c`, `Screen1_OnStart.c`, `tmrRefresh_Event.c`); this skill keeps them in `code\`
(`code\bStart_OnDown.c`) — both work, the JSON just stores the relative path.

```text
GreenhousePanel\
  GreenhousePanel.airhmi.json        screens, components, event references, resources
  code\
    MainScreen_OnStart.c             "onStart": "code\\MainScreen_OnStart.c"
    MainScreen_Functions.c           "functions": "code\\MainScreen_Functions.c"   (shared C functions of the screen)
    btnStart_OnDown.c                components[].events.onDown
    btnSettings_OnDown.c
    tmrSensors_Event.c               screens[].timers[].event
    SettingsScreen_OnStart.c
    lvSettings_OnUp.c
    tmrWatchdog_Event.c              globalTimers[].event
  img\  fonts\  sd_card\             assets (see widget-reference.md / html-to-airhmi.md)
```
Rules the compiler and runtime impose:
- **Every event is its own program.** Each `.c`/inline block is compiled to one `.pcc` and runs from
  top to bottom when the event fires. Variables declared in an event die when it ends; data that must
  survive between events or screens goes into **EVariable** objects (`VarSeti/VarGet`, globals) — not
  into C globals.
- **Screen Functions** (`screens[].functions`, one block per screen) hold `int f(...) {...}` definitions.
  They are compiled together with every event of that screen, so events call them directly without a
  prototype. Events of *other* screens cannot call them. Keep helpers short; heavy shared logic belongs
  in global variables + per-screen functions. (Designer's `Check C` on a single event may not see the
  screen functions — a "unknown function" there while export succeeds is that limitation, not a bug.)
- **Screen OnStart** runs on every open of the screen (guard one-time work with a global flag).
- **Timers**: `screens[].timers[]` live with their screen; `globalTimers[]` run everywhere. The event
  code is the `event` field (inline or `.c`).
- **Inline vs file**: 1-3 lines inline is fine (`"onDown": "lblStatus.Text = \"OK\";"`); anything longer
  goes to a file so it can be diffed and reused. Inline code must be JSON-escaped (`\"`, `\n`).
- **Legacy helpers are rewritten at export**: `LabelSetf(name, x)` becomes `sprintf(buf,"%g",x)` which
  the device does not print correctly — use `lbl.Text = x;` (formats `%.2f`) or your own `sprintf("%.1f")`.
- Compile check without the GUI: `scripts\run-sim.ps1 -NoLaunch` — compiler errors appear in
  `export-result.json → outputLines` with the event file name and line.

## 1. Dot syntax (compiler 1.2.0 / Designer 2.7.0 and newer)
```c
button1.Text  = 12;                 // write: number → text "12"
label1.Text   = "Ready";            // write: string
gauge1.Value  = counter + 1;        // write: expression (formatted automatically)
x = slider1.Value;                  // read (numeric)
y = a + gauge1.Value * 2;           // read inside an expression
timer1.Enable = 1;                  // timer write
t = timer1.Interval;                // timer read (needs firmware with TimerGet; older firmware returns 0)
if (toggle1.State == 1) { led1.State = 1; }
lblTemp.Text = tempC;               // int → "23"; float → "23.50" (%.2f)
int n = button1.Text;               // text property into a number → automatic atoi (float target → atof)
char s[32]; s = label1.Text;        // text into a char array (direct read into the buffer)
labelB.Text = labelA.Text;          // copy text between objects
gauge1.Value += 5;                  // compound assignment = read + op + write
```
**Rules**
- A **variable with the same name wins** over the object (existing struct code keeps working).
- Property names are case-insensitive aliases of the firmware keys (`Text` = `Caption` on a button).
  Unknown property: write is silently ignored, read gives 0 / empty string. **Object name is
  case-sensitive** (`Button1.` ≠ `button1.`; the compiler suggests the right spelling).
- Not supported (clear compile error): `obj.Prop++` / `--`, nested `a.b.c`, chained assignment
  `x = (a.Text = 5)`, taking the address `&obj.Prop`, object names that are not C identifiers
  (`7seg1` → rename the object or use `SevenSegSet("7seg1",...)`).
- Colours: `"#RRGGBB"` string or a decimal int. `"0xFF0000"` and `"R,G,B"` are **not** parsed.
- On/off properties (`Visible`, `Active`, `Enable`): `1` / `0`.
- `ListWheel.Value` is asymmetric: write = 1-based index, read = selected text.
- `ListView.Row` = selected row, column 0; `Row1`, `Row2` … other columns; `RowCount` number.
- QR objects are **write-only** (`qr1.Text = "https://…"`); reading is a compile error.
- Line numbers in the debugger stay the user's lines (hidden buffers are not shown).

### Properties per object type (as offered by Designer's code completion)
Legend: `n` number (default) · `d` decimal · `t` text · `f` 0/1 · `c` colour · `r`/`w` read-/write-only.
| Type | Properties |
|---|---|
| EButton | `Text:t Visible:f Active:f Left Top Width Height Color:c ColorTo:c Press_Color:c Press_ColorTo:c Font_Color:c Pen_Color:c Pen_Width Gradient:f FontSize FontName:t PushPull:f OnDown:t:w` |
| ELabel / ELabelBox | `Text:t Visible:f Active:f Left Top Width Height Font_Color:c FontSize FontName:t Center:f Rotate ScrollEnable:f:w ScrollSpeed:w ScrollMid:t:w ScrollMidFont:t:w OnDown:t:w` |
| EveGauge | `Value Visible:f Left Top Radius Range:w Color:c Needle_Color:c Needle_Circle_Color:c Press_Color:w Pen_Width:w Major_Count:w Minor_Count:w Flat:f:w Center:f:w NoPointer:f:w NoBackground:f:w NoTicks:f:w` |
| EveSlider | `Value Visible:f Active:f Left Top Width Height Range Color:c Background_Color:c Thumb_Color:c Press_Color Flat:f` |
| EveProgressBar | `Value Range Visible:f Left Top Width:w Height:w Color:c Background_Color:c Border_Color:c Border_Size Font_Color:c:w Press_Color:w Flat:f:w` |
| EToggle | `State:f Visible:f Active:f Left Top Width:r Height:r Color:c Color_On:c Color_Off:c Font_Color:c Font_Size Flat:f:w` |
| EImage | `Visible:f Active:f Left Top Width Height Image_File:t:w Image_File_Replace:t:w ScaleX:d ScaleY:d RotationAngle(0-255) RotationCenterLeft RotationCenterTop Blend_Color Picture_Size Picture_Type Picture_Ratio Static_Or_Dynamic PushPull:f OnDown:t` |
| EShape | `Active:f Left Top Width Height` |
| EGraph | `Visible:f Left Top Width:r Height:r Line0_Color:c … Line3_Color:c` |
| EListView | `SelPos SelVal:t:r Row:t:r RowCount:r ColCount:r Visible:f Active:f Left Top Insert:t:w (cells with ^) Delete_Selected:w Update:w` |
| EListWhell | `SelPos SelVal:t Value:t Visible:f Active:f Left Top` |
| EArc | `Value MinValue MaxValue Visible:f Active:f Left Top StartAngle SweepAngle ValueColor:c ValueWidth ValueAlign (INNER/CENTER/OUTER) TrackColor:c TrackWidth TrackVisible:f RoundedEnds:f` |
| ELine | `Points:t:w ("x:y;x:y") PointCount:r Visible:f Active:f Left Top Color:c Width CapStyle:t:w (BUTT/ROUND) Closed:f` |
| ELed | `State:f Visible:f Active:f Left Top OnColor:c OffColor:c Blink:f BlinkInterval` |
| ESevenSeg | `Value Visible:f Active:f Left Top DigitCount DecimalPlaces:w LeadingZero:f:w OnColor:c OffColor:c BackgroundColor:c:w` |
| EBarChart | `Values:t (comma list) MaxValue Visible:f Active:f Left Top BarColor:c AxisColor:c AxisVisible:f BackgroundColor:c` |
| EPieChart | `Values:t SliceColors:t:w Donut:f InnerRadius Visible:f Active:f Left Top` |
| ESpinner | `Value MinValue MaxValue Step Visible:f Active:f Left Top` |
| EMultiIcon | `Value Pictures:t:w Visible:f Active:f Left Top` |
| EQR | `Text:t:w Visible:f:w Left:w Top:w` (write-only) |
| EVideo | `Visible:f` (0 = poster hidden **and** playback stopped). Everything else via `Video_*` functions — `video-object.md` |
| ETimer | `Enable:f Interval (ms)` |
| EVariable | `Value` (int / float / string according to `dataType`) |

## 1b. The C subset — what the runtime understands
Event code is standard C as interpreted/compiled for the device VM; practical limits:

| Works | Notes |
|---|---|
| `int`, `float`, `double`, `char`, arrays (`char buf[64]`, `int v[8]`), pointers (`&x`, `char*`), `struct`, `const`, `static` | fixed-size arrays; no dynamic sizing in declarations |
| `if/else`, `for`, `while`, `do`, `switch`, `return`, `break/continue` | |
| Function definitions | **only in Screen Functions**; events contain statements, not function definitions |
| `#include "stk.h"`, `stdio.h`, `stdlib.h`, `string.h`, `math.h`, `ctype.h` | `stk.h` is mandatory for any HMI call |
| `sprintf/snprintf/sscanf`, `strcpy/strcat/strcmp/strlen/memset/memcpy`, `atoi/atof/itoa`, `abs/rand/srand`, `sin/cos/pow/sqrt` | device `sprintf`: `%d %i %u %x %X %f %s %c` + precision, **no `%g`** |
| `printf` | debug channel only (simulator log / UART), never the screen |

| Does not work / avoid | Use instead |
|---|---|
| `++x;` as a statement at file level | `x++;` or `x = x + 1;` |
| `obj.Prop++`, `a.b.c`, chained assignment on objects | see §1 |
| C globals shared between events | `EVariable` (`VarSeti`, `GlobalIntVarSet`) |
| Blocking waits in timers (`AudioPlayWait`, long loops) | the runtime is single-threaded: keep events short; animation = `millis()`-based loop inside one event + `DrawScreen()` |
| `malloc` in every event | fixed buffers; memory is small |
| Reading a `Get` into an `int` directly | `Get` writes **text** into a `char` buffer; convert with `atoi/atof` (or use dot syntax which does it) |
| Unicode sub/superscripts in strings | plain ASCII (`CO2`) |

Buffer sizes that are known to be enough: numbers `char buf[32]`, text/UART/file lines `char buf[64..256]`,
string variables `char buf[100]`. `memset(buf, 0, sizeof(buf))` before reuse is cheap insurance.

**Persistence**: variables live in RAM. `VariableSave("name")` stores a variable in non-volatile
memory (call it when the value changes, not every tick). Files: the `Fs_*` family (`file-api.md`) with
drive paths — `Fs_Write("C:/user/cfg.txt", …)` flash, `Fs_Append("D:/log/day.csv", …)` SD card. The old
`File_*` functions compile but raise `LEGACY_FILE_API`. The simulator maps `D:` to its `--sd` folder
and `C:` to `C:\Users\Public\airhmi\flash`; `VariableSave`/GPIO are mocks there.

**Memory limits (compile errors)**: all variables declared outside functions — including the top level
of an event file — share **8192 bytes**; one function's locals **4096 bytes** (1024 slots). Large tables
go to a file or are split.

**Cookbook (verified patterns)**
```c
// Counter: button increments a variable and shows it
#include "stk.h"
int count;
VarGeti("cnt", &count);
count = count + 1;
VarSeti("cnt", count);
lblCount.Text = count;

// Carry data to another screen: global variable + OnStart of the target
VarSeti("selectedItem", 3);            // btnDetail_OnDown.c
ChangeScreenSet("DetailScreen");
int sel; VarGeti("selectedItem", &sel); lblSelected.Text = sel;   // DetailScreen_OnStart.c

// Toggle drives a picture pair and a GPIO output
#include "stk.h"
if (tglPump.State == 1) { imgOn.Visible = 1; imgOff.Visible = 0; GPIO_Write("GPIO_3", 1); }
else                    { imgOn.Visible = 0; imgOff.Visible = 1; GPIO_Write("GPIO_3", 0); }

// Clock label (minute timer)
char text[32]; int d, m, y, hh, mm;
dateGet(&d, &m, &y); timeGet(&hh, &mm);
sprintf(text, "%02d.%02d.%04d %02d:%02d", d, m, y, hh, mm);
lblClock.Text = text;

// Setting that survives power loss
VarSeti("setpoint", 72); VariableSave("setpoint");          // when changed
int sp; VarGeti("setpoint", &sp); lblSetpoint.Text = sp;    // Screen OnStart
```
Screen-side communication with a host board (UART text protocol, Airduino) is in `host-protocol.md`.

## 2. Verified classic signatures (safe to use)
```c
// Widget property set/get — property names are friendly, matched case-insensitively
LabelSet("lblName","Text","Hello");  LabelSets("lblName", str);  LabelSeti("lblName", i);  LabelSetf("lblName", f);
ButtonSet("btnName","Text","Start"); ButtonSet("btnName","Color","#FFAB00"); ButtonSet("btnName","ColorTo","#321212");
ImageSet("imgName","LEFT","100");    ImageSet("imgName","VISIBLE","0");          // VISIBLE exists on almost every widget
ImageSet("imgName","IMAGE_FILE_REPLACE","file.raw");                            // .raw found on the SD card by name; size = widget W×H
TimerSet("timerName","Enable","1");  TimerSet("timerName","Interval","5000");
ArcSet("arcName","Value","80");      ArcSet("arcName","ValueColor","#38CFFF");   ArcGet("arcName","Value", buf);
LineAddPoint("lnName","20,40");      LineSetPoint("lnName","2","90,50");  LineClear("lnName");  LineSet("lnName","Color","#FF3030");
LedSet("led1","State","1");          SevenSegSet("seg1","Value","42");    BarChartSet("bar1","Values","10,20,30");
MultiIconSet("icoFan","Value","2");  SpinnerSet("spn1","Value","5");      QR_Set("qr1","Text","https://airhmi.com");
ChangeScreenSet("MainScreen");                                                   // screen change (NOT ScreenSet)
// Screen-local variables (screen.variables[], dataType int / String / float):
VarSeti("VName", i);  VarSet("VName", str);  VarSetf("VName", f);
VarGet("VName", &i);  VarGet("VName", buf);  VarGet("VName", &f);               // Get picks by type
// Global variables (globalVariables[]):
GlobalIntVarSet("gName", i);   GlobalIntVarGet("gName", &i);
GlobalStdVarSet("gName", str); GlobalStdVarGet("gName", buf);                   // Std = string
GlobalDoubleVarSet/Get(...);
// Time:
TimeGet(&h, &mi);  TimeGet(&h, &mi, &s);   DateGet(&day, &month, &year);         // int pointers
// ListView cells — argument order is (list, COLUMN, ROW, buffer/value)!
ListViewGetXY("lvSettings", 1, row, nameBuf);   ListViewSetXY("lvSettings", 0, row, "42");
ListViewSet("lvSettings","UPDATE","1");                                          // persist widget content to its SD list file
// Board I/O (real on the device, mock in the simulator) — pin names are TEXT:
GPIO_Write("GPIO_5", 1);  GPIO_Read("GPIO_2", &v);  PWM_Set(0, 1000, 50);  BuzzerSet(1);
double a; ADC_Read(0, &a);                                   // legacy board function, reads into a double
UartInit(9600, 8, 1, 0);  printf("OK\n");                    // printf IS the UART write (no UartWrite/UartPrint)
char rx[200]; int n; uartDataGet(rx, &n);                    // receive, max 199 bytes
I2C_Write(100, 0x50, data, len);  I2C_Read(100, 0x50, data, len);  SPI_SendByte(b);  SPI_WriteRead(tx, txLen, rx, rxLen);
// Network (REAL in the simulator too) and files — network-api.md / file-api.md:
ModbusTCP_ReadHoldingRegisters(1, 0, 4, regs);  SocketTCP_Read(buf, 127, 300);  Fs_Append("D:/log.csv", row, strlen(row));
// Video object — video-object.md:
Video_Play("vidIntro", 100);  VideoPause();  VideoContinue();  VideoStop();  Video_ElapsedGet();  Video_DurationGet();
```
- Button actions on **`onDown`** (responsive on the device); destructive actions on `onUp`.
- `Get` functions write **text** into a buffer: `char data[32];` for numbers, `[64..256]` for text.
  Convert with `atoi(data)` / `atof(data)`; format with `sprintf(buf, "%.1f", value)`.
- The device `sprintf` knows `%d %i %u %x %X %f %s %c` with precision — **not `%g`**.

## 3. Traps (each one cost a real project time)
| Trap | Correct |
|---|---|
| `ScreenSet("X")` for navigation | `ChangeScreenSet("X");` |
| `LabelSets("l","Text","x")` (3 args) | `LabelSet("l","Text","x");` — `LabelSets` takes **2** args (name, string) |
| `ListViewGetXY(list, row, col, buf)` | `(list, COLUMN, ROW, buf)` — swapped order reads the wrong cell silently |
| `VarSeti` on a `String` variable | silently ignored — declare `dataType:"int"` for counters/flags |
| `GlobalVar*` on screen variables | screen variables use `VarSet/VarGet`; globals use `GlobalIntVar*/GlobalStdVar*` |
| colour `"0xFF0000"` or `"255,0,0"` | `"#FF0000"` or a decimal int |
| `%g` in sprintf | `%.2f` |
| `obj.Prop++` | `obj.Prop = obj.Prop + 1;` or `+= 1` |
| reading a QR property | QR is write-only |
| text box sized exactly to the text | add ~20 % width / 1.6× font-size height (device font metrics differ) |
| Unicode subscripts `CO₂` | `CO2` |
| `TimerGet` / `timer1.Interval` read on old firmware | returns 0; write-side works everywhere |
| animation with its own timer + blocking call (`AudioPlayWait`) | single-threaded runtime — use a `millis()`-based loop inside one event and `DrawScreen()` per frame |
| 60 ms global timer | the simulator re-arms the VM per tick (~0.5 s); use time-based progress, not tick counts |
| `GPIO_Write(5, 1)` (pin as a number) | `GPIO_Write("GPIO_5", 1)` — the pin name is text |
| `UartWrite(...)` / `UartPrint(...)` | `printf("...\n")` is the UART write; receive with `uartDataGet(buf, &len)` |
| `File_write` / `File_readSD` in new code | `Fs_Write` / `Fs_Read` with `C:`/`D:` paths (`file-api.md`); old names → `LEGACY_FILE_API` |
| `Delay(ms)` to wait for network data | `SocketTCP_Read(buf, max, ms)` — `Delay` stops network processing and starves the watchdog (≥ 20 s = reset) |
| `ModbusTCP_Open` / `HTTP_PostGet` in `onDown` or startup code | call from timers; server IP in Hardware / Startup Settings (`ModbusTCP_Config`) |
| Modbus/socket `count`/`max` larger than the array | silent memory corruption — size the array to the largest `count` |
| `char big[9000];` at the top of an event | compile error (8192 B globals / 4096 B per function) — split it or use a file |

## 4. Simulator vs device (what "doesn't work in the simulator" usually means)
- Board I/O (`GPIO_*`, `ADC_Read`, `PWM_Set`, `UartInit`/`uartDataGet`, `I2C_*`, `SPI_*`, `BuzzerSet`,
  `EthernetInit_*`) returns fixed values and logs `[MOCK]`. `dateSet/timeSet` are accepted but change
  nothing; `TimeGet/DateGet` work.
- **Real in the simulator**: `SocketTCP_*`, `SocketUDP_*`, `HTTP_PostGet`, `ModbusTCP_*` (PC network stack —
  a PLC on the LAN or a Modbus TCP simulator on `127.0.0.1:502` answers for real); `Fs_*` on the SD /
  flash folders; Video objects (`.emf` playback in the object rectangle); `init.pcc` + `hw.cfg` startup
  settings (GPIO/PWM lines only logged).
- Image/Progress `Get`, Shape/Graph `Set/Get` are implemented in recent simulators; if a read comes back
  empty, check `socket_debug.log` before suspecting your code.
- Fonts: the simulator uses `<export>\<FontName>.TTF`; missing → Arial silently (Designer 2.8+ copies and warns).
- Text metrics differ (GDI vs device engine) — always verify text boxes on the device too.
- `ListView` getters re-read the SD file on every call.

## 5. Patterns
**Periodic live value (timer event)**
```c
#include "stk.h"
int v; double a;
ADC_Read(0, &a); v = a;         // device: real sensor; simulator: mock → use demo drift or socket-injected variable
lblTemp.Text = v;
if (v > 80) { ledAlarm.State = 1; } else { ledAlarm.State = 0; }
```
**Settings page: ListView ↔ variables**
```c
#include "stk.h"
char val[32];
ListViewGetXY("lvSettings", 1, 2, val);     // column 1 (value), row 2
VarSeti("setpoint", atoi(val));
ListViewSet("lvSettings","UPDATE","1");     // persist to SD list file
```
**Numeric keypad into a LabelBox**: `lblInput.Text` append via `sprintf(buf,"%s%d", current, digit)`; commit on OK with `atoi`.

**Screen OnStart**: runs on every open — guard one-time work with a global flag.

## 6. Capability catalog (what the device offers — exact names in the user guide function reference)
Widget `XxxSet/XxxGet` for every type above · `Var*/GlobalIntVar*/GlobalStdVar*/GlobalDoubleVar*`,
`VariableSave` · Screen (`ChangeScreenSet`, `ScreenGet`, `DrawScreen`, `ScreenCapture`) · Time/Date
(`TimeGet/TimeSet`, `DateGet`) · `millis`, `Delay` (blocks everything — avoid) · Audio (`AudioPlay/Stop/StatusGet`)
· Video object (`Video_Play/_XY`, `VideoPause/Continue/Stop`, `Video_StatusGet/DurationGet/ElapsedGet`,
`VideoSet/Get` — `video-object.md`) · Files `Fs_*` (`file-api.md`) · Board I/O (`GPIO_Read/Write`, `PWM_Set`,
`ADC_Read`, `UartInit`/`printf`/`uartDataGet`, `I2C_*`, `SPI_*`, `BuzzerSet`) · Network (`EthernetInit_*`,
`SocketTCP_*`, `SocketUDP_*`, `HTTP_PostGet`, `ModbusTCP_*` — `network-api.md`) · `KeypadNum` on-screen
keypad · `WDT_SoftReset`. Legacy names that still compile but are not suggested: `File_*`, Modbus RTU
(`ReadHoldingRegisters`, `Modbus_*`), `VideoPlay`. **Not available**: `itoa` (use `sprintf`), `UartPrint`,
`LabelBoxSet` (use `LabelSet`), `ListViewInsert` (use `lv.Insert = "a^b"`), `GraphAddValue` (use `GRAPH_AddValue`).
**Standard C**: `stdio.h` (`sprintf snprintf sscanf printf`), `stdlib.h` (`abs atoi atof rand srand`),
`string.h`, `math.h` (`sin cos pow sqrt`), `ctype.h`. Type the family prefix in Designer (e.g. `ModbusTCP_`)
or press **F1** on a name to open its guide row.

`printf` goes to the debug channel (simulator log / UART), never to the screen.
