# airhmi-dev changelog

## 2.10.2 — 2026-11-05
Install instructions only (no behaviour change).
- `README.md` Install: "let your agent install it" sentence with the GitHub `Skill` folder link (Claude Code to
  `.claude\skills`, Codex / Cursor / Gemini CLI / Copilot to `.agents\skills`), manual install, update and check steps.
  The old text pointed to a releases page; the zip lives in the repository's `Skill` folder.

## 2.10.1 — 2026-10-28
Dot syntax is now the only style for object properties in new event code.
- `SKILL.md` Stage 4 + negative rules: write `label1.Text = ...;` / `log1.Append = ...;` / `menu1.Items = ...;`;
  no classic property functions (`LabelSet`, `ButtonSet`, `ImageSet`, `LogAppend`, `MenuSet` … `XxxSet/XxxGet("obj","Prop",…)`)
  in new code. Lines touched in old projects are rewritten in dot syntax. Calls without a dot form stay functions
  (`LineAddPoint/LineSetPoint/LineClear`, `ListViewGetXY/SetXY`, `ListViewSet(...,"UPDATE",...)`).
- `lint-project.ps1`: new warning `CLASSIC_PROPERTY_CALL` (count + first call + its dot form; comments ignored).
- `script-api.md`: intro and §2 mark the classic property functions as legacy (for reading old projects) with
  their dot equivalents; traps table uses dot syntax. `widget-reference.md`, `video-object.md`: dot examples only;
  `simulator-socket.md`: function-format commands are socket test commands, not event code.

## 2.10.0 — 2026-10-27
Two new canvas objects (Designer 3.5.0, simulator 3.5.0, firmware V6.04 build 2026-10-27; the product line jumps from 2.9.x to 3.5.0); older Designers
reject them, so the skill checks the version before using them.
- `widget-reference.md`: **Log → `ELog`** (read-only scrolling text log: `maxLines` 1..1000 with batch trimming,
  `timestamp`, `wrapMode`, `autoScroll`, `scrollBar`, `static` keeps content across screens) and **Menu → `EMenu`**
  (finger-scrollable list with `items`, `subTexts`, `icons`, `separators` `"0:Title;3:Title"`, `selPos`,
  `kineticScroll`; tap = `onUp`). Defaults and the example project `1-BasicUI\Log_Menu`.
- `script-api.md`: dot syntax (`log1.Append`, `log1.Clear`, `log1.LineCount`, `menu1.SelPos`, `menu1.SelVal`,
  `menu1.Items`), classic `LogSet/LogGet/LogAppend/LogClear`, `MenuSet/MenuGet`, UART text keys, property table rows.
- `html-to-airhmi.md`: `<ul>`/`<nav>` settings list → `EMenu`, `<pre>`/console → `ELog`.
- `ELog.scrollBarWidth` (px, 8–48, default 24): the vertical bar is finger-sized on the device; timestamps use the
  RTC only when the date was really set (year ≥ 2023), otherwise time since power-on.
- Device note: appending to a full 200-line log costs ≈0.3 s on the device (the widget re-wraps all text) — keep
  `maxLines` at 50–100 for fast feeds.
- `lint-project.ps1`: `ELog` / `EMenu` are known types; `host-protocol.md`: `log1.Append=` / `menu1.SelPos=` lines;
  `ide-inventory.md`: feature row 3.5.0; README version table.

## 2.9.5 — 2026-10-26
Fixes from developer feedback (Turkish Windows, simulator 2.9.0).
- `lint-project.ps1`, `new-project.ps1`: names with a capital `I` (`btnInc`, `lblInfo`, `IsiKontrol`) were rejected
  on Turkish Windows - case-insensitive regex followed the OS culture (`I` → `ı`). Now case-sensitive matching.
- `render-mockup.ps1`: a project folder with a space in its path made the browser exit 13 (no PNG) - the
  `--screenshot` path is now quoted. Non-ASCII folder names (`ö`, `ş`) were already fine.
- `lint-project.ps1`: new warnings - events on `ELabel`/`ELabelBox` (they never run: labels are not touch
  targets, on the device either; use an `EShape` hotspot or `EButton`), and an `EImage` at order 0 on a screen
  with a background image (simulator 2.9.1 and older stop at start-up).
- `script-api.md`: `sscanf` specifiers and limits; simulator 2.9.1 and older lack `sscanf`. Label events note.
- `widget-reference.md`: "labels are not touch targets" with the hotspot recipe.
- `upload-ftp.ps1`: boot files (`hw.cfg`, `init.pcc`, `logo.js`, `options.ini`) last and `files.ini` at the very end,
  so an interrupted upload no longer leaves an empty package list that stops the device at start-up.
- `widget-reference.md`: the `startup` (boot logo) block; `device-deploy.md`: upload order, recovery after a cut
  upload, `552` after inserting the SD card while the device is on.
- Label (`ELabel`) removed in Designer 2.9.6: lint reports `ELabel` as an error, references describe `ELabelBox` as the
  only text component (Designer converts old projects on open: same name/text/events, height = line height).
- Simulator 2.9.2 (Designer setup 2.9.6) fixes the start-up stop, adds `sscanf` and keeps `Visible`/`Text`
  writes made right after re-entering a screen; project variables reading as 0 was fixed in 2.9.1.

## 2.9.4 — 2026-10-20
- Built against AIRHMI Designer 2.9.4 / simulator 2.9.4 / firmware V6.04.
- New references: `network-api.md` (Ethernet, TCP/UDP sockets, HTTP, Modbus TCP with return codes,
  Hardware / Startup Settings `hardware` block → `init.pcc` + `hw.cfg`, PLC polling patterns),
  `file-api.md` (`Fs_*` file functions, recipes, timings, simulator mapping, `File_*` migration),
  `video-object.md` (Video canvas object: MP4 resource → `.emf` at export, JSON fields, play/pause/
  progress functions, size budget, validation codes, incremental FTP).
- `script-api.md`: board I/O signatures corrected to the real names (`GPIO_Write("GPIO_n", v)`,
  `GPIO_Read`, `ADC_Read(n, &d)`, `printf` as UART write, `uartDataGet`, `BuzzerSet`), memory limits
  (8192 B globals / 4096 B per function), `EVideo.Visible`, new EImage/EBarChart properties, new traps
  (`Delay` vs network, legacy `File_*`), simulator section (network and files are real), catalog rewrite.
- `ide-inventory.md`: 2.9.x windows (Hardware / Startup Settings, VNC Viewer, F1 context help, FTP
  unchanged-video skip), new export files, cache/deploy-state paths, version table.
- `widget-reference.md`, `html-to-airhmi.md`, `device-deploy.md` (VNC check, video upload),
  `legacy-ahi-migration.md`, `simulator-socket.md`, `SKILL.md` stages and negative rules updated.

## 2.8.0 — 2026-10-12 (initial)
- First public version, built against AIRHMI Designer 2.8.0 (headless `--export-sim-out` /
  `--validate-out`, font copy), simulator socket 8890, PCC compiler 1.2.0 (dot syntax).
- Workflow: scenario → mockup → convert → code → simulate/compare → device.
- Scripts: env-check, new-project, lint-project, run-sim, AirHmiSocket module, capture-sim,
  compare-shots, render-mockup, upload-ftp, download-ftp.
- References: IDE inventory, widget reference, HTML→AIRHMI, script API (project code layout, C subset,
  dot syntax, cookbook), host protocol (UART text protocol + AIRDUINO), legacy .ahi migration (headless
  convert + checklist), simulator socket, device deploy,
  templates (scenario/roadmap/decisions + minimal projects), example design.
